import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hoverable?: boolean;
  onClick?: boolean | (() => void);
  padding?: 'none' | 'small' | 'medium' | 'large';
}

const Card: React.FC<CardProps> = ({ 
  children, 
  className = '', 
  hoverable = false, 
  onClick,
  padding = 'large'
}) => {
  const paddingClasses = {
    none: 'p-0',
    small: 'p-3',
    medium: 'p-4',
    large: 'p-6'
  };

  const baseClasses = "bg-white/80 backdrop-blur-xl rounded-large border border-black/[0.04] shadow-card transition-all duration-200 ease-in-out";
  const hoverClasses = hoverable || onClick ? "hover:shadow-card-hover hover:-translate-y-0.5 cursor-pointer" : "";
  
  return (
    <div 
      className={`${baseClasses} ${paddingClasses[padding]} ${hoverClasses} ${className}`}
      onClick={typeof onClick === 'function' ? onClick : undefined}
    >
      {children}
    </div>
  );
};

export default Card;
