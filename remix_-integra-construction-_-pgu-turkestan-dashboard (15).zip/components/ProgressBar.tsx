import React from 'react';

interface LinearProgressBarProps {
  value: number; // 0 to 100
  className?: string;
}

export const LinearProgressBar: React.FC<LinearProgressBarProps> = ({ value, className }) => {
  return (
    <div className={`progress-linear ${className}`}>
      <div 
        className="progress-linear-fill" 
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }} 
      />
    </div>
  );
};

interface CircularProgressBarProps {
  value: number; // 0 to 100
  size?: 48 | 64 | 96;
  strokeWidth?: 4 | 6 | 8;
  className?: string;
}

export const CircularProgressBar: React.FC<CircularProgressBarProps> = ({ 
  value, 
  size = 48, 
  strokeWidth = 4, 
  className 
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (Math.min(100, Math.max(0, value)) / 100) * circumference;

  return (
    <div className={`relative flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#E5E5EA"
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#007AFF"
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-500 ease-out"
        />
      </svg>
      <span className="absolute text-[10px] font-bold text-[#1D1D1F]">
        {Math.round(value)}%
      </span>
    </div>
  );
};
