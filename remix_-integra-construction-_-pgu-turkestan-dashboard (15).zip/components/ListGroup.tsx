import React from 'react';

interface ListGroupProps {
  children: React.ReactNode;
  className?: string;
}

export const ListGroup: React.FC<ListGroupProps> = ({ children, className }) => {
  return (
    <div className={`list-group ${className}`}>
      {children}
    </div>
  );
};

interface ListItemProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const ListItem: React.FC<ListItemProps> = ({ children, className, onClick }) => {
  return (
    <div className={`list-item ${className}`} onClick={onClick}>
      {children}
    </div>
  );
};
