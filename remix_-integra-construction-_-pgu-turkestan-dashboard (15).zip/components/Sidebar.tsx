
import React, { useMemo } from 'react';
import { ModuleType, UserRole } from '../types';
import { 
  LayoutDashboard, 
  Files, 
  TableProperties, 
  CalendarDays, 
  Users, 
  HardHat, 
  Truck, 
  BookOpen, 
  Package, 
  Network, 
  Video, 
  ShieldCheck,
  UserRoundCheck,
  ChevronLeft,
  ChevronRight,
  X,
  Box
} from 'lucide-react';

interface SidebarProps {
  activeModule: ModuleType;
  setActiveModule: (m: ModuleType) => void;
  userRole: UserRole;
  isCollapsed: boolean;
  toggleCollapse: () => void;
  isMobileOpen: boolean;
  closeMobileMenu: () => void;
}

const SidebarContent = ({
  isCollapsed,
  activeModule,
  setActiveModule,
  filteredMenuItems,
  userRole
}: {
  isCollapsed: boolean;
  activeModule: ModuleType;
  setActiveModule: (m: ModuleType) => void;
  filteredMenuItems: any[];
  userRole: UserRole;
}) => (
    <>
      <div className={`flex items-center ${isCollapsed ? 'justify-center p-4' : 'p-6 space-x-3'} transition-all duration-300`}>
        <div className="w-10 h-10 bg-[#007AFF] rounded-xl flex items-center justify-center font-bold text-white shadow-lg shadow-[#007AFF]/20 shrink-0 transition-all duration-300">
          <LayoutDashboard size={24} />
        </div>
        
        <div className={`overflow-hidden whitespace-nowrap transition-all duration-300 ${isCollapsed ? 'w-0 opacity-0' : 'w-48 opacity-100'}`}>
          <h1 className="text-[#1D1D1F] text-headline leading-none tracking-tight">INTEGRA</h1>
          <p className="text-caption-2 text-[#86868B] font-black uppercase tracking-widest mt-1">Construction</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-2 custom-scrollbar overflow-x-hidden">
        <ul className="space-y-1">
          {filteredMenuItems.map((item: any) => (
            item.type === 'divider' ? (
              <li key={item.id} className="my-4 border-t border-black/[0.04]" />
            ) : (
              <li key={item.id}>
                <button
                  onClick={() => setActiveModule(item.id as ModuleType)}
                  disabled={item.disabled}
                  title={isCollapsed ? item.label : undefined}
                  className={`w-full h-[44px] flex items-center ${isCollapsed ? 'justify-center px-2' : 'px-3 space-x-3'} rounded-xl transition-all duration-150 ease-in-out group relative ${
                    activeModule === item.id 
                      ? 'bg-[#007AFF]/10 text-[#007AFF] duration-200' 
                      : item.disabled 
                        ? 'text-[#C7C7CC] cursor-not-allowed'
                        : 'text-[#1D1D1F] hover:bg-black/5'
                  }`}
                >
                  <item.icon size={20} className={`shrink-0 transition-colors duration-150 ${activeModule === item.id ? 'text-[#007AFF]' : item.disabled ? 'text-[#C7C7CC]' : 'text-[#86868B] group-hover:text-[#1D1D1F]'}`} />
                  
                  <span className={`text-callout font-medium whitespace-nowrap transition-all duration-300 overflow-hidden ${
                    isCollapsed ? 'w-0 opacity-0' : 'w-auto opacity-100 delay-75'
                  }`}>
                    {item.label}
                  </span>
                  
                  {/* Tooltip for collapsed state */}
                  {isCollapsed && (
                    <div className="absolute left-full top-1/2 -translate-y-1/2 ml-4 bg-[#1D1D1F] text-white text-caption-1 font-medium px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-apple whitespace-nowrap z-50 shadow-lg translate-x-2 group-hover:translate-x-0">
                      {item.label}
                      <div className="absolute left-0 top-1/2 -translate-x-1 -translate-y-1/2 w-2 h-2 bg-[#1D1D1F] rotate-45"></div>
                    </div>
                  )}
                </button>
              </li>
            )
          ))}
          
          {/* ADMIN & LEADERSHIP Specific Buttons */}
          {(userRole === UserRole.ADMIN || userRole === UserRole.LEADERSHIP) && (
            <li className={`mt-6 pt-4 border-t border-black/[0.04] space-y-1`}>
              <button
                onClick={() => setActiveModule('PROJECT_MANAGERS')}
                title={isCollapsed ? 'Рук проекты' : undefined}
                className={`w-full h-[44px] flex items-center ${isCollapsed ? 'justify-center px-2' : 'px-3 space-x-3'} rounded-xl transition-all duration-150 ease-in-out group relative ${
                  activeModule === 'PROJECT_MANAGERS' 
                    ? 'bg-[#007AFF]/10 text-[#007AFF] duration-200' 
                    : 'text-[#1D1D1F] hover:bg-black/5'
                }`}
              >
                <UserRoundCheck size={20} className={`shrink-0 transition-colors duration-150 ${activeModule === 'PROJECT_MANAGERS' ? 'text-[#007AFF]' : 'text-[#86868B] group-hover:text-[#1D1D1F]'}`} />
                <span className={`text-callout font-medium whitespace-nowrap transition-all duration-300 overflow-hidden ${
                    isCollapsed ? 'w-0 opacity-0' : 'w-auto opacity-100 delay-75'
                  }`}>
                    Рук проекты
                </span>
              </button>
              
              {/* Only ADMIN sees Admin Panel */}
              {userRole === UserRole.ADMIN && (
                <button
                  onClick={() => setActiveModule('ADMIN_PANEL')}
                  title={isCollapsed ? 'Админ-панель' : undefined}
                  className={`w-full h-[44px] flex items-center ${isCollapsed ? 'justify-center px-2' : 'px-3 space-x-3'} rounded-xl transition-all duration-150 ease-in-out group relative ${
                    activeModule === 'ADMIN_PANEL' 
                      ? 'bg-[#007AFF]/10 text-[#007AFF] duration-200' 
                      : 'text-[#1D1D1F] hover:bg-black/5'
                }`}
              >
                <ShieldCheck size={20} className={`shrink-0 transition-colors duration-150 ${activeModule === 'ADMIN_PANEL' ? 'text-[#007AFF]' : 'text-[#86868B] group-hover:text-[#1D1D1F]'}`} />
                <span className={`text-callout font-medium whitespace-nowrap transition-all duration-300 overflow-hidden ${
                      isCollapsed ? 'w-0 opacity-0' : 'w-auto opacity-100 delay-75'
                    }`}>
                      Админ-панель
                  </span>
                </button>
              )}
            </li>
          )}
        </ul>
      </nav>

      {/* Footer Info */}
      <div className={`p-4 border-t border-black/[0.04] flex transition-all duration-300 ${isCollapsed ? 'justify-center' : 'justify-between items-center'}`}>
        {!isCollapsed && (
          <div className="flex flex-col">
            <span className="text-caption-2 uppercase font-black tracking-widest text-[#86868B]">Система v2.4.0</span>
            <div className="flex items-center gap-1.5 mt-1">
              <div className="w-2 h-2 rounded-full bg-[#34C759] animate-pulse"></div>
              <span className="text-caption-2 font-black text-[#86868B]">В сети</span>
            </div>
          </div>
        )}
        
        {isCollapsed && (
          <div className="w-2 h-2 rounded-full bg-[#34C759] animate-pulse"></div>
        )}
      </div>
    </>
);

const Sidebar: React.FC<SidebarProps> = ({ 
  activeModule, 
  setActiveModule, 
  userRole, 
  isCollapsed, 
  toggleCollapse,
  isMobileOpen,
  closeMobileMenu
}) => {
  
  const filteredMenuItems = useMemo(() => {
    const allItems = [
      { id: 'GENERAL_STATUS', label: 'Общий статус', icon: LayoutDashboard },
      { id: 'EXECUTION_SUMMARY', label: 'Сводка выполнения', icon: Files },
      { id: 'TITLES', label: 'Прогресс титулов', icon: TableProperties },
      { id: 'WORK_PLAN', label: 'План работ', icon: CalendarDays },
      { id: 'HR_RESOURCES', label: 'Расстановка HR', icon: Users },
      { id: 'SUBCONTRACTORS', label: 'Субподрядчики', icon: HardHat },
      { id: 'EQUIPMENT', label: 'Техника', icon: Truck },
      { id: 'divider-1', label: '', type: 'divider' },
      { id: 'HANDBOOK', label: 'Справочник', icon: BookOpen },
      { id: 'SUPPLY', label: 'Реестр снабжения', icon: Package },
      { id: 'GEN_STRUCTURE', label: 'Структура генподряда', icon: Network },
      { id: 'LIVE', label: 'Онлайн-трансляция', icon: Video },
    ];
    
    if (userRole === UserRole.VIEWER) {
      const allowedViewerModules = ['GENERAL_STATUS', 'EXECUTION_SUMMARY', 'TITLES', 'HR_RESOURCES', 'WORK_PLAN'];
      return allItems.filter(item => item.type === 'divider' || allowedViewerModules.includes(item.id));
    }

    return allItems;
  }, [userRole]);

  return (
    <>
      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 lg:hidden animate-in fade-in duration-300"
          onClick={closeMobileMenu}
        />
      )}

      {/* Mobile Sidebar (Slide-over) */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-white flex flex-col h-full border-r border-black/[0.04] transform transition-transform duration-300 ease-in-out lg:hidden ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="absolute top-4 right-4">
          <button onClick={closeMobileMenu} className="btn-icon">
            <X size={20} />
          </button>
        </div>
        <SidebarContent 
          isCollapsed={false}
          activeModule={activeModule}
          setActiveModule={setActiveModule}
          filteredMenuItems={filteredMenuItems}
          userRole={userRole}
        />
      </aside>

      {/* Desktop Sidebar (Static / Collapsible) */}
      <aside className={`hidden lg:flex fixed inset-y-0 left-0 z-40 bg-white/80 backdrop-blur-xl flex-col h-full border-r border-black/[0.08] shrink-0 transition-[width] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] shadow-[4px_0_24px_-8px_rgba(0,0,0,0.05)] ${isCollapsed ? 'w-[80px]' : 'w-[280px]'}`}>
        <SidebarContent 
          isCollapsed={isCollapsed}
          activeModule={activeModule}
          setActiveModule={setActiveModule}
          filteredMenuItems={filteredMenuItems}
          userRole={userRole}
        />
        
        {/* Toggle Button */}
        <button 
          onClick={toggleCollapse}
          className="absolute top-12 -right-3 w-6 h-6 bg-white text-[#86868B] rounded-full flex items-center justify-center shadow-md border border-black/[0.08] hover:text-[#007AFF] transition-apple z-10 hover:scale-110 active:scale-95"
        >
          {isCollapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
        </button>
      </aside>
    </>
  );
};

export default Sidebar;
