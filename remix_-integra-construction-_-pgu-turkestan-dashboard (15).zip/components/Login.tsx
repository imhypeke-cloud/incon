
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (login: string, pass: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [login, setLogin] = useState('');
  const [pass, setPass] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(login, pass);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F7] flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-[#007AFF]/5 -skew-x-12 translate-x-1/4"></div>
      <div className="absolute bottom-0 left-0 w-1/3 h-1/2 bg-[#FF3B30]/5 skew-y-12 -translate-x-1/4"></div>

      <div className="max-w-md w-full relative z-10 animate-in fade-in zoom-in-95 duration-500">
        <div className="bg-white/80 backdrop-blur-xl rounded-3xl p-10 shadow-[0_8px_32px_-8px_rgba(0,0,0,0.1)] border border-black/[0.04]">
          <div className="flex flex-col items-center mb-10">
            <div className="w-16 h-16 bg-[#007AFF] rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-lg shadow-[#007AFF]/20 mb-6">IC</div>
            <h1 className="text-title-1 text-[#1D1D1F] tracking-tight text-center uppercase">Integra Construction</h1>
            <p className="text-caption-2 text-[#86868B] font-black uppercase tracking-widest mt-2">PGU Turkestan | Portal v2.4</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest ml-1 mb-2 block">Логин</label>
              <input 
                type="text" 
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                className="input-field w-full"
                placeholder="inconshym / admin / viewer"
              />
            </div>
            <div>
              <label className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest ml-1 mb-2 block">Пароль</label>
              <input 
                type="password" 
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                className="input-field w-full"
                placeholder="••••••••"
              />
            </div>
            <button 
              type="submit"
              className="btn-primary w-full uppercase tracking-widest text-caption-1 mt-4"
            >
              Войти в систему
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-black/[0.04] flex items-center justify-between">
            <span className="text-caption-2 text-[#86868B] font-black uppercase tracking-widest">© 2026 Integra Construction</span>
            <div className="flex space-x-2">
              <div className="w-2 h-2 rounded-full bg-black/[0.08]"></div>
              <div className="w-2 h-2 rounded-full bg-black/[0.08]"></div>
              <div className="w-2 h-2 rounded-full bg-[#34C759] animate-pulse shadow-[0_0_8px_rgba(52,199,89,0.5)]"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
