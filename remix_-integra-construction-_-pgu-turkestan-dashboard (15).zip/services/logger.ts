import { AuditLog } from '../types';

export const logAction = async (user: string, role: string, action: string) => {
  const newLog: AuditLog = {
    id: Math.random().toString(36).substr(2, 9),
    user,
    role,
    timestamp: new Date().toLocaleString(),
    action
  };

  try {
    await fetch('/api/logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newLog)
    });
  } catch (e) {
    console.error('Failed to save log', e);
  }
};
