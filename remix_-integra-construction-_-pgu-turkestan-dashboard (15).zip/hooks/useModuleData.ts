import { useState, useEffect } from 'react';

export function useModuleData<T>(moduleName: string, initialData: T) {
  const [data, setData] = useState<T>(initialData);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`/api/data/${moduleName}`);
        if (response.ok) {
          const result = await response.json();
          setData(result);
        } else if (response.status === 404) {
          // If not found, save the initial data to the server
          await fetch(`/api/data/${moduleName}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(initialData),
          });
          setData(initialData);
        } else {
          throw new Error('Failed to fetch data');
        }
      } catch (err) {
        console.error(`Error loading ${moduleName} data:`, err);
        setError((err as Error).message);
        // Fallback to initial data
        setData(initialData);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [moduleName]);

  const updateData = async (newData: T) => {
    setData(newData);
    try {
      const response = await fetch(`/api/data/${moduleName}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newData),
      });
      if (!response.ok) {
        throw new Error('Failed to save data');
      }
    } catch (err) {
      console.error(`Error saving ${moduleName} data:`, err);
      setError((err as Error).message);
    }
  };

  return { data, updateData, isLoading, error };
}
