import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ProjectStatus, ModuleType, Title, HumanResource, Equipment } from '../types';
import { INITIAL_EXECUTION_KPIS } from '../constants';
import Card from '../components/Card';
import { 
  Users, 
  Truck, 
  Layers, 
  Calendar,
  ArrowUpRight,
  AlertCircle,
  Activity,
  TrendingUp,
  Package
} from 'lucide-react';

interface GeneralStatusProps {
  onNavigate: (m: ModuleType) => void;
  titles: Title[];
  hr: HumanResource[];
  equipment: Equipment[];
}

const GeneralStatus: React.FC<GeneralStatusProps> = React.memo(({ onNavigate, titles = [], hr = [], equipment = [] }) => {
  const stats = useMemo(() => {
    const safeTitles = Array.isArray(titles) ? titles : [];
    
    // Mock data for charts
    const chartData = [
      { name: 'Пн', value: 400 },
      { name: 'Вт', value: 300 },
      { name: 'Ср', value: 600 },
      { name: 'Чт', value: 800 },
      { name: 'Пт', value: 500 },
      { name: 'Сб', value: 700 },
      { name: 'Вс', value: 900 },
    ];

    const totalRC = safeTitles.reduce((acc, t) => acc + (t.rc?.total || 0), 0);
    const doneRC = safeTitles.reduce((acc, t) => acc + (t.rc?.done || 0), 0);
    const rcProgress = totalRC > 0 ? (doneRC / totalRC) * 100 : 0;

    const safeHr = Array.isArray(hr) ? hr : [];
    const totalPeople = safeHr.find(item => item.subcontractor === 'ИТОГО')?.total ?? safeHr.reduce((acc, item) => acc + Number(item.total || 0), 0);
    
    const safeEquipment = Array.isArray(equipment) ? equipment : [];
    const totalEquipment = safeEquipment.reduce((acc, item) => acc + Number(item.total || 0), 0);

    return {
      rcProgress,
      totalPeople,
      totalEquipment,
      chartData,
      statusCounts: {
        [ProjectStatus.IN_SCHEDULE]: safeTitles.filter(t => t.status === ProjectStatus.IN_SCHEDULE).length || 0,
        [ProjectStatus.RISK]: safeTitles.filter(t => t.status === ProjectStatus.RISK).length || 0,
        [ProjectStatus.DELAY]: safeTitles.filter(t => t.status === ProjectStatus.DELAY).length || 0,
        [ProjectStatus.COMPLETED]: safeTitles.filter(t => t.status === ProjectStatus.COMPLETED).length || 0,
      }
    };
  }, [titles, hr, equipment]);

  return (
    <div className="space-y-6 animate-in fade-in duration-700 pb-10">
      
      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard icon={Users} label="Персонал" value={stats.totalPeople} trend="+12%" trendUp={true} />
        <KPICard icon={Truck} label="Техника" value={stats.totalEquipment} trend="-5%" trendUp={false} />
        <KPICard icon={Layers} label="Прогресс КЖ" value={`${stats.rcProgress.toFixed(0)}%`} trend="+2%" trendUp={true} />
        <KPICard icon={Package} label="Завершено" value={stats.statusCounts[ProjectStatus.COMPLETED]} trend="+8%" trendUp={true} />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-headline text-[#1D1D1F] mb-6">Динамика работ</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.chartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#007AFF" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#007AFF" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="value" stroke="#007AFF" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        
        <Card className="p-6">
          <h3 className="text-headline text-[#1D1D1F] mb-6">Распределение статусов</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.chartData}>
                <defs>
                  <linearGradient id="colorValue2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#34C759" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#34C759" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="value" stroke="#34C759" strokeWidth={3} fillOpacity={1} fill="url(#colorValue2)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {/* Activity Feed */}
      <Card className="p-6">
        <h3 className="text-headline text-[#1D1D1F] mb-6">Лента активности</h3>
        <div className="space-y-4">
          <ActivityItem title="Заливка бетона" time="10:00" desc="Сектор А, 50м3" />
          <ActivityItem title="Поставка арматуры" time="09:30" desc="Машина №123" />
        </div>
      </Card>
    </div>
  );
});

const KPICard: React.FC<{ icon: any; label: string; value: string | number; trend: string; trendUp: boolean }> = ({ icon: Icon, label, value, trend, trendUp }) => (
  <Card className="p-6 relative">
    <div className={`absolute top-4 right-4 px-2 py-1 rounded-full text-[10px] font-black ${trendUp ? 'bg-[#34C759]/10 text-[#34C759]' : 'bg-[#FF3B30]/10 text-[#FF3B30]'}`}>
      {trend}
    </div>
    <div className="w-12 h-12 bg-[#007AFF]/10 rounded-2xl flex items-center justify-center text-[#007AFF] mb-4">
      <Icon size={24} />
    </div>
    <div className="text-[32px] font-bold text-[#1D1D1F] leading-none">{value}</div>
    <div className="text-[15px] text-[#86868B] mt-1">{label}</div>
  </Card>
);

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-lg border border-black/[0.04]">
        <p className="text-xs font-black text-[#86868B] uppercase">{label}</p>
        <p className="text-lg font-bold text-[#1D1D1F]">{payload[0].value}</p>
      </div>
    );
  }
  return null;
};

const ActivityItem: React.FC<{ title: string; time: string; desc: string }> = ({ title, time, desc }) => (
  <div className="flex items-center gap-4 p-4 rounded-2xl bg-[#F5F5F7] border border-black/[0.04]">
    <div className="w-2 h-2 rounded-full bg-[#007AFF]" />
    <div className="text-xs font-bold text-[#86868B]">{time}</div>
    <div className="text-sm font-bold text-[#1D1D1F]">{title}</div>
    <div className="text-sm text-[#86868B]">{desc}</div>
  </div>
);

export default GeneralStatus;