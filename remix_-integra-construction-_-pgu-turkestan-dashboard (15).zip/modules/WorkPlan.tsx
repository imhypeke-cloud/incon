import React, { useMemo, useState } from 'react';
import { WorkPlanRecord } from '../types';
import { useData } from '../services/DataContext';
import { 
  Search, 
  Calendar,
  ChevronLeft,
  ChevronRight,
  Filter
} from 'lucide-react';
import Card from '../components/Card';

type ViewType = 'week' | 'month' | 'quarter';

const WorkPlan: React.FC = () => {
  const { workPlan } = useData();
  const [view, setView] = useState<ViewType>('week');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredData = useMemo(() => {
    if (!workPlan) return [];
    return workPlan.filter(record => 
      record.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [workPlan, searchTerm]);

  return (
    <div className="h-full flex flex-col space-y-6 animate-in fade-in duration-500 p-1 pb-10 max-w-7xl mx-auto">
      
      {/* Header & Controls */}
      <Card className="flex items-center justify-between p-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-[#007AFF] text-white rounded-xl flex items-center justify-center shadow-lg"><Calendar size={20} /></div>
          <div>
            <h1 className="text-headline text-[#1D1D1F] uppercase tracking-tight leading-none">План работ</h1>
            <p className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest mt-1">График выполнения и мониторинг</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex bg-[#F5F5F7] p-1 rounded-xl">
            {(['week', 'month', 'quarter'] as ViewType[]).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${
                  view === v ? 'bg-[#007AFF] text-white shadow-sm' : 'text-[#86868B] hover:text-[#1D1D1F]'
                }`}
              >
                {v === 'week' ? 'Неделя' : v === 'month' ? 'Месяц' : 'Квартал'}
              </button>
            ))}
          </div>
          
          <div className="relative group">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#C7C7CC] group-focus-within:text-[#007AFF] transition-colors" size={18} />
            <input 
              type="text"
              placeholder="ПОИСК..."
              className="input-field w-64 pl-11"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </Card>

      <div className="flex gap-6 flex-1">
        {/* Sidebar Filters */}
        <Card className="w-64 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-caption-1 font-black uppercase tracking-widest text-[#1D1D1F]">Фильтры</h3>
            <button className="text-xs text-[#007AFF] font-bold">Очистить</button>
          </div>
          <div className="space-y-2">
            {['Бетон', 'Металл', 'Отделка', 'Инженерка'].map(type => (
              <button key={type} className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-[#F5F5F7] text-xs font-bold text-[#1D1D1F] hover:bg-[#007AFF]/10 transition-colors">
                {type}
                <div className="w-2 h-2 rounded-full bg-[#007AFF]" />
              </button>
            ))}
          </div>
        </Card>

        {/* Calendar Grid */}
        <Card className="flex-1 p-6 overflow-auto">
          <div className={`grid gap-2 ${view === 'week' ? 'grid-cols-7' : 'grid-cols-30'}`}>
            {Array.from({ length: view === 'week' ? 7 : 30 }).map((_, i) => (
              <div key={i} className="min-h-[120px] border border-black/[0.05] rounded-xl p-2 bg-[#F5F5F7]/30">
                <span className="text-[10px] font-bold text-[#86868B]">{i + 1}</span>
                {i === 2 && (
                  <div className="mt-2 bg-[#007AFF]/10 border-l-4 border-[#007AFF] p-2 rounded-lg cursor-pointer hover:shadow-md transition-all">
                    <p className="text-[13px] font-medium text-[#1D1D1F]">Заливка секции А</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default WorkPlan;
