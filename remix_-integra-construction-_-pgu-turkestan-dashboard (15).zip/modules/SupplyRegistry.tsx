
import React, { useState, useMemo } from 'react';
import { 
  Package, 
  Truck, 
  Search, 
  Filter, 
  User, 
  Calendar, 
  Warehouse, 
  FileText,
  ClipboardList,
  ChevronLeft,
  ChevronRight,
  Clock,
  AlertCircle,
  MoreHorizontal,
  ArrowUpDown,
  AlertTriangle,
  Timer,
  History,
  Download
} from 'lucide-react';
import { AuditLog } from '../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import Card from '../components/Card';
import { ListGroup, ListItem } from '../components/ListGroup';

interface SupplyItem {
  id: string;           // Номер заявки
  date: string;         // Дата заявки
  material: string;     // Наименование
  unit: string;         // Ед. изм.
  qty: string | number; // Кол-во
  note: string;         // Примечание (из дока)
  responsible: string;  // Ответственное лицо
  status: string;       // Статус (1-4)
  supplier: string;     // Поставщик
  comment: string;      // Комментарии
  deliveryDate: string; // Дата поставки
  daysInWork: string | number; // Количество дней в работе
  title: string;        // Титул (объект)
}

interface SupplyRegistryProps {
  data: SupplyItem[];
  auditLogs: AuditLog[];
}

const SupplyRegistry: React.FC<SupplyRegistryProps> = React.memo(({ data = [], auditLogs = [] }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'ALL' | '1' | '2' | '3' | '4' | 'STORE' | 'CRITICAL'>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc'); // asc = от ранних к поздним
  const [showHistory, setShowHistory] = useState(false);
  const itemsPerPage = 50;
  
  // Дата актуальности данных (из файла)
  const DATA_DATE = "10.03.2026";

  // Вспомогательная функция парсинга даты DD.MM.YYYY
  const parseDate = (dateStr: any) => {
    if (!dateStr || dateStr === '—') return new Date(0);
    const str = String(dateStr);
    if (!str.includes('.')) return new Date(0);
    const parts = str.split('.');
    if (parts.length !== 3) return new Date(0);
    const [day, month, year] = parts.map(Number);
    return new Date(year, month - 1, day);
  };

  // Функция расчета дней в работе
  const calculateDays = (itemDate: any, explicitDays: any) => {
    // Если в исходных данных уже есть число дней (из OCR), используем его
    if (typeof explicitDays === 'number' && explicitDays > 0) return explicitDays;
    if (typeof explicitDays === 'string' && !isNaN(Number(explicitDays)) && Number(explicitDays) > 0) return Number(explicitDays);
    
    // Иначе считаем от даты заявки до текущей даты (актуальности)
    const start = parseDate(itemDate);
    const end = new Date(); // Use current date for calculation if not static
    
    if (start.getTime() === 0) return 0;

    const diffTime = end.getTime() - start.getTime();
    const days = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return days > 0 ? days : 0;
  };

  // Process data to ensure daysInWork is calculated
  const processedData = useMemo(() => {
    return data.map(item => ({
      ...item,
      daysInWork: calculateDays(item.date, item.daysInWork)
    }));
  }, [data]);

  const stats = useMemo(() => {
    return {
      total: processedData.length,
      purchasing: processedData.filter(i => String(i.supplier || '').includes('1.') || String(i.supplier || '').includes('2.')).length,
      contracts: processedData.filter(i => String(i.supplier || '').includes('3.')).length,
      transit: processedData.filter(i => String(i.supplier || '').includes('4.')).length,
      warehouse: processedData.filter(i => String(i.supplier || '') === 'На складе' || String(i.supplier || '').includes('склад') || String(i.note || '').includes('на складе')).length,
      critical: processedData.filter(i => (i.daysInWork as number) > 60).length
    };
  }, [processedData]);

  // Топ проблемных (самые старые незавершенные)
  const criticalItems = useMemo(() => {
      return [...processedData]
        .filter(i => !String(i.supplier || '').includes('COMPLETE') && !String(i.supplier || '').includes('На складе') && !String(i.supplier || '').includes('0. Дополнительное') && (i.daysInWork as number) > 0)
        .sort((a,b) => (b.daysInWork as number) - (a.daysInWork as number))
        .slice(0, 3);
  }, [processedData]);

  // Фильтрация
  const filteredData = useMemo(() => {
    return processedData.filter(item => {
      const searchStr = searchQuery.toLowerCase();
      const searchMatch = String(item.material || '').toLowerCase().includes(searchStr) || 
                          String(item.id || '').toLowerCase().includes(searchStr) ||
                          String(item.title || '').toLowerCase().includes(searchStr);
      
      let tabMatch = true;
      const supplierStr = String(item.supplier || '');
      if (activeTab === '1') tabMatch = supplierStr.includes('1.');
      if (activeTab === '2') tabMatch = supplierStr.includes('2.');
      if (activeTab === '3') tabMatch = supplierStr.includes('3.');
      if (activeTab === '4') tabMatch = supplierStr.includes('4.');
      if (activeTab === 'STORE') tabMatch = supplierStr === 'На складе' || supplierStr.includes('склад') || String(item.note || '').includes('на складе');
      if (activeTab === 'CRITICAL') tabMatch = (item.daysInWork as number) > 60;

      return searchMatch && tabMatch;
    });
  }, [searchQuery, activeTab, processedData]);

  // Сортировка
  const sortedData = useMemo(() => {
      return [...filteredData].sort((a, b) => {
          const dateA = parseDate(a.date).getTime();
          const dateB = parseDate(b.date).getTime();
          return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
      });
  }, [filteredData, sortOrder]);

  // Пагинация
  const totalPages = Math.ceil(sortedData.length / itemsPerPage);
  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage]);

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      document.querySelector('main')?.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const getRowStyle = (days: number) => {
      if (days > 90) return 'bg-rose-50 border-l-4 border-l-rose-500';
      if (days > 45) return 'bg-amber-50 border-l-4 border-l-amber-500';
      return 'hover:bg-blue-50/30 border-l-4 border-l-transparent';
  };

  const exportToPDF = () => {
    const doc = new jsPDF('l', 'mm', 'a4'); // Landscape orientation
    
    // Add title
    doc.setFontSize(16);
    doc.text('Реестр снабжения', 14, 15);
    doc.setFontSize(10);
    doc.text(`Дата актуальности: ${DATA_DATE}`, 14, 22);

    // Define table columns and rows
    const tableColumn = [
      "Заявка", "Дата", "Материал", "Ед.", "Кол-во", 
      "Ответственный", "Статус", "Поставщик", "План поставки", "Дней", "Титул"
    ];

    const tableRows = filteredData.map(item => [
      item.id,
      item.date,
      item.material,
      item.unit,
      item.qty,
      item.responsible,
      item.status,
      item.supplier,
      item.deliveryDate,
      item.daysInWork,
      item.title
    ]);

    // Generate table
    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 30,
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [15, 23, 42], textColor: 255, fontStyle: 'bold' }, // Slate-900
      alternateRowStyles: { fillColor: [248, 250, 252] }, // Slate-50
    });

    // Save PDF
    doc.save(`supply_registry_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      
      {/* ЗАГОЛОВОК И АКТУАЛЬНОСТЬ */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-4 mb-2">
          <div>
             <h2 className="text-2xl font-black text-[#1D1D1F]">Реестр снабжения</h2>
             <p className="text-xs text-[#86868B] font-bold mt-1 uppercase tracking-widest flex items-center">
                <Calendar size={14} className="mr-2 text-[#007AFF]"/>
                Актуальность данных: <span className="text-[#1D1D1F] ml-1">{DATA_DATE}</span>
             </p>
          </div>
          <div className="flex gap-2">
             <button 
                onClick={exportToPDF}
                className="btn-primary h-[36px] px-4 text-xs"
             >
                <Download size={14} className="mr-2" />
                Скачать PDF
             </button>
             <button 
                onClick={() => setShowHistory(!showHistory)}
                className={`btn-secondary h-[36px] px-4 text-xs ${
                  showHistory 
                    ? 'bg-[#007AFF]/5 border-[#007AFF]/10 text-[#007AFF]' 
                    : 'border-black/[0.04] text-[#86868B] hover:bg-[#F5F5F7]'
                }`}
             >
                <History size={14} className="mr-2" />
                История загрузок
             </button>
             <button 
                onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                className="btn-secondary border-black/[0.04] text-[#1D1D1F] h-[36px] px-4 text-xs"
             >
                <ArrowUpDown size={14} className="mr-2" />
                {sortOrder === 'asc' ? 'Сначала ранние (Старые)' : 'Сначала поздние (Новые)'}
             </button>
          </div>
      </div>

      {/* ИСТОРИЯ ЗАГРУЗОК */}
      {showHistory && (
        <Card className="animate-in slide-in-from-top-4 duration-300">
          <h3 className="text-sm font-black text-[#1D1D1F] uppercase tracking-wider mb-4 flex items-center gap-2">
            <History size={16} className="text-[#007AFF]"/>
            История обновлений реестра
          </h3>
          
          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
            {auditLogs.filter(log => log.module === 'SUPPLY').length === 0 ? (
              <p className="text-xs text-[#86868B] italic text-center py-4">История загрузок пуста</p>
            ) : (
              auditLogs
                .filter(log => log.module === 'SUPPLY')
                .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                .map((log) => (
                  <div key={log.id} className="flex items-start gap-3 p-3 rounded-xl bg-[#F5F5F7] border border-black/[0.04] hover:bg-[#007AFF]/5 transition-colors group">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      log.status === 'SUCCESS' ? 'bg-[#34C759]/10 text-[#34C759]' : 'bg-[#FF3B30]/10 text-[#FF3B30]'
                    }`}>
                      {log.status === 'SUCCESS' ? <FileText size={14} /> : <AlertCircle size={14} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <p className="text-xs font-bold text-[#1D1D1F] truncate">{log.fileName}</p>
                        <span className="text-[10px] text-[#86868B] whitespace-nowrap ml-2">
                          {new Date(log.timestamp).toLocaleString('ru-RU')}
                        </span>
                      </div>
                      <p className="text-[10px] text-[#86868B] mt-0.5">
                        {log.action} • {log.details}
                      </p>
                      <p className="text-[9px] text-[#C7C7CC] mt-1 flex items-center gap-1">
                        <User size={10} /> {log.user}
                      </p>
                    </div>
                  </div>
                ))
            )}
          </div>
        </Card>
      )}

      {/* АНАЛИЗ ЗАДЕРЖЕК */}
      {criticalItems.length > 0 && (
          <Card className="border-[#FF3B30]/20 shadow-lg shadow-[#FF3B30]/5 p-6 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-2 h-full bg-[#FF3B30]"></div>
              <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-[#FF3B30]/10 text-[#FF3B30] rounded-lg">
                      <AlertTriangle size={24}/>
                  </div>
                  <div>
                      <h3 className="font-black text-[#1D1D1F] text-lg leading-none">Топ проблемных позиций</h3>
                      <p className="text-xs text-[#86868B] font-medium mt-1">Требуют немедленного внимания ({'>'} 45 дней)</p>
                  </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {criticalItems.map((item, idx) => (
                      <div key={idx} className="bg-[#FF3B30]/5 rounded-xl p-4 border border-[#FF3B30]/10 flex flex-col justify-between">
                          <div>
                              <div className="flex justify-between items-start mb-2">
                                  <span className="text-[10px] font-black bg-white border border-[#FF3B30]/10 px-2 py-1 rounded text-[#FF3B30]">{item.id}</span>
                                  <span className="text-xs font-bold text-[#86868B]">{item.date}</span>
                              </div>
                              <p className="font-bold text-[#1D1D1F] text-sm line-clamp-2 leading-tight mb-2" title={item.material}>{item.material}</p>
                              <p className="text-[10px] text-[#86868B] truncate">{item.responsible}</p>
                          </div>
                          <div className="mt-3 pt-3 border-t border-[#FF3B30]/10 flex items-center justify-between">
                               <span className="text-[10px] font-bold text-[#86868B] uppercase">В работе</span>
                              <span className="text-lg font-black text-[#FF3B30] flex items-center gap-1">
                                  <Timer size={16}/> {item.daysInWork} дн.
                              </span>
                          </div>
                      </div>
                  ))}
              </div>
          </Card>
      )}

      {/* СВОДНЫЕ КАРТОЧКИ */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <StatItem icon={<ClipboardList size={20}/>} label="Всего заявок" value={stats.total} color="slate" />
        <StatItem icon={<Search size={20}/>} label="Тендеры / КП" value={stats.purchasing} color="amber" />
        <StatItem icon={<FileText size={20}/>} label="Договор / Аванс" value={stats.contracts} color="blue" />
        <StatItem icon={<Truck size={20}/>} label="Товар в пути" value={stats.transit} color="indigo" />
        <StatItem icon={<AlertCircle size={20}/>} label="Критично (>60 дн)" value={stats.critical} color="rose" />
      </div>

      {/* ПАНЕЛЬ УПРАВЛЕНИЯ */}
      <Card className="flex flex-col lg:flex-row items-center justify-between gap-6">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'ALL', label: 'Все данные' },
            { id: 'CRITICAL', label: '❗ Критичные' },
            { id: '1', label: '1. Сбор КП' },
            { id: '2', label: '2. Протокол' },
            { id: '3', label: '3. Договор' },
            { id: '4', label: '4. Поставка' },
            { id: 'STORE', label: 'Склад ПГУ' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id as any); setCurrentPage(1); }}
              className={`px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === tab.id 
                  ? (tab.id === 'CRITICAL' ? 'bg-[#FF3B30] text-white shadow-xl scale-105' : 'bg-[#1D1D1F] text-white shadow-xl scale-105') 
                  : 'bg-[#F5F5F7] text-[#86868B] hover:bg-[#E5E5EA]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative flex-1 lg:min-w-[400px]">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#C7C7CC]" size={16} />
          <input 
            type="text" 
            placeholder="Поиск по материалу, ERP или Титулу..." 
            value={searchQuery}
            onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
            className="input-field w-full pl-11"
          />
        </div>
      </Card>

      {/* РЕЕСТР (ТАБЛИЦА) */}
      <Card padding="none" className="overflow-hidden flex flex-col max-h-[800px]">
        <div className="overflow-auto custom-scrollbar flex-1">
        <ListGroup>
          {paginatedData.map((item, idx) => (
            <ListItem key={idx} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="flex items-center gap-4 col-span-1 lg:col-span-2">
                <div className="w-12 h-12 rounded-2xl bg-[#F5F5F7] flex items-center justify-center shrink-0">
                  {item.supplier === 'На складе' || item.supplier?.includes('склад') ? <Warehouse size={20} className="text-[#86868B]" /> : <Package size={20} className="text-[#86868B]" />}
                </div>
                <div>
                  <div className="text-xs font-black text-[#1D1D1F]">{item.id}</div>
                  <div className="text-[10px] font-bold text-[#86868B]">{item.date}</div>
                  <div className="text-sm font-black text-[#1D1D1F] mt-1">{item.material}</div>
                </div>
              </div>
              <div className="flex flex-col justify-center">
                <div className="text-[10px] font-bold text-[#86868B] uppercase">Ответственный</div>
                <div className="text-xs font-black text-[#1D1D1F]">{item.responsible}</div>
                <div className="text-[10px] font-bold text-[#86868B] uppercase mt-2">Титул</div>
                <div className="text-xs font-black text-[#007AFF]">{item.title}</div>
              </div>
              <div className="flex flex-col justify-center items-end">
                <StatusBadge status={item.supplier} />
                <div className="text-xs font-black text-[#1D1D1F] mt-2">{item.qty} {item.unit}</div>
                <div className={`text-xs font-black mt-1 ${(item.daysInWork as number) > 60 ? 'text-[#FF3B30]' : (item.daysInWork as number) > 30 ? 'text-[#FF9500]' : 'text-[#86868B]'}`}>
                  {item.daysInWork} дней
                </div>
              </div>
            </ListItem>
          ))}
        </ListGroup>
        </div>
      </Card>

      {/* ПАГИНАЦИЯ */}
      {totalPages > 1 && (
        <Card className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[10px] font-black text-[#86868B] uppercase tracking-widest">
            Показано {(currentPage - 1) * itemsPerPage + 1} - {Math.min(currentPage * itemsPerPage, sortedData.length)} из {sortedData.length} позиций
          </p>
          
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className={`p-3 rounded-xl border transition-all ${currentPage === 1 ? 'text-[#C7C7CC] border-transparent cursor-not-allowed' : 'text-[#86868B] border-black/[0.04] hover:bg-[#F5F5F7] hover:text-[#007AFF]'}`}
            >
              <ChevronLeft size={20} />
            </button>
            
            <div className="flex items-center space-x-1 px-2 overflow-x-auto max-w-[300px] no-scrollbar">
              {generatePageNumbers(currentPage, totalPages).map((page, i) => (
                page === '...' ? (
                  <span key={i} className="px-3 text-[#C7C7CC]"><MoreHorizontal size={14} /></span>
                ) : (
                  <button
                    key={i}
                    onClick={() => handlePageChange(Number(page))}
                    className={`w-10 h-10 rounded-xl text-xs font-black transition-all shrink-0 ${
                      currentPage === page 
                        ? 'bg-[#1D1D1F] text-white shadow-xl scale-110' 
                        : 'bg-white text-[#86868B] hover:bg-[#F5F5F7] border border-black/[0.04]'
                    }`}
                  >
                    {page}
                  </button>
                )
              ))}
            </div>

            <button 
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className={`p-3 rounded-xl border transition-all ${currentPage === totalPages ? 'text-[#C7C7CC] border-transparent cursor-not-allowed' : 'text-[#86868B] border-black/[0.04] hover:bg-[#F5F5F7] hover:text-[#007AFF]'}`}
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </Card>
      )}
    </div>
  );
});

// Вспомогательная функция для генерации номеров страниц
const generatePageNumbers = (current: number, total: number) => {
  const pages = [];
  const delta = 2;
  for (let i = 1; i <= total; i++) {
    if (i === 1 || i === total || (i >= current - delta && i <= current + delta)) {
      pages.push(i);
    } else if (pages[pages.length - 1] !== '...') {
      pages.push('...');
    }
  }
  return pages;
};

const StatItem: React.FC<{ icon: React.ReactNode; label: string; value: number | string; color: 'slate' | 'amber' | 'blue' | 'indigo' | 'emerald' | 'rose' }> = ({ icon, label, value, color }) => {
  const themes = {
    slate: 'bg-white text-[#1D1D1F]',
    amber: 'bg-white text-[#FF9500]',
    blue: 'bg-white text-[#007AFF]',
    indigo: 'bg-white text-[#5856D6]',
    emerald: 'bg-[#34C759]/5 text-[#34C759]',
    rose: 'bg-[#FF3B30]/5 text-[#FF3B30]'
  };

  return (
    <Card hoverable className={`flex flex-col justify-between h-36 transition-all ${themes[color]}`}>
      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-[#86868B] shadow-inner border border-black/[0.04]">
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-[0.1em] text-[#86868B] mb-1.5">{label}</p>
        <p className="text-3xl font-black leading-none tracking-tighter">{value}</p>
      </div>
    </Card>
  );
};

const StatusBadge: React.FC<{ status: any }> = ({ status }) => {
  const statStr = String(status || '—');
  let style = "bg-[#F5F5F7] text-[#86868B] border-black/[0.04]";
  if (statStr.includes('1.')) style = "bg-[#FF9500]/10 text-[#FF9500] border-[#FF9500]/20";
  if (statStr.includes('2.')) style = "bg-[#FF9500]/10 text-[#FF9500] border-[#FF9500]/20";
  if (statStr.includes('3.')) style = "bg-[#007AFF]/10 text-[#007AFF] border-[#007AFF]/20";
  if (statStr.includes('4.')) style = "bg-[#5856D6]/10 text-[#5856D6] border-[#5856D6]/20";
  if (statStr === 'На складе' || statStr.includes('склад') || statStr.includes('COMPLETE') || statStr.includes('5.') || statStr.includes('6.') || statStr.includes('0. Дополнительное')) style = "bg-[#34C759]/10 text-[#34C759] border-[#34C759]/20";

  return (
    <span className={`inline-flex items-center px-2.5 py-1.5 rounded-xl border text-[9px] font-black uppercase tracking-wider ${style}`}>
      <div className={`w-1.5 h-1.5 rounded-full mr-1.5 ${
        statStr.includes('1') ? 'bg-[#FF9500]' : 
        statStr.includes('2') ? 'bg-[#FF9500]' : 
        statStr.includes('3') ? 'bg-[#007AFF]' : 
        statStr.includes('4') ? 'bg-[#5856D6]' : 
        statStr === '—' ? 'bg-[#C7C7CC]' :
        'bg-[#34C759]'
      }`} />
      {statStr === '—' ? 'Нет данных' : statStr}
    </span>
  );
};

export default SupplyRegistry;
