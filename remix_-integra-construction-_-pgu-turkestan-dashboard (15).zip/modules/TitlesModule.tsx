
import React, { useState, useMemo, useEffect } from 'react';
import { ProjectStatus, User, Title, UserRole, VolumeData } from '../types';
import { 
  AlertTriangle, 
  CheckCircle, 
  ChevronDown, 
  Clock, 
  Search, 
  Target,
  User as UserIcon,
  BadgeCheck,
  Edit2,
  Save,
  X,
  Filter,
  Layers,
  Calculator,
  Calendar,
  ChevronRight
} from 'lucide-react';
import Card from '../components/Card';

interface TitlesModuleProps {
  user: User;
  titles: Title[];
  onUpdateTitle: (updatedTitle: Title) => void;
}

const MANAGER_MAPPING = [
  { id: '1', name: 'Попивнухин Н.В.', titles: ['1.1', '1.2', '1.3', '4.1-4.2', '5.1-5.2', '5.3-5.4', '6.1-6.4', '23.1.1-23.1.2', '23.2', '23.3.1-23.3.2', '34'] },
  { id: '2', name: 'Махмудов Ю.С.', titles: ['8.1', '8.2', '12.1', '12.2', '12.3', '23.4', '24', '38', '39.1-39.4', '42', '43', '44', '45.1', '45.2', '46', '47.1', '47.2', '47.3', '48', '48.1-48.2', '49'] },
  { id: '3', name: 'Алдамуратов Р.И.', titles: ['2.1', '2.2', '3', '7.1', '7.2', '9', '10,11', '13.2-13.3', '13.4', '15.1', '15.2-15.3', '15.4-15.5', '16', '18', '19', '20.1-20.3', '21', '22.1-22.6', '23.5', '23.6.1-23.6.2', '23.7', '26.1-26.3', '27', '28', '29', '31', '32', '33.1-33.6', '35', '35.1', '36', '37', '41', '50', '51', '52'] },
  { id: '4', name: 'Абилькасимов Б.Ж.', titles: ['25', '30'] }
];

const TitlesModule: React.FC<TitlesModuleProps> = React.memo(({ user, titles, onUpdateTitle }) => {
  const [expandedTitleId, setExpandedTitleId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('Все статусы');
  const [managerFilter, setManagerFilter] = useState<string>('Все РП');
  const [sectionFilter, setSectionFilter] = useState<string>('Все разделы');
  const [searchQuery, setSearchQuery] = useState('');

  const titlesWithContext = useMemo(() => {
    return titles.map(t => {
      const mapping = MANAGER_MAPPING.find(m => 
        m.titles.includes(t.number) || 
        m.titles.some(mt => t.number === mt || t.number.startsWith(mt + '.'))
      );
      return {
        ...t,
        manager: t.manager || (mapping ? mapping.name : 'Не назначен'),
      };
    });
  }, [titles]);

  const managersList = useMemo(() => ['Все РП', ...MANAGER_MAPPING.map(m => m.name)], []);

  const filteredTitles = useMemo(() => {
    return titlesWithContext.filter(t => {
      const statusMatch = statusFilter === 'Все статусы' || t.status === statusFilter;
      const managerMatch = managerFilter === 'Все РП' || t.manager === managerFilter;
      let sectionMatch = true;
      if (sectionFilter === 'Железобетон (КЖ)') sectionMatch = !!(t.rc && t.rc.total > 0);
      else if (sectionFilter === 'Металлоконструкции (КМ)') sectionMatch = !!(t.sc && t.sc.total > 0);

      const searchMatch = !searchQuery || 
        t.name?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        t.number?.toLowerCase().includes(searchQuery.toLowerCase());
        
      return statusMatch && managerMatch && sectionMatch && searchMatch;
    });
  }, [titlesWithContext, statusFilter, managerFilter, sectionFilter, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 pb-12">
      
      {/* HEADER & FILTERS */}
      <Card className="p-6 border-none shadow-lg shadow-black/[0.03] bg-white/80 backdrop-blur-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#007AFF] rounded-2xl flex items-center justify-center shadow-lg shadow-[#007AFF]/20">
              <Layers size={24} className="text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-[#1D1D1F] tracking-tight">Реестр титулов</h1>
              <p className="text-xs font-medium text-[#86868B] mt-0.5 uppercase tracking-wider">Управление объемами и статусами объектов</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative group flex-1 sm:flex-none">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#86868B] group-focus-within:text-[#007AFF] transition-colors" />
              <input 
                type="text" 
                placeholder="Поиск..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-field w-full sm:w-64 pl-10"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <select value={sectionFilter} onChange={(e) => setSectionFilter(e.target.value)} className="select-field">
                <option>Все разделы</option>
                <option>Железобетон (КЖ)</option>
                <option>Металлоконструкции (КМ)</option>
              </select>
              <select value={managerFilter} onChange={(e) => setManagerFilter(e.target.value)} className="select-field">
                {managersList.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="select-field">
                <option>Все статусы</option>
                {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
        </div>
      </Card>

      {/* TITLES LIST */}
      <div className="space-y-4">
        {filteredTitles.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {filteredTitles.map((title) => (
              <TitleCard 
                key={title.id} 
                title={title} 
                isAdmin={user.role === UserRole.ADMIN}
                isOpen={expandedTitleId === title.id} 
                onToggle={() => setExpandedTitleId(expandedTitleId === title.id ? null : title.id)}
                onSave={onUpdateTitle}
              />
            ))}
          </div>
        ) : (
          <Card className="py-24 text-center border-dashed border-2 border-black/[0.04] bg-transparent shadow-none">
            <p className="text-sm font-semibold text-[#86868B] uppercase tracking-widest">Ничего не найдено</p>
          </Card>
        )}
      </div>
    </div>
  );
});

const TitleCard: React.FC<{ 
  title: Title; 
  isOpen: boolean; 
  isAdmin: boolean;
  onToggle: () => void;
  onSave: (title: Title) => void;
}> = ({ title, isOpen, isAdmin, onToggle, onSave }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState<Title>({...title});

  const getSectionProgress = (vol: VolumeData | undefined) => {
      if (!vol || vol.total === 0) return 0;
      return Math.min(100, Math.max(0, (vol.done / vol.total) * 100));
  };

  return (
    <Card className={`overflow-hidden transition-all duration-300 ${isOpen ? 'ring-2 ring-[#007AFF]/20 shadow-xl' : 'hover:shadow-lg'}`}>
      {/* CARD HEADER */}
      <div className="p-5 flex items-center justify-between cursor-pointer" onClick={onToggle}>
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-[#007AFF] rounded-2xl flex items-center justify-center text-white font-bold text-sm shadow-lg shadow-[#007AFF]/20">
            {title.number}
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[#1D1D1F]">{title.name}</h3>
            <div className="flex items-center gap-3 mt-1">
               <div className="flex items-center gap-1.5 px-2 py-0.5 bg-[#007AFF]/5 rounded-md">
                  <span className="text-[10px] font-bold text-[#007AFF]">КЖ</span>
                  <span className="text-[10px] font-bold text-[#1D1D1F]">{getSectionProgress(title.rc).toFixed(0)}%</span>
               </div>
               <div className="flex items-center gap-1.5 px-2 py-0.5 bg-[#FF9500]/5 rounded-md">
                  <span className="text-[10px] font-bold text-[#FF9500]">КМ</span>
                  <span className="text-[10px] font-bold text-[#1D1D1F]">{getSectionProgress(title.sc).toFixed(0)}%</span>
               </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <StatusBadge status={title.status} />
          <ChevronDown size={16} className={`text-[#C7C7CC] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </div>
      </div>

      {/* EXPANDED CONTENT */}
      {isOpen && (
        <div className="p-5 pt-0 border-t border-black/[0.04] animate-in slide-in-from-top-2 duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6">
            <VolumeDetail label="Железобетон (КЖ)" data={title.rc} unit="м3" color="blue" />
            <VolumeDetail label="Металлоконструкции (КМ)" data={title.sc} unit="тн" color="orange" />
          </div>
          <div className="mt-6 pt-6 border-t border-black/[0.04] flex items-center gap-3">
             <div className="w-10 h-10 rounded-full bg-[#F5F5F7] flex items-center justify-center text-[#86868B]">
                <UserIcon size={20} />
             </div>
             <span className="text-sm font-semibold text-[#1D1D1F]">{title.manager}</span>
          </div>
        </div>
      )}
    </Card>
  );
};

const VolumeDetail: React.FC<{ label: string; data?: VolumeData; unit: string; color: 'blue' | 'orange' }> = ({ label, data, unit, color }) => {
  const progress = data && data.total > 0 ? (data.done / data.total) * 100 : 0;
  const theme = color === 'blue' ? 'text-[#007AFF] bg-[#007AFF]' : 'text-[#FF9500] bg-[#FF9500]';
  
  return (
    <div className="bg-[#F5F5F7] p-4 rounded-2xl">
      <div className="flex justify-between mb-2">
        <span className="text-xs font-bold text-[#86868B] uppercase">{label}</span>
        <span className={`text-xs font-bold ${color === 'blue' ? 'text-[#007AFF]' : 'text-[#FF9500]'}`}>{progress.toFixed(0)}%</span>
      </div>
      <div className="flex items-baseline gap-2 mb-3">
        <span className="text-lg font-bold text-[#1D1D1F]">{data?.done.toLocaleString()}</span>
        <span className="text-xs text-[#86868B]">/ {data?.total.toLocaleString()} {unit}</span>
      </div>
      <div className="w-full h-1.5 bg-white rounded-full overflow-hidden">
        <div className={`h-full ${theme.replace('text-', 'bg-')}`} style={{width: `${progress}%`}}></div>
      </div>
    </div>
  );
};

const StatusBadge: React.FC<{ status: ProjectStatus | string }> = ({ status }) => {
  const styles: Record<string, string> = {
    [ProjectStatus.IN_SCHEDULE]: 'bg-emerald-50 text-emerald-600',
    [ProjectStatus.RISK]: 'bg-amber-50 text-amber-600',
    [ProjectStatus.DELAY]: 'bg-rose-50 text-rose-600',
    [ProjectStatus.COMPLETED]: 'bg-blue-50 text-blue-600',
  };
  return <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase ${styles[status] || 'bg-slate-50 text-slate-600'}`}>{status}</span>;
};

export default TitlesModule;
