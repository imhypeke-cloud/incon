import React, { useState, useMemo } from 'react';
import { Equipment, EquipmentCategory } from '../types';
import { 
  Truck, 
  Construction, 
  Search, 
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';
import Card from '../components/Card';

interface EquipmentModuleProps {
  data: Equipment[];
}

const EquipmentModule: React.FC<EquipmentModuleProps> = ({ data }) => {
  const [activeCategory, setActiveCategory] = useState<EquipmentCategory | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const stats = useMemo(() => {
    const safeData = Array.isArray(data) ? data : [];
    const total = safeData.reduce((acc, e) => acc + Number(e.total || 0), 0);
    const gen = safeData.reduce((acc, e) => acc + Number(e.genPodryad || 0), 0);
    const sub = safeData.reduce((acc, e) => acc + Number(e.subPodryad || 0), 0);
    return { total, gen, sub };
  }, [data]);

  const filteredData = useMemo(() => {
    const safeData = Array.isArray(data) ? data : [];
    return safeData.filter(e => {
      const catMatch = activeCategory === 'ALL' || e.category === activeCategory;
      const searchMatch = !searchQuery || 
        e.type?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        e.model?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        e.plateNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.operator?.toLowerCase().includes(searchQuery.toLowerCase());
      return catMatch && searchMatch;
    });
  }, [data, activeCategory, searchQuery]);

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-[#007AFF] text-white rounded-xl flex items-center justify-center shadow-lg shadow-[#007AFF]/20">
            <Truck size={20} />
          </div>
          <div>
            <h2 className="text-headline text-[#1D1D1F] uppercase tracking-tight leading-none">Техника</h2>
            <p className="text-caption-2 text-[#86868B] font-black uppercase tracking-widest mt-1">
              Управление парком и мониторинг ресурсов
            </p>
          </div>
        </div>
      </div>

      {/* Сводная статистика */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          icon={<Truck size={24} />} 
          label="Всего техники" 
          value={stats.total} 
          color="slate" 
        />
        <StatCard 
          icon={<ShieldCheck size={24} />} 
          label="Генподряд (Integra)" 
          value={stats.gen} 
          color="blue" 
        />
        <StatCard 
          icon={<Zap size={24} />} 
          label="Субподрядчики" 
          value={stats.sub} 
          color="orange" 
        />
      </div>

      {/* Панель инструментов */}
      <Card className="flex flex-col lg:flex-row items-center justify-between gap-6">
        <div className="flex flex-wrap items-center gap-2">
          <button 
            onClick={() => setActiveCategory('ALL')}
            className={`px-4 py-2 rounded-xl text-caption-2 font-black uppercase tracking-widest transition-all ${
              activeCategory === 'ALL' ? 'bg-[#1D1D1F] text-white shadow-lg shadow-black/10' : 'bg-[#F5F5F7] text-[#86868B] hover:bg-[#E5E5EA]'
            }`}
          >
            Все
          </button>
          {Object.values(EquipmentCategory).map(cat => (
            <button 
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-caption-2 font-black uppercase tracking-widest transition-all ${
                activeCategory === cat ? 'bg-[#007AFF] text-white shadow-lg shadow-[#007AFF]/20' : 'bg-[#F5F5F7] text-[#86868B] hover:bg-[#E5E5EA]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center space-x-3 w-full lg:w-auto">
          <div className="relative flex-1 lg:w-72 group">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#C7C7CC] group-focus-within:text-[#007AFF] transition-colors" size={16} />
            <input 
              type="text" 
              placeholder="ПОИСК ПО МОДЕЛИ, НОМЕРУ..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field w-full pl-11"
            />
          </div>
        </div>
      </Card>

      {/* Основной контент (Только таблица) */}
      <Card padding="none" className="overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead>
              <tr className="bg-[#F5F5F7] text-caption-2 font-black uppercase text-[#86868B] tracking-widest border-b border-black/[0.04]">
                <th className="px-6 py-5">Тип / Модель</th>
                <th className="px-6 py-5 text-center">Кол-во</th>
                <th className="px-6 py-5">Водитель / Оператор</th>
                <th className="px-6 py-5">Собственник</th>
                <th className="px-6 py-5">Категория</th>
                <th className="px-6 py-5 text-center">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/[0.02]">
              {filteredData.map(e => (
                <tr key={e.id} className="hover:bg-[#F5F5F7]/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-sm ${e.ownerType === 'GEN' ? 'bg-[#007AFF]/5 text-[#007AFF] border border-[#007AFF]/10' : 'bg-[#FF9500]/5 text-[#FF9500] border border-[#FF9500]/10'}`}>
                        {getCategoryIcon(e.category)}
                      </div>
                      <div>
                        <p className="text-headline text-[#1D1D1F] uppercase tracking-tight leading-none">{e.type}</p>
                        <p className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest mt-1">{e.model}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-caption-1 font-black bg-[#F5F5F7] px-3 py-1 rounded-lg text-[#1D1D1F] border border-black/[0.04] uppercase tracking-tight">
                      {e.total} ед.
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-callout font-black text-[#1D1D1F] uppercase tracking-tight">{e.operator}</span>
                      <span className="text-caption-2 text-[#007AFF] font-black tracking-widest mt-0.5">{e.phone}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                      <span className={`w-2 h-2 rounded-full ${e.ownerType === 'GEN' ? 'bg-[#007AFF]' : 'bg-[#FF9500]'}`} />
                      <span className="text-caption-1 font-black text-[#1D1D1F] uppercase tracking-tight">{e.ownerName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest bg-[#F5F5F7] px-2.5 py-1 rounded-lg border border-black/[0.02]">
                      {e.category}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center">
                      <span className="flex items-center space-x-2 px-3 py-1.5 bg-[#34C759]/10 text-[#34C759] rounded-full text-caption-2 font-black uppercase tracking-widest border border-[#34C759]/20">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#34C759] animate-pulse" />
                        <span>Работа</span>
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: number; color: string }> = ({ icon, label, value, color }) => {
  const styles: any = {
    slate: 'bg-[#1D1D1F] text-white',
    blue: 'bg-white text-[#1D1D1F]',
    orange: 'bg-white text-[#1D1D1F]'
  };
  const iconColors: any = {
    slate: 'bg-white/10 text-[#007AFF]',
    blue: 'bg-[#007AFF]/5 text-[#007AFF]',
    orange: 'bg-[#FF9500]/5 text-[#FF9500]'
  };

  return (
    <Card hoverable className={`flex items-center justify-between transition-all duration-300 ${styles[color]}`}>
      <div className="flex items-center space-x-5">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm ${iconColors[color]}`}>
          {icon}
        </div>
        <div>
          <p className={`text-caption-2 font-black uppercase tracking-widest leading-none mb-2 ${color === 'slate' ? 'text-[#86868B]' : 'text-[#86868B]'}`}>
            {label}
          </p>
          <p className="text-title-1 leading-none tracking-tight font-black">{value}</p>
        </div>
      </div>
    </Card>
  );
};

const getCategoryIcon = (cat: EquipmentCategory) => {
  switch (cat) {
    case EquipmentCategory.TRUCKS: return <Truck size={20} />;
    case EquipmentCategory.LIFTING: return <Construction size={20} />;
    case EquipmentCategory.EARTHMOVING: return <Construction size={20} />;
    case EquipmentCategory.ROAD: return <Construction size={20} />;
    case EquipmentCategory.TRANSPORT: return <Truck size={20} />;
    default: return <Info size={20} />;
  }
};

export default EquipmentModule;