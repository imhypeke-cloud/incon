
import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';
import { AlertCircle, TrendingUp, Zap, ChevronRight, CheckCircle2, Clock } from 'lucide-react';
import Card from '../components/Card';
import { ListGroup, ListItem } from '../components/ListGroup';

const WeeklyPlan: React.FC = () => {
  const planFactData = [
    { name: 'Неделя 1', план: 25, факт: 22 },
    { name: 'Неделя 2', план: 30, факт: 28 },
    { name: 'Неделя 3', план: 28, факт: 31 },
    { name: 'Неделя 4', план: 35, факт: 20 },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-10">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 flex flex-col">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-headline text-[#1D1D1F] uppercase tracking-tight">Сводный План/Факт (Месяц)</h3>
            <div className="flex space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-[#007AFF] rounded-sm"></div>
                <span className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest">План</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-[#FF9500] rounded-sm"></div>
                <span className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest">Факт</span>
              </div>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={planFactData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F5F5F7" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#86868B', fontSize: 10, fontWeight: 900 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#86868B', fontSize: 10, fontWeight: 900 }}
                />
                <Tooltip 
                  cursor={{ fill: '#F5F5F7' }}
                  contentStyle={{ 
                    backgroundColor: '#1D1D1F', 
                    border: 'none', 
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                    fontWeight: '900',
                    textTransform: 'uppercase'
                  }}
                />
                <Bar dataKey="план" fill="#007AFF" radius={[4, 4, 0, 0]} barSize={40} />
                <Bar dataKey="факт" fill="#FF9500" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="flex flex-col">
          <h3 className="text-headline text-[#1D1D1F] uppercase tracking-tight mb-8 flex items-center">
            <Zap size={20} className="text-[#FF9500] mr-2" />
            Приоритизация работ
          </h3>
          <div className="space-y-4">
            <PriorityTask label="Котлован БНС" priority="Высокий" color="rose" />
            <PriorityTask label="Бетонирование 00-КЖ" priority="Критический" color="rose" />
            <PriorityTask label="Монтаж опор под ГТУ" priority="Средний" color="blue" />
            <PriorityTask label="Временные дороги" priority="Низкий" color="slate" />
          </div>
          <div className="mt-8 pt-8 border-t border-black/[0.04]">
             <h4 className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest mb-4">Рейтинг РП по выполнению</h4>
             <div className="space-y-4">
               <ManagerRank name="Иванов И." progress={98} />
               <ManagerRank name="Петров А." progress={92} />
               <ManagerRank name="Сидоров К." progress={74} />
             </div>
          </div>
        </Card>
      </div>

      <Card padding="none" className="overflow-hidden border-[#FF3B30]/20">
        <div className="bg-[#FF3B30]/5 p-6 flex items-center justify-between border-b border-[#FF3B30]/10">
          <div className="flex items-center space-x-3">
            <AlertCircle className="text-[#FF3B30]" size={24} />
            <h3 className="text-headline text-[#1D1D1F] uppercase tracking-tight">Реестр проблемных вопросов и рисков</h3>
          </div>
          <button className="btn-primary bg-[#FF3B30] hover:bg-[#D70015] shadow-[#FF3B30]/20 uppercase tracking-widest text-caption-2">
            Подробнее в реестре
          </button>
        </div>
        <ListGroup>
          <ListItem className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="font-black text-[#1D1D1F] text-callout uppercase tracking-tight col-span-1 md:col-span-1">Задержка поставки арматуры (12мм)</div>
            <div className="text-[#86868B] italic text-caption-1 col-span-1 md:col-span-1">Переброска с другого участка, ускорение логистики</div>
            <div className="font-black text-[#FF3B30] text-caption-1 underline underline-offset-4 col-span-1 md:col-span-1">20.05.2025</div>
            <div className="text-[#1D1D1F] font-black text-caption-2 uppercase tracking-widest col-span-1 md:col-span-1">ОМТС / Иванов</div>
          </ListItem>
          <ListItem className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="font-black text-[#1D1D1F] text-callout uppercase tracking-tight col-span-1 md:col-span-1">Отставание по монтажу металлоконструкций</div>
            <div className="text-[#86868B] italic text-caption-1 col-span-1 md:col-span-1">Увеличение сменности (2/2), мобилизация доп. крана</div>
            <div className="font-black text-[#86868B] text-caption-1 col-span-1 md:col-span-1">25.05.2025</div>
            <div className="text-[#1D1D1F] font-black text-caption-2 uppercase tracking-widest col-span-1 md:col-span-1">Субподрядчик / Петров</div>
          </ListItem>
        </ListGroup>
      </Card>
    </div>
  );
};

const PriorityTask: React.FC<{ label: string; priority: string; color: string }> = ({ label, priority, color }) => (
  <div className={`p-4 rounded-2xl border flex items-center justify-between transition-all hover:shadow-lg hover:shadow-black/5 ${
    color === 'rose' ? 'bg-[#FF3B30]/5 border-[#FF3B30]/10 text-[#FF3B30]' :
    color === 'blue' ? 'bg-[#007AFF]/5 border-[#007AFF]/10 text-[#007AFF]' :
    'bg-[#F5F5F7] border-black/[0.04] text-[#1D1D1F]'
  }`}>
    <span className="text-caption-1 font-black uppercase tracking-tight">{label}</span>
    <span className={`text-caption-2 font-black uppercase px-3 py-1 rounded-full ${
      color === 'rose' ? 'bg-[#FF3B30] text-white' :
      color === 'blue' ? 'bg-[#007AFF] text-white' :
      'bg-[#1D1D1F] text-white'
    }`}>{priority}</span>
  </div>
);

const ManagerRank: React.FC<{ name: string; progress: number }> = ({ name, progress }) => (
  <div className="flex items-center space-x-4">
    <span className="text-caption-2 font-black text-[#1D1D1F] uppercase tracking-widest w-20 truncate">{name}</span>
    <div className="flex-1 bg-[#F5F5F7] h-2 rounded-full overflow-hidden border border-black/[0.04]">
      <div 
        className={`h-full rounded-full transition-all duration-1000 ${progress > 90 ? 'bg-[#34C759]' : progress > 80 ? 'bg-[#007AFF]' : 'bg-[#FF3B30]'}`} 
        style={{ width: `${progress}%` }}
      />
    </div>
    <span className="text-caption-2 font-black text-[#1D1D1F] w-10 text-right">{progress}%</span>
  </div>
);

export default WeeklyPlan;
