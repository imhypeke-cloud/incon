
import React, { useState, useMemo, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  ChevronDown, 
  Download, 
  Activity, 
  Plus, 
  Calculator,
  Sigma,
  Hammer
} from 'lucide-react';
import { useData } from '../services/DataContext';
import Card from '../components/Card';

interface MonthlyPlanProps {
  isReadOnly?: boolean;
}

const MonthlyPlan: React.FC<MonthlyPlanProps> = ({ isReadOnly = false }) => {
  const { monthlyPlanData } = useData();
  const [selectedMonth, setSelectedMonth] = useState<string>('');
  
  const [expandedManagers, setExpandedManagers] = useState<string[]>([
    'Попивнухин Н.В.', 'Махмудов Ю.С.', 'Алдамуратов Р.И.', 'Абилькасимов Б.Ж.', 'Тлеулесов К.К.', 'Рахматулла А.'
  ]);

  // Ensure selectedMonth defaults to the latest available month if not set
  useEffect(() => {
    const availableMonths = Object.keys(monthlyPlanData);
    if (availableMonths.length > 0 && !selectedMonth) {
        // Sort months? For now, just pick the last one added or default 'Февраль 2026'
        setSelectedMonth(availableMonths.includes('Февраль 2026') ? 'Февраль 2026' : availableMonths[availableMonths.length - 1]);
    }
  }, [monthlyPlanData, selectedMonth]);

  const currentMonthPlans = useMemo(() => monthlyPlanData[selectedMonth] || [], [monthlyPlanData, selectedMonth]);

  const toggleManager = (name: string) => {
    setExpandedManagers(prev => prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]);
  };

  // Helper to categorize work type from name
  const detectWorkCategory = (name: string): string => {
    const lower = name?.toLowerCase() || '';
    if (lower.includes('бетонирование')) return 'Бетонирование';
    if (lower.includes('засыпка')) return 'Обратная засыпка';
    if (lower.includes('монтаж мк') || lower.includes('монтаж м/к')) return 'Монтаж металлоконструкций';
    if (lower.includes('сэндвич')) return 'Монтаж сэндвич-панелей';
    if (lower.includes('профлист') || lower.includes('профнастил')) return 'Монтаж профлиста';
    if (lower.includes('кровл')) return 'Кровельные работы';
    if (lower.includes('гидроиз')) return 'Гидроизоляция';
    if (lower.includes('цоколь')) return 'Монтаж цокольных панелей';
    if (lower.includes('рельс')) return 'Устройство рельсовых путей';
    if (lower.includes('трубопровод')) return 'Прокладка трубопроводов';
    if (lower.includes('гтг') || lower.includes('турбин') || lower.includes('генератор')) return 'Монтаж оборудования (ГТГ/ПТ)';
    if (lower.includes('электр') || lower.includes('кабель') || lower.includes('заземлен')) return 'Электромонтажные работы';
    return 'Прочие работы';
  };

  // Helper to calculate totals by work type for a specific manager
  const getManagerTotals = (manager: any) => {
    const totals: Record<string, { plan: number, fact: number, unit: string }> = {};
    
    manager.titles.forEach((t: any) => {
      t.projects.forEach((p: any) => {
        const category = detectWorkCategory(p.name);
        
        if (!totals[category]) {
          totals[category] = { plan: 0, fact: 0, unit: p.unit };
        }
        
        totals[category].plan += p.monthlyPlan;
        totals[category].fact += p.fact;
        if (p.unit && p.unit !== totals[category].unit) totals[category].unit = p.unit;
      });
    });
    
    return totals;
  };

  // Week Color Styles - BRIGHT COLORS
  const weekStyles = {
    n1: { bgHeader: 'bg-slate-200 text-slate-800', bgCell: 'bg-slate-100' },
    n2: { bgHeader: 'bg-cyan-200 text-cyan-900', bgCell: 'bg-cyan-100' },
    n3: { bgHeader: 'bg-violet-200 text-violet-900', bgCell: 'bg-violet-100' },
    n4: { bgHeader: 'bg-orange-200 text-orange-900', bgCell: 'bg-orange-100' },
  };

  // Dynamic Week Headers based on Month
  const getWeekHeaders = (month: string) => {
    if (month.includes('Январь 2026')) return ['05.01 - 11.01', '12.01 - 18.01', '19.01 - 25.01', '26.01 - 01.02'];
    if (month.includes('Февраль 2026')) return ['02.02 - 08.02', '09.02 - 15.02', '16.02 - 22.02', '22.02 - 28.02'];
    // Generic fallback
    return ['Неделя 1', 'Неделя 2', 'Неделя 3', 'Неделя 4'];
  }

  const weekHeaders = getWeekHeaders(selectedMonth);

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-10">
      
      {/* HEADER CONTROLS */}
      <Card className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-[#007AFF] text-white rounded-xl flex items-center justify-center shadow-lg"><Activity size={20} /></div>
          <div>
            <h2 className="text-headline text-[#1D1D1F] uppercase tracking-tight leading-none">План работы (Факт/План)</h2>
            <div className="flex items-center mt-1">
              <select 
                value={selectedMonth} 
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="select-field"
              >
                {Object.keys(monthlyPlanData).map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
          </div>
        </div>
        
        <div className="flex space-x-2">
           {!isReadOnly && (
             <button className="btn-secondary border-none bg-[#F5F5F7] text-[#86868B] hover:bg-[#E5E5EA] uppercase tracking-widest text-caption-2 h-[36px] px-4">
               <Plus size={12} className="mr-2" /> 
               <span>Новый план</span>
             </button>
           )}
           <button className="btn-primary bg-[#1D1D1F] hover:bg-black shadow-black/10 uppercase tracking-widest text-caption-2 h-[36px] px-4 rounded-xl">
             <Download size={12} className="mr-2" /> 
             <span>Экспорт</span>
           </button>
        </div>
      </Card>

      {/* DETAILED TABLE */}
      <div className="space-y-6">
        {currentMonthPlans.length === 0 ? (
           <Card className="p-12 text-center border-dashed border-black/[0.08] text-[#C7C7CC] font-black uppercase text-caption-1">
              Нет данных для выбранного периода
           </Card>
        ) : currentMonthPlans.map((manager) => {
          const isExpanded = expandedManagers.includes(manager.name);
          const totals = getManagerTotals(manager);

          return (
            <Card key={manager.name} padding="none" className="overflow-hidden">
              <div 
                onClick={() => toggleManager(manager.name)}
                className={`px-6 py-6 flex items-center justify-between cursor-pointer transition-colors ${isExpanded ? 'bg-[#F5F5F7] border-b border-black/[0.04]' : 'bg-white hover:bg-[#F5F5F7]'}`}
              >
                 <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#1D1D1F] text-white flex items-center justify-center font-black text-caption-1">
                       {manager.name.charAt(0)}
                    </div>
                    <span className="text-headline text-[#1D1D1F] uppercase tracking-tight">{manager.name}</span>
                 </div>
                 <ChevronDown size={20} className={`text-[#C7C7CC] transition-transform ${isExpanded ? 'rotate-180' : ''}`}/>
              </div>

              {isExpanded && (
                <div className="animate-in fade-in duration-300">
                  
                  {/* MANAGER TOTALS SUMMARY BY WORK TYPE */}
                  <div className="bg-gradient-to-r from-[#F5F5F7] to-white border-b border-black/[0.04] p-6">
                     <h4 className="flex items-center gap-2 text-caption-1 font-black uppercase text-[#86868B] mb-3 tracking-widest">
                       <Hammer size={14} className="text-[#007AFF]"/>
                       ИТОГО ПО ВИДАМ РАБОТ:
                     </h4>
                     <div className="flex flex-wrap gap-6">
                        {Object.entries(totals).map(([category, val]) => (
                           <div key={category} className="flex flex-col bg-white border border-black/[0.04] rounded-xl px-4 py-2.5 shadow-sm min-w-[180px] hover:shadow-md transition-all">
                              <span className="text-caption-2 font-black text-[#86868B] uppercase tracking-tight mb-2 truncate" title={category}>{category}</span>
                              <div className="flex items-center justify-between gap-3 text-caption-1">
                                 <div className="flex flex-col">
                                    <span className="text-caption-2 text-[#007AFF] font-black uppercase">План</span>
                                    <span className="font-black text-[#1D1D1F]">{val.plan.toLocaleString(undefined, {maximumFractionDigits: 1})} <span className="text-[9px] text-[#C7C7CC] font-normal">{val.unit}</span></span>
                                 </div>
                                 <div className="h-6 w-px bg-black/[0.04]"></div>
                                 <div className="flex flex-col items-end">
                                    <span className="text-caption-2 text-[#34C759] font-black uppercase">Факт</span>
                                    <span className="font-black text-[#1D1D1F]">{val.fact.toLocaleString(undefined, {maximumFractionDigits: 1})} <span className="text-[9px] text-[#C7C7CC] font-normal">{val.unit}</span></span>
                                 </div>
                              </div>
                           </div>
                        ))}
                     </div>
                  </div>

                  <div className="overflow-x-auto custom-scrollbar">
                    <table className="w-full text-left border-collapse min-w-[1400px]">
                      <thead>
                        <tr className="bg-[#F5F5F7] text-caption-1 font-black uppercase text-[#86868B] tracking-widest border-b border-black/[0.04]">
                          <th className="py-4 px-4 w-16 bg-white sticky left-0 z-10">Титул</th>
                          <th className="py-4 px-4 min-w-[200px] bg-white sticky left-16 z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]">Наименование работ</th>
                          <th className="py-4 px-4 text-center">Ед.</th>
                          
                          {/* New Columns */}
                          <th className="py-4 px-4 text-center text-[#1D1D1F] border-l border-black/[0.04]">Срок ГПР</th>
                          <th className="py-4 px-4 text-center text-[#1D1D1F]">Всего</th>
                          <th className="py-4 px-4 text-center text-[#1D1D1F] border-r border-black/[0.04]">Остаток</th>

                          <th className="py-4 px-4 text-center bg-[#007AFF]/5 text-[#007AFF]">План мес.</th>
                          <th className="py-4 px-4 text-center bg-[#34C759]/5 text-[#34C759]">Факт мес.</th>
                          <th className="py-4 px-4 text-center text-[#1D1D1F] border-r border-black/[0.04]">Откл.</th>
                          
                          {/* DYNAMIC WEEKS HEADER */}
                          <th className={`py-2 px-2 text-center border-r border-black/[0.04] ${weekStyles.n1.bgHeader}`} colSpan={2}>{weekHeaders[0]}</th>
                          <th className={`py-2 px-2 text-center border-r border-black/[0.04] ${weekStyles.n2.bgHeader}`} colSpan={2}>{weekHeaders[1]}</th>
                          <th className={`py-2 px-2 text-center border-r border-black/[0.04] ${weekStyles.n3.bgHeader}`} colSpan={2}>{weekHeaders[2]}</th>
                          <th className={`py-2 px-2 text-center ${weekStyles.n4.bgHeader}`} colSpan={2}>{weekHeaders[3]}</th>
                        </tr>
                        
                        <tr className="bg-[#F5F5F7] text-caption-2 font-black uppercase text-[#86868B] tracking-widest border-b border-black/[0.04]">
                          <th colSpan={9} className="bg-white sticky left-0 z-10 border-r border-black/[0.04] shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]"></th>
                          {/* Week 1 Sub-header */}
                          <th className={`pb-2 text-center text-[#1D1D1F] ${weekStyles.n1.bgHeader}`}>План</th>
                          <th className={`pb-2 text-center text-[#1D1D1F] border-r border-black/[0.08] ${weekStyles.n1.bgHeader}`}>Факт</th>
                          
                          {/* Week 2 Sub-header */}
                          <th className={`pb-2 text-center text-[#007AFF] ${weekStyles.n2.bgHeader}`}>План</th>
                          <th className={`pb-2 text-center text-[#007AFF] border-r border-[#007AFF]/20 ${weekStyles.n2.bgHeader}`}>Факт</th>
                          
                          {/* Week 3 Sub-header */}
                          <th className={`pb-2 text-center text-[#5856D6] ${weekStyles.n3.bgHeader}`}>План</th>
                          <th className={`pb-2 text-center text-[#5856D6] border-r border-[#5856D6]/20 ${weekStyles.n3.bgHeader}`}>Факт</th>
                          
                          {/* Week 4 Sub-header */}
                          <th className={`pb-2 text-center text-[#FF9500] ${weekStyles.n4.bgHeader}`}>План</th>
                          <th className={`pb-2 text-center text-[#FF9500] ${weekStyles.n4.bgHeader}`}>Факт</th>
                        </tr>
                      </thead>
                      
                      <tbody className="text-callout font-bold text-[#1D1D1F] divide-y divide-black/[0.04]">
                        {manager.titles.map((t: any) => (
                          t.projects.map((p: any, idx: number) => (
                            <tr key={p.id} className="hover:bg-[#007AFF]/5 transition-colors group">
                              <td className="py-3 px-4 font-black text-[#1D1D1F] sticky left-0 bg-white group-hover:bg-[#F5F5F7] z-10 text-caption-1 w-16">{idx === 0 ? t.id : ''}</td>
                              <td className="py-3 px-4 sticky left-16 bg-white group-hover:bg-[#F5F5F7] z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)] min-w-[200px]">
                                 <div className="font-black text-[#1D1D1F] line-clamp-2 leading-tight" title={p.name}>{p.name}</div>
                                 <span className="text-caption-2 text-[#86868B] uppercase font-black bg-[#F5F5F7] px-1.5 py-0.5 rounded border border-black/[0.04]">{p.section}</span>
                              </td>
                              <td className="py-3 px-4 text-center uppercase text-caption-2 font-black text-[#86868B]">{p.unit}</td>
                              
                              {/* New Data Columns */}
                              <td className="py-3 px-4 text-center text-caption-1 font-bold text-[#86868B] border-l border-black/[0.04] whitespace-nowrap">
                                 {p.completionDate || '-'}
                              </td>
                              <td className="py-3 px-4 text-center text-caption-1 font-black text-[#1D1D1F]">
                                 {p.projectTotal?.toLocaleString() || '-'}
                              </td>
                              <td className="py-3 px-4 text-center text-caption-1 font-black text-[#86868B] border-r border-black/[0.04]">
                                 {p.projectResidue?.toLocaleString() || '-'}
                              </td>

                              {/* MONTH TOTALS */}
                              <td className="py-3 px-4 text-center font-black bg-[#007AFF]/5 text-[#007AFF]">{p.monthlyPlan}</td>
                              <td className="py-3 px-4 text-center font-black bg-[#34C759]/5 text-[#34C759]">{p.fact}</td>
                              <td className={`py-3 px-4 text-center font-black border-r border-black/[0.04] ${p.deviation < 0 ? 'text-[#FF3B30]' : 'text-[#34C759]'}`}>
                                 {p.deviation > 0 ? '+' : ''}{Number(p.deviation.toFixed(2))}
                              </td>

                              {/* WEEKS DATA WITH BRIGHT BACKGROUNDS */}
                              <td className={`py-3 px-2 text-center text-[#86868B] ${weekStyles.n1.bgCell}`}>{p.weeks.n1.plan}</td>
                              <td className={`py-3 px-2 text-center font-black border-r border-black/[0.08] ${weekStyles.n1.bgCell} ${p.weeks.n1.fact < p.weeks.n1.plan ? 'text-[#FF3B30]' : 'text-[#34C759]'}`}>{p.weeks.n1.fact}</td>

                              <td className={`py-3 px-2 text-center text-[#86868B] ${weekStyles.n2.bgCell}`}>{p.weeks.n2.plan}</td>
                              <td className={`py-3 px-2 text-center font-black border-r border-[#007AFF]/20 ${weekStyles.n2.bgCell} ${p.weeks.n2.fact < p.weeks.n2.plan ? 'text-[#FF3B30]' : 'text-[#34C759]'}`}>{p.weeks.n2.fact}</td>

                              <td className={`py-3 px-2 text-center text-[#86868B] ${weekStyles.n3.bgCell}`}>{p.weeks.n3.plan}</td>
                              <td className={`py-3 px-2 text-center font-black border-r border-[#5856D6]/20 ${weekStyles.n3.bgCell} ${p.weeks.n3.fact < p.weeks.n3.plan ? 'text-[#FF3B30]' : 'text-[#34C759]'}`}>{p.weeks.n3.fact}</td>

                              <td className={`py-3 px-2 text-center text-[#86868B] ${weekStyles.n4.bgCell}`}>{p.weeks.n4.plan}</td>
                              <td className={`py-3 px-2 text-center font-black ${weekStyles.n4.bgCell} ${p.weeks.n4.fact < p.weeks.n4.plan ? 'text-[#FF3B30]' : 'text-[#34C759]'}`}>{p.weeks.n4.fact}</td>
                            </tr>
                          ))
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default MonthlyPlan;
