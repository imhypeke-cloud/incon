import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { Upload, FileSpreadsheet, AlertCircle, Download, Calendar, Trash2 } from 'lucide-react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { INITIAL_EXECUTION_SUMMARY_DATA, INITIAL_EXECUTION_KPIS, DATA_VERSION } from '../constants';
import Card from '../components/Card';

interface ExecutionRow {
  id: string;
  no: string;
  name: string;
  unit: string;
  
  // General
  totalVolume: number;
  displayTotal?: string;
  done: number;
  displayDone?: string;
  remainder: number;
  displayRemainder?: string;
  
  // BAZIS / Others
  bazisFact: number;
  bazisPercent: number;
  
  // INTEGRA
  integraFact: number;
  displayIntegraFact?: string;
  integraPercent: number;
  integraRemainder: number;
  integraRemainderPercent: number;
  
  // Progress
  progress: number;
  
  isSection: boolean;
  level: number;
}

interface KPI {
  title: string;
  value: number;
  percent: number;
  unit: string;
}

const ExecutionSummary: React.FC = () => {
  const [data, setData] = useState<ExecutionRow[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileDate, setFileDate] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [kpis, setKpis] = useState<{
    concrete: KPI;
    metal: KPI;
    sandwich: KPI;
  } | null>(null);

  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);

  const handleDelete = () => {
    setData([]);
    setFileName(null);
    setFileDate(null);
    setKpis(null);
    localStorage.removeItem('execution_summary_data');
    localStorage.removeItem('execution_summary_filename');
    localStorage.removeItem('execution_summary_date');
    localStorage.removeItem('execution_summary_kpis');
    setIsConfirmingDelete(false);
  };

  useEffect(() => {
    const savedVersion = localStorage.getItem('execution_summary_version');
    const savedData = localStorage.getItem('execution_summary_data');
    const savedFileName = localStorage.getItem('execution_summary_filename');
    const savedFileDate = localStorage.getItem('execution_summary_date');
    const savedKpis = localStorage.getItem('execution_summary_kpis');

    // Check version to invalidate old data
    if (savedVersion !== DATA_VERSION) {
      setData(INITIAL_EXECUTION_SUMMARY_DATA);
      setKpis(INITIAL_EXECUTION_KPIS);
      setFileDate('10.03.2026'); // Updated date
      localStorage.setItem('execution_summary_version', DATA_VERSION);
      localStorage.removeItem('execution_summary_data');
      localStorage.removeItem('execution_summary_kpis');
    } else {
      if (savedData) {
        try {
          setData(JSON.parse(savedData));
        } catch (e) {
          console.error("Failed to parse saved data", e);
          setData(INITIAL_EXECUTION_SUMMARY_DATA);
        }
      } else {
        setData(INITIAL_EXECUTION_SUMMARY_DATA);
      }

      if (savedFileName) setFileName(savedFileName);
      
      if (savedFileDate) {
        setFileDate(savedFileDate);
      } else {
        setFileDate('10.03.2026');
      }

      if (savedKpis) {
        try {
          setKpis(JSON.parse(savedKpis));
        } catch (e) {
          setKpis(INITIAL_EXECUTION_KPIS);
        }
      } else {
        setKpis(INITIAL_EXECUTION_KPIS);
      }
    }
  }, []);

  const parseDate = (cell: any): string | null => {
    if (!cell) return null;
    // Try to parse date string or Excel serial date
    if (typeof cell === 'number') {
      const date = new Date(Math.round((cell - 25569) * 86400 * 1000));
      return date.toLocaleDateString('ru-RU');
    }
    if (typeof cell === 'string') {
      // Look for date pattern dd.mm.yyyy
      const match = cell.match(/(\d{2})\.(\d{2})\.(\d{4})/);
      if (match) return match[0];
    }
    return null;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const rawData = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];

        if (rawData.length < 2) {
          setError("Файл пуст или имеет неверный формат");
          return;
        }

        // 1. Extract Date (look in first 5 rows)
        let extractedDate = new Date().toLocaleDateString('ru-RU');
        for (let i = 0; i < Math.min(5, rawData.length); i++) {
          const rowStr = rawData[i].join(' ');
          const date = parseDate(rowStr);
          if (date) {
            extractedDate = date;
            break;
          }
          // Also check individual cells
          for (const cell of rawData[i]) {
            const d = parseDate(cell);
            if (d) {
              extractedDate = d;
              break;
            }
          }
        }

        // 2. Find Header Row
        let headerRowIndex = -1;
        for (let i = 0; i < Math.min(20, rawData.length); i++) {
          const row = rawData[i].map(c => String(c || '').toLowerCase());
          if (row.some(c => c.includes('наименование') || c.includes('name'))) {
            headerRowIndex = i;
            break;
          }
        }

        if (headerRowIndex === -1) {
          setError("Не удалось найти заголовок таблицы (ищите 'Наименование')");
          return;
        }

        const headers = rawData[headerRowIndex].map(h => String(h || '').trim().toLowerCase());
        
        // 3. Map Columns
        const colMap = {
          no: headers.findIndex(h => h.includes('№') || h.includes('no')),
          name: headers.findIndex(h => h.includes('наименование') || h.includes('name')),
          unit: headers.findIndex(h => h.includes('ед.') || h.includes('unit')),
        };

        // Advanced Column Mapping using Group Headers
        const groupRow = headerRowIndex > 0 ? rawData[headerRowIndex - 1].map(c => String(c || '').toLowerCase()) : [];
        
        // Helper to find column index within a group or globally
        const findCol = (keywords: string[], groupKeywords: string[] = []) => {
          for (let i = 0; i < headers.length; i++) {
            const h = headers[i];
            // Check current column header
            if (keywords.some(k => h.includes(k))) {
               // If no group constraint, return found index
               if (groupKeywords.length === 0) return i;

               // Check group constraint (look in current col or previous cols for merged cells)
               let activeGroup = '';
               // Scan backwards from i to 0 in groupRow to find the nearest non-empty group header
               for (let j = i; j >= 0; j--) {
                 if (groupRow[j] && groupRow[j].trim() !== '') {
                   activeGroup = groupRow[j];
                   break;
                 }
               }
               
               if (groupKeywords.some(gk => activeGroup.includes(gk))) {
                 return i;
               }
            }
          }
          return -1;
        };

        const idxTotal = findCol(['объем', 'общ', 'total', 'план'], ['общ', 'general']);
        const idxDone = findCol(['выполнено', 'done'], ['общ', 'general']);
        const idxRemainder = findCol(['остаток', 'remainder'], ['общ', 'general']);
        
        // Integra - explicitly look for "Integra" in group header and "выполнено" or "fact" or just the column under Integra
        // Sometimes the header under Integra is just "Integra Construction" if it's a single column, or "Выполнено" under "Integra" group.
        // Let's try to find a column that has 'integra' in the header OR is under 'integra' group.
        let idxIntegraFact = findCol(['integra', 'интегра']); 
        if (idxIntegraFact === -1) {
            idxIntegraFact = findCol(['выполнено', 'факт', 'done'], ['integra', 'интегра']);
        }
        
        const idxIntegraRemainder = findCol(['остаток', 'remainder'], ['integra', 'интегра']);

        const parsedRows: ExecutionRow[] = [];
        
        // KPI Accumulators
        let kpiConcrete = { val: 0, done: 0, unit: 'м3' };
        let kpiMetal = { val: 0, done: 0, unit: 'тн' };
        let kpiSandwich = { val: 0, done: 0, unit: 'м2' };

        // Create a map of existing data for merging
        const existingDataMap = new Map<string, ExecutionRow>(data.map(row => [row.name?.toLowerCase().trim() || '', row]));

        for (let i = headerRowIndex + 1; i < rawData.length; i++) {
          const row = rawData[i];
          if (!row || row.length === 0) continue;

          const name = row[colMap.name] ? String(row[colMap.name]).trim() : '';
          if (!name) continue;

          // Helper to get value or undefined if empty
          const getVal = (idx: number): number | undefined => {
            if (idx === -1) return undefined;
            const val = row[idx];
            if (val === undefined || val === null || String(val).trim() === '') return undefined;
            
            if (typeof val === 'number') return val;
            if (typeof val === 'string') {
              // Remove spaces and replace comma with dot
              const cleanVal = val.replace(/\s/g, '').replace(',', '.');
              if (cleanVal === '') return undefined;
              const num = parseFloat(cleanVal);
              return isNaN(num) ? undefined : num;
            }
            return undefined;
          };

          const existingRow = existingDataMap.get(name.toLowerCase());

          const unit = colMap.unit > -1 ? (String(row[colMap.unit] || '').trim() || existingRow?.unit || '') : (existingRow?.unit || '');
          
          // Merge logic: Use file value if present, otherwise existing value, otherwise 0
          const valTotal = getVal(idxTotal);
          const total = valTotal !== undefined ? valTotal : (existingRow?.totalVolume ?? 0);
          
          const valDone = getVal(idxDone);
          const done = valDone !== undefined ? valDone : (existingRow?.done ?? 0);
          
          // If remainder is missing in file, calculate it from the resolved total and done
          const valRemainder = idxRemainder > -1 ? getVal(idxRemainder) : undefined;
          let remainder = valRemainder !== undefined ? valRemainder : (total - done);
          
          // Integra Logic
          const valIntegraFact = getVal(idxIntegraFact);
          const integraFact = valIntegraFact !== undefined ? valIntegraFact : (existingRow?.integraFact ?? 0);
          
          // BAZIS Logic: Calculate (Done - Integra)
          const bazisFact = Math.max(0, done - integraFact);
          
          const valIntegraRemainder = idxIntegraRemainder > -1 ? getVal(idxIntegraRemainder) : undefined;
          let integraRemainder = valIntegraRemainder !== undefined ? valIntegraRemainder : (total - done); // Fallback

          // Recalculate percentages
          const progress = total > 0 ? (done / total) * 100 : 0;
          const bazisPercent = total > 0 ? (bazisFact / total) * 100 : 0;
          const integraPercent = total > 0 ? (integraFact / total) * 100 : 0;
          const integraRemainderPercent = total > 0 ? (integraRemainder / total) * 100 : 0;

          const isSection = name.toLowerCase().startsWith('раздел') || (unit === '' && total > 0);

          // KPI Extraction Logic
          const nameLower = name.toLowerCase();
          
          // 1. Concrete (КЖ)
          if (nameLower.includes('кж') && (unit.includes('м3') || isSection)) {
             if (nameLower.includes('раздел кж')) {
               kpiConcrete.val = total;
               kpiConcrete.done = done;
             } 
          }

          // 2. Metal (КМ)
          if (nameLower.includes('км') && (unit.includes('тн') || unit.includes('т') || isSection)) {
             if (nameLower.includes('раздел км')) {
               kpiMetal.val = total;
               kpiMetal.done = done;
             }
          }

          // 3. Sandwich Panels
          if (nameLower.includes('сэндвич') && (unit.includes('м2') || isSection)) {
             kpiSandwich.val = total; 
             kpiSandwich.done = done; 
          }

          parsedRows.push({
            id: existingRow ? existingRow.id : `row-${i}`,
            no: colMap.no > -1 ? String(row[colMap.no] || '') : (existingRow?.no || ''),
            name: name,
            unit: unit,
            totalVolume: total,
            done: done,
            remainder: remainder,
            bazisFact: bazisFact,
            bazisPercent: bazisPercent,
            integraFact: integraFact,
            integraPercent: integraPercent,
            integraRemainder: integraRemainder,
            integraRemainderPercent: integraRemainderPercent,
            progress: progress,
            isSection: isSection,
            level: isSection ? 0 : 1
          });
        }

        const newKpis = {
          concrete: { title: 'Железобетон (КЖ)', value: kpiConcrete.done, percent: kpiConcrete.val > 0 ? (kpiConcrete.done / kpiConcrete.val) * 100 : 0, unit: 'м³' },
          metal: { title: 'Металлоконструкции (КМ)', value: kpiMetal.done, percent: kpiMetal.val > 0 ? (kpiMetal.done / kpiMetal.val) * 100 : 0, unit: 'тн' },
          sandwich: { title: 'Сэндвич-панели (АР)', value: kpiSandwich.done, percent: kpiSandwich.val > 0 ? (kpiSandwich.done / kpiSandwich.val) * 100 : 0, unit: 'м²' }
        };

        setData(parsedRows);
        setFileName(file.name);
        setFileDate(extractedDate);
        setKpis(newKpis);
        setError(null);
        
        localStorage.setItem('execution_summary_data', JSON.stringify(parsedRows));
        localStorage.setItem('execution_summary_filename', file.name);
        localStorage.setItem('execution_summary_date', extractedDate);
        localStorage.setItem('execution_summary_kpis', JSON.stringify(newKpis));

      } catch (err) {
        console.error(err);
        setError("Ошибка при чтении файла. Убедитесь, что это корректный Excel файл.");
      }
    };
    reader.readAsBinaryString(file);
  };

  const exportPDF = () => {
    const doc = new jsPDF('l', 'mm', 'a4'); // Landscape
    doc.addFont("https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/fonts/Roboto/Roboto-Regular.ttf", "Roboto", "normal");
    doc.setFont("Roboto");
    
    doc.setFontSize(14);
    doc.text("СВОДКА ВЫПОЛНЕНИЯ И ОСТАТКИ", 14, 15);
    doc.setFontSize(10);
    doc.text(`Актуальность данных: ${fileDate || '—'}`, 14, 22);
    
    (doc as any).autoTable({
      head: [
        [
          { content: 'Наименование работ', rowSpan: 2, styles: { valign: 'middle' } },
          { content: 'Ед.', rowSpan: 2, styles: { valign: 'middle' } },
          { content: 'Общие показатели', colSpan: 3, styles: { halign: 'center' } },
          { content: 'BAZIS / Прочие', colSpan: 1, styles: { halign: 'center' } },
          { content: 'INTEGRA CONSTRUCTION', colSpan: 2, styles: { halign: 'center' } },
          { content: 'Прогресс', rowSpan: 2, styles: { valign: 'middle' } }
        ],
        ['Объем', 'Выполнено', 'Остаток', 'Факт / %', 'Факт / %', 'Остаток / %']
      ],
      body: data.map(row => [
        row.name,
        row.unit,
        row.totalVolume ? row.totalVolume.toLocaleString() : '—',
        row.done ? row.done.toLocaleString() : '—',
        row.remainder ? row.remainder.toLocaleString() : '—',
        row.bazisFact ? `${row.bazisFact.toLocaleString()} / ${row.bazisPercent.toFixed(0)}%` : '—',
        row.integraFact ? `${row.integraFact.toLocaleString()} / ${row.integraPercent.toFixed(0)}%` : '—',
        row.integraRemainder ? `${row.integraRemainder.toLocaleString()} / ${row.integraRemainderPercent.toFixed(0)}%` : '—',
        `${row.progress.toFixed(1)}%`
      ]),
      startY: 30,
      styles: { font: "Roboto", fontSize: 8 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, lineWidth: 0.1, lineColor: [200, 200, 200] },
      theme: 'grid'
    });

    doc.save("execution_summary.pdf");
  };

  return (
    <div className="space-y-6 pb-10">
      {/* Header & Upload */}
      <Card padding="none" className="overflow-hidden">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center p-6 gap-4">
          <div className="w-full">
             <h2 className="text-xl md:text-2xl font-bold text-[#1D1D1F] uppercase tracking-tight">Сводка выполнения и остатки</h2>
             <div className="flex items-center mt-2 text-[#86868B] text-xs md:text-sm font-medium">
               <Calendar className="w-4 h-4 mr-2 text-[#C7C7CC]" />
               Актуальность данных: <span className="text-[#1D1D1F] ml-1">{fileDate || '—'}</span>
             </div>
          </div>
          <div className="flex flex-col sm:flex-row flex-wrap gap-2 w-full md:w-auto">
            <label className="btn-primary w-full sm:w-auto cursor-pointer">
              <Upload className="w-4 h-4 mr-2" />
              {data.length > 0 ? 'Обновить' : 'Загрузить'}
              <input 
                type="file" 
                accept=".xlsx, .xls" 
                className="hidden" 
                onChange={handleFileUpload}
                onClick={(e) => (e.target as HTMLInputElement).value = ''} 
              />
            </label>
            
            {data.length > 0 && (
              <div className="flex gap-2 w-full sm:w-auto">
                <button 
                  onClick={exportPDF} 
                  className="btn-secondary flex-1 sm:flex-none text-[#1D1D1F] border-black/[0.08]"
                >
                  <Download className="w-4 h-4 mr-2" />
                  PDF
                </button>
                
                {isConfirmingDelete ? (
                  <div className="flex gap-2 w-full sm:w-auto">
                    <button 
                      onClick={handleDelete}
                      className="btn-primary bg-[#FF3B30] hover:bg-[#FF3B30]/90 shadow-[#FF3B30]/30 flex-1 sm:flex-none"
                    >
                      Удалить точно?
                    </button>
                    <button 
                      onClick={() => setIsConfirmingDelete(false)}
                      className="btn-secondary border-none bg-[#E5E5EA] hover:bg-[#D1D1D6] text-[#1D1D1F] flex-1 sm:flex-none"
                    >
                      Отмена
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => setIsConfirmingDelete(true)}
                    className="btn-secondary border-[#FF3B30]/20 text-[#FF3B30] hover:bg-[#FF3B30]/10 flex-1 sm:flex-none"
                    title="Очистить данные"
                  >
                    <Trash2 className="w-4 h-4 sm:mr-2" />
                    <span className="sm:hidden">Удалить</span>
                    <span className="hidden sm:inline">Удалить</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </Card>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-xl flex items-center border border-red-100">
          <AlertCircle className="w-5 h-5 mr-2" />
          {error}
        </div>
      )}

      {/* KPI Cards removed */}

      {/* Main Table */}
      {data.length > 0 ? (
        <>
          <Card padding="none" className="overflow-hidden">
          <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-220px)]">
            <table className="w-full text-xs md:text-sm text-left border-collapse relative min-w-[800px]">
              <thead className="sticky top-0 z-40 shadow-sm">
                <tr className="bg-[#F5F5F7] text-[#86868B] font-semibold text-[10px] md:text-xs uppercase tracking-wider border-b border-black/[0.08]">
                  <th className="px-2 md:px-4 py-3 w-1/3 md:w-1/4 border-r border-black/[0.04] bg-[#F5F5F7] sticky left-0 z-50 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)]">Наименование работ</th>
                  <th className="px-1 md:px-2 py-3 w-12 md:w-16 text-center border-r border-black/[0.04] bg-[#F5F5F7]">Ед.</th>
                  
                  {/* General Indicators */}
                  <th colSpan={3} className="px-2 md:px-4 py-2 text-center border-r border-black/[0.04] bg-[#F5F5F7]">
                    Общие показатели
                  </th>
                  
                  {/* BAZIS */}
                  <th className="px-2 md:px-4 py-2 text-center border-r border-black/[0.04] text-[#34C759] bg-[#34C759]/5">
                    BAZIS / Прочие
                  </th>
                  
                  {/* INTEGRA */}
                  <th colSpan={2} className="px-2 md:px-4 py-2 text-center border-r border-black/[0.04] text-[#007AFF] bg-[#007AFF]/5">
                    INTEGRA CONSTRUCTION
                  </th>
                  
                  <th className="px-2 md:px-4 py-3 w-32 md:w-48 bg-[#F5F5F7]">Прогресс</th>
                </tr>
                <tr className="bg-[#F5F5F7] text-[#C7C7CC] font-medium text-[10px] md:text-xs border-b border-black/[0.08]">
                  <th className="px-2 md:px-4 py-2 border-r border-black/[0.04] bg-[#F5F5F7] sticky left-0 z-50 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)]"></th>
                  <th className="px-1 md:px-2 py-2 border-r border-black/[0.04] bg-[#F5F5F7]"></th>
                  
                  <th className="px-2 md:px-3 py-2 text-right border-r border-black/[0.04] bg-[#F5F5F7]">Объем</th>
                  <th className="px-2 md:px-3 py-2 text-right border-r border-black/[0.04] bg-[#F5F5F7]">Выполнено</th>
                  <th className="px-2 md:px-3 py-2 text-right border-r border-black/[0.04] text-[#FF3B30] bg-[#F5F5F7]">Остаток</th>
                  
                  <th className="px-2 md:px-3 py-2 text-right border-r border-black/[0.04] text-[#34C759] bg-[#34C759]/5">Факт / %</th>
                  
                  <th className="px-2 md:px-3 py-2 text-right border-r border-black/[0.04] text-[#007AFF] bg-[#007AFF]/5">Факт / %</th>
                  <th className="px-2 md:px-3 py-2 text-right border-r border-black/[0.04] text-[#007AFF] bg-[#007AFF]/5">Остаток / %</th>
                  
                  <th className="px-2 md:px-4 py-2 bg-[#F5F5F7]"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-black/[0.04]">
                {data.map((row) => {
                  if (row.isSection) {
                    return (
                      <tr key={row.id} className="bg-[#F5F5F7] border-y border-black/[0.08]">
                        <td colSpan={9} className="px-2 md:px-4 py-2 md:py-3 text-center font-bold text-[#1D1D1F] uppercase tracking-wider text-[11px] md:text-sm sticky left-0 z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]">
                          {row.name}
                        </td>
                      </tr>
                    );
                  }
                  
                  return (
                    <tr key={row.id} className="hover:bg-[#F5F5F7] transition-colors text-[#1D1D1F] border-b border-black/[0.04] group">
                      <td className="px-2 md:px-4 py-2 md:py-3 border-r border-black/[0.04] sticky left-0 bg-white z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)] group-hover:bg-[#F5F5F7]">
                        <div className="pl-2 md:pl-6 text-[11px] md:text-sm leading-tight font-medium">
                          {row.name}
                        </div>
                      </td>
                      <td className="px-1 md:px-2 py-2 md:py-3 text-center text-[#86868B] border-r border-black/[0.04] text-[10px] md:text-xs">{row.unit}</td>
                      
                      {/* General */}
                      <td className="px-2 md:px-3 py-2 md:py-3 text-right tabular-nums border-r border-black/[0.04] text-[11px] md:text-sm">
                        {row.displayTotal || (typeof row.totalVolume === 'number' ? row.totalVolume.toLocaleString() : '—')}
                      </td>
                      <td className="px-2 md:px-3 py-2 md:py-3 text-right tabular-nums border-r border-black/[0.04] font-semibold text-[11px] md:text-sm">
                        {row.displayDone || (typeof row.done === 'number' ? row.done.toLocaleString() : '—')}
                      </td>
                      <td className="px-2 md:px-3 py-2 md:py-3 text-right tabular-nums border-r border-black/[0.04] text-[#FF3B30] font-semibold text-[11px] md:text-sm">
                        {row.displayRemainder || (typeof row.remainder === 'number' ? row.remainder.toLocaleString() : '—')}
                      </td>
                      
                      {/* BAZIS */}
                      <td className="px-2 md:px-3 py-2 md:py-3 text-right tabular-nums border-r border-black/[0.04] text-[#34C759] bg-[#34C759]/5 text-[11px] md:text-sm">
                        {typeof row.bazisFact === 'number' ? (
                          <div className="flex flex-col items-end leading-tight">
                            <span className="font-semibold">{row.bazisFact.toLocaleString()}</span>
                            <span className="text-[9px] md:text-[10px] opacity-70">{row.bazisPercent.toFixed(0)}%</span>
                          </div>
                        ) : <span className="text-[#C7C7CC]">—</span>}
                      </td>
                      
                      {/* INTEGRA */}
                      <td className="px-2 md:px-3 py-2 md:py-3 text-right tabular-nums border-r border-black/[0.04] text-[#007AFF] bg-[#007AFF]/5 text-[11px] md:text-sm">
                        {(typeof row.integraFact === 'number' || row.displayIntegraFact) ? (
                          <div className="flex flex-col items-end leading-tight">
                            <span className="font-semibold">{row.displayIntegraFact || row.integraFact.toLocaleString()}</span>
                            <span className="text-[9px] md:text-[10px] opacity-70">{row.integraPercent.toFixed(0)}%</span>
                          </div>
                        ) : <span className="text-[#C7C7CC]">—</span>}
                      </td>
                      <td className="px-2 md:px-3 py-2 md:py-3 text-right tabular-nums border-r border-black/[0.04] text-[#007AFF] bg-[#007AFF]/5 text-[11px] md:text-sm">
                        {typeof row.integraRemainder === 'number' ? (
                          <div className="flex flex-col items-end leading-tight">
                            <span className="font-semibold">{row.integraRemainder.toLocaleString()}</span>
                            <span className="text-[9px] md:text-[10px] opacity-70">{row.integraRemainderPercent.toFixed(0)}%</span>
                          </div>
                        ) : <span className="text-[#C7C7CC]">—</span>}
                      </td>
                      
                      {/* Progress */}
                      <td className="px-2 md:px-4 py-2 md:py-3">
                        {row.totalVolume > 0 ? (
                          <div className="flex items-center space-x-3">
                            <div className="flex-1 h-2 bg-[#F5F5F7] rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full transition-all duration-500 ${
                                  row.progress >= 100 ? 'bg-[#34C759]' : 
                                  row.progress > 0 ? 'bg-[#FF9500]' : 
                                  'bg-[#C7C7CC]'
                                }`} 
                                style={{ width: `${Math.min(100, Math.max(0, row.progress))}%` }} 
                              />
                            </div>
                            <span className={`text-xs font-bold w-10 text-right ${
                               row.progress >= 100 ? 'text-[#34C759]' : 
                               row.progress > 0 ? 'text-[#FF9500]' : 
                               'text-[#C7C7CC]'
                            }`}>
                              {row.progress.toFixed(0)}%
                            </span>
                          </div>
                        ) : <span className="text-xs text-[#C7C7CC]">нет данных</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          </Card>
        </>
      ) : (
        !error && (
          <div className="text-center py-24 bg-[#F5F5F7] rounded-3xl border border-dashed border-black/[0.08]">
            <div className="bg-white p-4 rounded-full inline-flex mb-4 shadow-sm border border-black/[0.04]">
              <FileSpreadsheet className="w-8 h-8 text-[#007AFF]" />
            </div>
            <h3 className="text-headline text-[#1D1D1F] uppercase tracking-tight mb-2">Данные не загружены</h3>
            <p className="text-caption-1 text-[#86868B] mb-6 max-w-sm mx-auto">Загрузите Excel файл для формирования сводки выполнения и KPI показателей</p>
            <label className="btn-primary cursor-pointer uppercase tracking-widest">
              <Upload className="w-5 h-5 mr-2" />
              Загрузить файл
              <input type="file" accept=".xlsx, .xls" className="hidden" onChange={handleFileUpload} />
            </label>
          </div>
        )
      )}
    </div>
  );
};

const KPICard: React.FC<{ title: string; value: number; percent: number; unit: string }> = ({ title, value, percent, unit }) => {
  return (
    <Card className="hover:shadow-card-hover transition-all duration-200">
      <div className="flex justify-between items-start mb-4">
         <h3 className="text-sm font-bold text-[#86868B] uppercase tracking-wider">{title}</h3>
         <span className={`text-sm font-black px-2 py-1 rounded-lg ${
           percent >= 100 ? 'bg-[#34C759]/10 text-[#34C759]' : 'bg-[#FF9500]/10 text-[#FF9500]'
         }`}>
           {percent.toFixed(1)}%
         </span>
      </div>
      
      <div className="flex items-baseline space-x-2 mb-4">
        <span className="text-3xl font-black text-[#1D1D1F]">{value.toLocaleString()}</span>
        <span className="text-sm font-medium text-[#86868B]">{unit}</span>
      </div>
      
      <div className="w-full bg-[#F5F5F7] h-2 rounded-full overflow-hidden">
         <div 
           className={`h-full rounded-full transition-all duration-1000 ${
             percent >= 100 ? 'bg-[#34C759]' : 'bg-[#FF9500]'
           }`} 
           style={{width: `${Math.min(100, Math.max(0, percent))}%`}}
         ></div>
      </div>
      
      <div className="mt-2 text-xs text-[#C7C7CC] text-right font-medium">
        Выполнено
      </div>
    </Card>
  );
};

export default ExecutionSummary;
