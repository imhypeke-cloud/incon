
import React, { useState, useMemo } from 'react';
import { 
  Users, 
  UserCheck, 
  HardHat, 
  Briefcase, 
  Search, 
  Calendar, 
  ChevronDown,
  Building2,
  Stethoscope,
  ShieldCheck,
  Zap,
  Hammer,
  ArrowRight,
  Layout,
  UserPlus
} from 'lucide-react';
import Card from '../components/Card';

interface HRAllocation {
  id: string;
  title: string;
  itr: number;
  workers: number;
  workType: string;
  subcontractor?: string;
}

interface ManagementStaff {
  position: string;
  qty: number;
  category: 'ADMIN' | 'LINE' | 'WORKERS';
  comment?: string;
}

const HRResources: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  
  // АКТУАЛЬНАЯ ДАТА ИЗ ДОКУМЕНТА
  const reportDate = "17.03.2026";

  // ДАННЫЕ ИЗ PDF (Стр. 1): Административный и Линейный состав INTEGRA
  const managementStaff: ManagementStaff[] = [
    { position: 'Исполнительный директор ДПГУ / Deputy Director', qty: 1, category: 'ADMIN' },
    { position: 'Технический директор / Technical Director', qty: 1, category: 'ADMIN' },
    { position: 'Начальник управления по строительству / Managing Director', qty: 1, category: 'ADMIN' },
    { position: 'Заместитель Исполнительного директора по строительству', qty: 1, category: 'ADMIN' },
    { position: 'Руководитель проекта / Project Manager', qty: 4, category: 'ADMIN' },
    { position: 'Инженер ОТ и ТБ, Эколог HSE Engineer, Environmental Engineer', qty: 14, category: 'ADMIN', comment: 'Из них эколог - 2 чел.' },
    { position: 'Начальник ОПП/ Ведущий инженер ОПП, Инженер ОПП', qty: 6, category: 'ADMIN' },
    { position: 'Начальник ОКК, Инженер ОКК', qty: 10, category: 'ADMIN' },
    { position: 'Менеджер по управлению отчетности', qty: 2, category: 'ADMIN' },
    { position: 'Специалист по учету персонала', qty: 5, category: 'ADMIN' },
    { position: 'Заведующий складом, кладовщик / Warehouse Manager, Storekeeper', qty: 9, category: 'ADMIN' },
    { position: 'Фельдшер Paramedic', qty: 3, category: 'ADMIN' },
    { position: 'Специалист АХО Facility Management Specialist', qty: 3, category: 'ADMIN' },
    { position: 'Отдел снабжения / Supply Department', qty: 2, category: 'ADMIN' },
    { position: 'Служба безопасности (СБ) / Security Service (SS)', qty: 2, category: 'ADMIN' },
    { position: 'Главный геодезист, Инженер Геодезист / Chief Surveyor, Survey Engineer', qty: 24, category: 'LINE' },
    { position: 'Начальник участка Site Manager', qty: 8, category: 'LINE' },
    { position: 'Отдел главного энергетика Chief Electrical Engineer', qty: 8, category: 'LINE' },
    { position: 'Прораб / Foreman', qty: 14, category: 'LINE' },
    { position: 'Механик( малая механизация) / Mechanic', qty: 2, category: 'LINE' },
    { position: 'Мастер / Supervisor', qty: 1, category: 'LINE' },
    { position: 'Электромонтажники и Сантехники Electricians and Plumbers', qty: 10, category: 'WORKERS' },
    { position: 'Рабочие / Labors', qty: 28, category: 'WORKERS', comment: '3 чел - пожарная служба, 7 чел. на складе, 12 чел на площадке, 4 чел. пом. геодезиста. 2 чел пом. менед. отч.' },
  ];

  const titleAllocation: HRAllocation[] = [
    { id: 'rebar-shop', title: 'Арматурный цех тит 50 и площадка ОГ', itr: 0, workers: 8, workType: 'Загатовка: ОГ, арматурных изделий, уборка по всей площадке', subcontractor: 'INTEGRA' },
    { id: '0.0-blitz', title: 'Титул 0.0 (КЖ1) ТОО Блиц-Монтаж', itr: 1, workers: 15, workType: 'Устройство армирования', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: 'doosan', title: 'Склад Doosan', itr: 1, workers: 8, workType: 'Вывоз материалов со склада на строй площадку', subcontractor: 'INTEGRA' },
    { id: '1.1-stroy', title: 'Титул 1.1 (Stroy Consulting 2050)', itr: 1, workers: 9, workType: 'Монтаж М/К', subcontractor: 'Stroy Consulting-2050' },
    { id: '1.1-sst', title: 'Титул 1.1 (SST Building)', itr: 1, workers: 21, workType: 'Монтаж оборудования', subcontractor: 'SST Building' },
    { id: '1.1-sarens', title: 'Титул 1.1 (Sarens)', itr: 0, workers: 2, workType: 'Монтаж', subcontractor: 'Sarens' },
    { id: '1.1-kj45-blitz', title: 'Титул 1.1 Кж4.5 (Блиц-Монтаж)', itr: 1, workers: 14, workType: 'Устройство армокаркаса, устранение замечаний, монтаж опалубки', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '1.1-blitz', title: 'Титул 1.1 (КЖ 2, 6, 7, 8, 16) Блиц-Монтаж', itr: 1, workers: 41, workType: 'Устройство армокаркаса, чипинг колонн', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '1.1-baibol', title: 'Титул 1.1 (КЖ15) ТОО Baibol', itr: 1, workers: 24, workType: 'Устройство армирования', subcontractor: 'ТОО Baibol' },
    { id: '1.2-ancon', title: 'Титул 1.2 (ТОО Ancon)', itr: 2, workers: 70, workType: 'Устройство армирования', subcontractor: 'ТОО Ancon' },
    { id: '1.2-blitz', title: 'Титул 1.2 (ТОО Блиц-Монтаж)', itr: 1, workers: 43, workType: 'Устройство армирования', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '1.3-sst', title: 'Титул 1.3 (SST Building)', itr: 1, workers: 11, workType: 'Устройство армирования', subcontractor: 'SST Building' },
    { id: '1.3-blitz', title: 'Титул 1.3 (ТОО Блиц-Монтаж)', itr: 2, workers: 46, workType: 'Устройство армирования', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '3-blitz', title: 'Титул 3 (ТОО Блиц-Монтаж)', itr: 1, workers: 7, workType: 'Устройство армирования', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '5.1-5.4-blitz', title: 'Титул 5.1 - 5.4 (ТОО Блиц-Монтаж)', itr: 1, workers: 17, workType: 'Устройство армирования', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '6.1-blitz', title: 'Титул 6.1 (ТОО Блиц-Монтаж)', itr: 0, workers: 6, workType: 'Устройство армирования', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '8.1', title: 'Титул 8.1 (Квант)', itr: 1, workers: 4, workType: 'Инженерные сети / Installation of sandwich panels', subcontractor: 'Квант' },
    { id: '8.2', title: 'Титул 8.2 (ТОО NUR-AKHMED GROUP)', itr: 1, workers: 3, workType: 'Инженерные сети / Installation of sandwich panels', subcontractor: 'ТОО NUR-AKHMED GROUP' },
    { id: '9-blitz', title: 'Титул 9 (0.0 Кж1) (ТОО Блиц-Монтаж)', itr: 0, workers: 8, workType: 'Устройство армирования', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '10.11', title: 'Титул 10.11 (ТОО Блиц-Монтаж)', itr: 1, workers: 6, workType: 'Монтаж опалубки', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '12.1', title: 'Титул 12.1 (Квант)', itr: 2, workers: 6, workType: 'Подготовительные работы к монтажу ФБц панелей', subcontractor: 'Квант' },
    { id: '12.2-12.3', title: 'Титул 12.2-12.3 (KBP)', itr: 1, workers: 8, workType: 'Монтаж резервуаров в проектное положение', subcontractor: 'KBP' },
    { id: '13.4', title: 'Титул 13.4 (Stroy Consulting-2050)', itr: 1, workers: 12, workType: 'Монтаж М/К', subcontractor: 'Stroy Consulting-2050' },
    { id: '15.1', title: 'Титул 15.1 (ТОО QPARK group)', itr: 1, workers: 4, workType: 'Устройство армокаркаса', subcontractor: 'ТОО QPARK group' },
    { id: '16', title: 'Титул 16 (ТОО Блиц-Монтаж)', itr: 2, workers: 28, workType: 'Монтаж опалубки', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '24', title: 'Титул 24 (ТОО QPARK group)', itr: 4, workers: 11, workType: 'Устройство армокаркаса', subcontractor: 'ТОО QPARK group' },
    { id: '25-atameken', title: 'Титул 25 (ТОО АТАМЕКЕН-ҚС)', itr: 1, workers: 23, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки, монтаж лесов', subcontractor: 'АТАМЕКЕН-ҚС' },
    { id: '25-sst', title: 'Титул 25 (SST Building)', itr: 6, workers: 26, workType: 'Монтаж перегородочного газоблока', subcontractor: 'SST Building' },
    { id: '25-mega', title: 'Титул 25 (Мега Мост)', itr: 1, workers: 9, workType: 'Устройство армокаркаса', subcontractor: 'Мега Мост' },
    { id: '25-blitz', title: 'Титул 25 (Блиц-Монтаж)', itr: 1, workers: 10, workType: 'Устройство армокаркаса', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '27-blitz', title: 'Титул 27 (Блиц-Монтаж)', itr: 0, workers: 6, workType: 'Устройство армокаркаса', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '32', title: 'Титул 32 (TOO Q17 CONSTRUCTION)', itr: 1, workers: 7, workType: 'Монтаж М/К', subcontractor: 'TOO Q17 CONSTRUCTION' },
    { id: '34', title: 'Титул 34 (Блиц-Монтаж)', itr: 1, workers: 7, workType: 'Устройство армокаркаса', subcontractor: 'Блиц-Монтаж' },
    { id: '33.1', title: 'Титул 33.1 (Блиц-Монтаж)', itr: 1, workers: 3, workType: 'Устранение замечаний', subcontractor: 'Блиц-Монтаж' },
    { id: '38', title: 'Титул 38 (ТОО Адал Жарық Құрылыс)', itr: 1, workers: 8, workType: 'Устройство армокаркаса', subcontractor: 'ТОО Адал Жарық Құрылыс' },
    { id: '39', title: 'Титул 39 (ТОО Блиц-Монтаж)', itr: 1, workers: 10, workType: 'Загатовка опалубки', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '42', title: 'Титул 42 (ТОО Ancon)', itr: 2, workers: 18, workType: 'Устройство армокаркаса', subcontractor: 'ТОО Ancon' },
    { id: '0.0-blitz-2', title: 'Титул 0.0 (КЖ1) ТОО Блиц-Монтаж (2)', itr: 1, workers: 27, workType: 'Устройство армирования', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '43-hydro', title: 'Титул 43 (ТОО Блиц-Монтаж) гидроизоляция', itr: 0, workers: 12, workType: 'Гидроизоляция', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '43-portals', title: 'Титул 43 (ТОО Блиц-Монтаж) порталы', itr: 2, workers: 32, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки, монтаж лесов', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '44-son', title: 'Титул 44 (ТОО Блиц-Монтаж) СОН', itr: 1, workers: 44, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки, монтаж лесов', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '44-portals', title: 'Титул 44 (ТОО Блиц-Монтаж) порталы', itr: 2, workers: 26, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки, монтаж лесов', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '46', title: 'Титул 46 (ТОО Блиц-Монтаж)', itr: 1, workers: 5, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки, монтаж лесов', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '47.1', title: 'Титул 47.1 (ТОО Блиц-Монтаж)', itr: 0, workers: 4, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки, монтаж лесов', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '50-kz3', title: 'Титул 50 (КЖ3) (ТОО Мейрам Құрылыс)', itr: 1, workers: 3, workType: 'Монтаж м/к', subcontractor: 'ТОО Мейрам Құрылыс' },
    { id: '50-kz4-pazuhi', title: 'Титул 50 (КЖ4) (ТОО Блиц-Монтаж) пазухи', itr: 0, workers: 3, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '50-kz4-atameken', title: 'Титул 50 (КЖ4) (ТОО АТАМЕКЕН-ҚС)', itr: 0, workers: 4, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки', subcontractor: 'АТАМЕКЕН-ҚС' },
    { id: '50-kz4-hydro', title: 'Титул 50 (КЖ4) (ТОО Блиц-Монтаж) гидроизоляция', itr: 1, workers: 5, workType: 'Гидроизоляция', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '50-kz5-blitz', title: 'Титул 50 (КЖ5) (ТОО Блиц-Монтаж)', itr: 0, workers: 2, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: '50-kz8-blitz', title: 'Титул 50 (КЖ8) (ТОО Блиц-Монтаж)', itr: 0, workers: 3, workType: 'Устройство армокаркаса, демонаж и монтаж опалубки', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: 'forestry', title: 'Лесомонтажники (ТОО Блиц-Монтаж)', itr: 2, workers: 48, workType: 'Монтаж строительных лесов', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: 'pipeshop', title: 'Трубный цех (ТОО Блиц-Монтаж)', itr: 1, workers: 17, workType: 'Сборка трубного цеха', subcontractor: 'ТОО Блиц-Монтаж' },
    { id: 'imstalkon', title: 'АО Имсталькон', itr: 1, workers: 23, workType: 'Монтаж м/к', subcontractor: 'АО Имсталькон' },
    { id: 'stecol', title: 'TOO STECOL', itr: 65, workers: 67, workType: 'Монтаж оборудования', subcontractor: 'TOO STECOL' },
    { id: 'const-go', title: 'KZ Construction Go', itr: 2, workers: 8, workType: 'Изготовление', subcontractor: 'KZ Construction Go' },
  ];

  // ИТОГОВЫЕ ПОКАЗАТЕЛИ ИЗ PDF (Стр. 4)
  const totals = {
    itr: 221, 
    workers: 978,
    total: 1199 
  };

  const filteredTitles = useMemo(() => {
    return titleAllocation.filter(t => 
      t.title?.toLowerCase().includes(searchQuery.toLowerCase()) || 
      t.workType?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.subcontractor?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      
      {/* HEADER SECTION */}
      <Card className="relative overflow-hidden border-none bg-[#1D1D1F] text-white p-8">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#007AFF]/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center space-x-5">
            <div className="w-14 h-14 bg-[#007AFF] rounded-2xl flex items-center justify-center shadow-lg shadow-[#007AFF]/20 rotate-3 group-hover:rotate-0 transition-transform duration-300">
              <Users size={28} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">Управление персоналом</h1>
              <div className="flex items-center mt-1.5 space-x-4">
                <p className="text-sm font-medium text-[#86868B] flex items-center">
                  <Calendar size={14} className="mr-1.5" />
                  Отчет от {reportDate}
                </p>
                <span className="w-1 h-1 bg-[#86868B] rounded-full" />
                <p className="text-sm font-medium text-[#007AFF]">Общий штат: {totals.total} чел.</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="relative group">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#86868B] group-focus-within:text-[#007AFF] transition-colors" />
              <input 
                type="text" 
                placeholder="Поиск по титулу или подрядчику..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-field w-full md:w-72 pl-10"
              />
            </div>
          </div>
        </div>
      </Card>

      {/* STATS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card hoverable className="flex flex-col justify-between p-6 group">
          <div className="flex items-center justify-between mb-6">
            <div className="w-12 h-12 bg-[#007AFF]/10 text-[#007AFF] rounded-2xl flex items-center justify-center group-hover:bg-[#007AFF] group-hover:text-white transition-all duration-300">
              <Building2 size={24} />
            </div>
            <div className="text-right">
              <p className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest">Management</p>
              <p className="text-xs font-medium text-[#34C759] mt-0.5">В штате</p>
            </div>
          </div>
          <div>
            <h3 className="text-3xl font-semibold tracking-tight text-[#1D1D1F]">{totals.itr}</h3>
            <p className="text-sm font-medium text-[#86868B] mt-1">Инженерно-технический состав</p>
          </div>
        </Card>

        <Card hoverable className="flex flex-col justify-between p-6 group">
          <div className="flex items-center justify-between mb-6">
            <div className="w-12 h-12 bg-[#34C759]/10 text-[#34C759] rounded-2xl flex items-center justify-center group-hover:bg-[#34C759] group-hover:text-white transition-all duration-300">
              <HardHat size={24} />
            </div>
            <div className="text-right">
              <p className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest">Operations</p>
              <p className="text-xs font-medium text-[#34C759] mt-0.5">На объектах</p>
            </div>
          </div>
          <div>
            <h3 className="text-3xl font-semibold tracking-tight text-[#1D1D1F]">{totals.workers}</h3>
            <p className="text-sm font-medium text-[#86868B] mt-1">Рабочий персонал и операторы</p>
          </div>
        </Card>

        <Card hoverable className="flex flex-col justify-between p-6 group bg-[#007AFF]/5 border-[#007AFF]/10">
          <div className="flex items-center justify-between mb-6">
            <div className="w-12 h-12 bg-[#007AFF] text-white rounded-2xl flex items-center justify-center shadow-lg shadow-[#007AFF]/20">
              <Users size={24} />
            </div>
            <div className="text-right">
              <p className="text-[11px] font-bold text-[#007AFF] uppercase tracking-widest">Total Force</p>
              <p className="text-xs font-medium text-[#007AFF] mt-0.5">Суммарно</p>
            </div>
          </div>
          <div>
            <h3 className="text-3xl font-semibold tracking-tight text-[#1D1D1F]">{totals.total}</h3>
            <p className="text-sm font-medium text-[#86868B] mt-1">Общее количество персонала</p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* АДМИНИСТРАТИВНОЕ УПРАВЛЕНИЕ (ПОЗИЦИИ) */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="h-full flex flex-col p-0 overflow-hidden">
            <div className="p-6 border-b border-black/[0.04] bg-[#F5F5F7]/30">
              <h3 className="text-lg font-semibold text-[#1D1D1F] flex items-center">
                <Building2 className="mr-2.5 text-[#007AFF]" size={20} />
                ИТР Состав (INTEGRA)
              </h3>
              <p className="text-xs font-medium text-[#86868B] mt-1 uppercase tracking-wider">Административный и линейный персонал</p>
            </div>
            
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-2 max-h-[600px]">
              {managementStaff.map((staff, idx) => (
                <div key={idx} className="flex items-center justify-between p-3.5 bg-white rounded-xl border border-black/[0.04] hover:border-[#007AFF]/30 hover:shadow-sm transition-all group">
                  <div className="flex-1 pr-4">
                    <p className="text-sm font-medium text-[#1D1D1F] leading-snug group-hover:text-[#007AFF] transition-colors">{staff.position}</p>
                    {staff.comment && (
                      <p className="text-[11px] text-[#86868B] mt-1 flex items-center">
                        <span className="w-1 h-1 bg-[#C7C7CC] rounded-full mr-1.5" />
                        {staff.comment}
                      </p>
                    )}
                  </div>
                  <div className={`flex items-center justify-center min-w-[32px] h-8 rounded-lg text-sm font-bold ${staff.category === 'ADMIN' ? 'bg-[#007AFF]/10 text-[#007AFF]' : 'bg-[#F5F5F7] text-[#1D1D1F]'}`}>
                    {staff.qty}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* РАССТАНОВКА ПО ТИТУЛАМ (ТАБЛИЦА) */}
        <div className="lg:col-span-2 space-y-6">
          <Card padding="none" className="flex flex-col h-full overflow-hidden border-none shadow-lg shadow-black/[0.03]">
            <div className="p-6 border-b border-black/[0.04] bg-[#F5F5F7]/30">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-[#1D1D1F] flex items-center">
                    <Layout className="mr-2.5 text-[#007AFF]" size={20} />
                    Распределение по объектам
                  </h3>
                  <p className="text-xs font-medium text-[#86868B] mt-1 uppercase tracking-wider">Текущая расстановка персонала по титулам</p>
                </div>
                <div className="flex items-center space-x-2 text-xs font-medium text-[#86868B]">
                  <span className="flex items-center"><span className="w-2 h-2 bg-[#007AFF] rounded-full mr-1.5" /> ИТР</span>
                  <span className="flex items-center ml-3"><span className="w-2 h-2 bg-[#34C759] rounded-full mr-1.5" /> РАБОЧИЕ</span>
                </div>
              </div>
            </div>

            <div className="overflow-x-auto overflow-y-auto max-h-[600px] custom-scrollbar">
              <table className="w-full border-collapse">
                <thead className="sticky top-0 z-20 bg-[#F5F5F7] backdrop-blur-md">
                  <tr className="text-[11px] font-bold uppercase text-[#86868B] tracking-widest border-b border-black/[0.08]">
                    <th className="px-6 py-4 text-left">Объект / Организация</th>
                    <th className="px-4 py-4 text-center w-20">ИТР</th>
                    <th className="px-4 py-4 text-center w-20">РАБ.</th>
                    <th className="px-6 py-4 text-left">Виды работ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-black/[0.04] bg-white">
                  {filteredTitles.map((title) => (
                    <tr key={title.id} className="hover:bg-[#F5F5F7]/50 transition-all group">
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="text-sm font-semibold text-[#1D1D1F] group-hover:text-[#007AFF] transition-colors">{title.title}</span>
                          {title.subcontractor && (
                            <div className="flex items-center mt-1.5">
                              <span className="text-[10px] font-bold text-[#007AFF] bg-[#007AFF]/5 px-2 py-0.5 rounded-full uppercase border border-[#007AFF]/10">
                                {title.subcontractor}
                              </span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className={`inline-flex items-center justify-center w-9 h-9 rounded-xl text-sm font-bold ${title.itr > 0 ? 'bg-[#007AFF]/5 text-[#007AFF]' : 'text-[#C7C7CC]'}`}>
                          {title.itr}
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="inline-flex items-center justify-center w-9 h-9 rounded-xl bg-[#34C759]/5 text-[#34C759] text-sm font-bold">
                          {title.workers}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-xs font-medium text-[#86868B] leading-relaxed max-w-xs group-hover:text-[#1D1D1F] transition-colors">
                          {title.workType}
                        </p>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              
              {filteredTitles.length === 0 && (
                <div className="py-24 text-center flex flex-col items-center">
                  <div className="w-16 h-16 bg-[#F5F5F7] rounded-full flex items-center justify-center mb-4">
                    <Users size={32} className="text-[#C7C7CC]" />
                  </div>
                  <p className="text-sm font-semibold text-[#86868B] uppercase tracking-widest">Результатов не найдено</p>
                  <p className="text-xs text-[#C7C7CC] mt-1">Попробуйте изменить параметры поиска</p>
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default HRResources;
