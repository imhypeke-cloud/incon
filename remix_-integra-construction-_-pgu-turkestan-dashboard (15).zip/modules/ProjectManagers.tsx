
import React, { useState, useMemo } from 'react';
import { 
  User, 
  Briefcase, 
  UserCheck, 
  HardHat, 
  Zap, 
  Cog, 
  Calendar, 
  ListTodo, 
  ChevronRight, 
  Search,
  Filter,
  BarChart3,
  Download,
  Info
} from 'lucide-react';
import Card from '../components/Card';

interface ScheduleItem {
  title: string;
  section: string;
  name: string;
  unit: string;
  qty: number | string;
  rdDate: string;
  start: string;
  finish: string;
  duration: number | string;
}

const ProjectManagers: React.FC = () => {
  const [viewMode, setViewMode] = useState<'cards' | 'schedule'>('cards');
  const [selectedManagerId, setSelectedManagerId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const sections = [
    {
      id: '1',
      manager: 'Попивнухин Николай Владимирович',
      titles: ['1.1', '1.2', '1.3', '4', '5', '6', '23.3', '34'],
      color: 'border-amber-200 bg-amber-50',
      accent: 'amber'
    },
    {
      id: '2',
      manager: 'Махмудов Юнус Смихан-Оглы',
      titles: ['24', '38', '39', '42', '43', '44', '46', '47.1', '48', '49', '23.4', '45.1', '45.2', '47.1', '47.2', '47.3', '8.2', '12.1', '12.2-12.3', '47.3', '8.1'],
      color: 'border-blue-200 bg-blue-50',
      accent: 'blue'
    },
    {
      id: '3',
      manager: 'Алдамуратов Рахматулла Изатуллаевич',
      titles: ['2.2', '2.1', '3', '7.1', '7.2', '9', '10', '11', '13.4', '13.2-13.3', '38', '19', '32', '33.1-33.6', '35.1', '36', '37', '16', '18', '23.7', '22.1.6', '31', '15.2-15.3', '15.4-15.5', '20.1-20.3', '21', '23.5', '28', '27', '29', '35', '41', '50 кж-7'],
      color: 'border-emerald-200 bg-emerald-50',
      accent: 'emerald'
    },
    {
      id: '4',
      manager: 'Руководитель проекта – Вакансия',
      siteChief: 'Абилькасимов Болат Жарылкасымович',
      titles: ['25', '30', '41'],
      color: 'border-slate-200 bg-slate-50',
      accent: 'slate'
    }
  ];

  const scheduleData: ScheduleItem[] = [
    { title: '1.1', section: 'КЖ', name: 'Конструкции железобетонные КЖ1-21', unit: 'м3', qty: 10796.55, rdDate: '30.05.2025', start: '01.08.2025', finish: '27.07.2026', duration: 360 },
    { title: '1.1', section: 'КМ', name: 'Конструкции металлические КМ1-КМ8', unit: 'тн', qty: 11805.9, rdDate: '25.07.2025', start: '01.08.2025', finish: '25.10.2026', duration: 450 },
    { title: '1.1', section: 'ТХ', name: 'КУ#11 (Комплектная установка)', unit: 'компл', qty: 1, rdDate: '05.11.2025', start: '01.12.2025', finish: '26.12.2026', duration: 390 },
    { title: '1.2', section: 'КЖ', name: 'Железобетонные конструкции', unit: 'м3', qty: 9312.3, rdDate: '01.07.2024', start: '01.08.2025', finish: '29.12.2025', duration: 150 },
    { title: '25', section: 'КЖ', name: 'Адм-хозяйственное здание', unit: 'м3', qty: 13544.03, rdDate: '07.05.2025', start: '01.08.2025', finish: '27.02.2026', duration: 210 },
    { title: '43', section: 'КЖ', name: 'ОРУ-220 кВ - КЖ', unit: 'м3', qty: 4236.26, rdDate: '13.05.2025', start: '01.08.2025', finish: '30.10.2025', duration: 90 },
    { title: '44', section: 'КЖ', name: 'ОРУ-500 кВ - КЖ', unit: 'м3', qty: 3493.5, rdDate: '13.05.2025', start: '20.10.2025', finish: '29.11.2025', duration: 40 },
    { title: '50', section: 'КМ', name: 'Трубопроводные эстакады', unit: 'тн', qty: '—', rdDate: '25.08.2025', start: '01.12.2025', finish: '27.09.2026', duration: 300 },
  ];

  const globalRoles = [
    { name: 'Тлеулесов Каржаубай Куандыкович', dept: 'Отдел оборудования, механики и трубопровода', icon: Cog },
    { name: 'Рахматулла Айбек', dept: 'Отдел по электрике и КИПиА', icon: Zap }
  ];

  const filteredSchedule = useMemo(() => {
    return scheduleData.filter(item => {
      const managerMatch = !selectedManagerId || sections.find(s => s.id === selectedManagerId)?.titles.includes(item.title);
      const searchMatch = !searchQuery || 
        item.title?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        item.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.section?.toLowerCase().includes(searchQuery.toLowerCase());
      return managerMatch && searchMatch;
    });
  }, [scheduleData, selectedManagerId, searchQuery, sections]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-12">
      <Card className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-1 bg-[#F5F5F7] p-1 rounded-xl border border-black/[0.04]">
          <button 
            onClick={() => setViewMode('cards')}
            className={`px-6 py-2 rounded-lg text-xs font-bold transition-all ${viewMode === 'cards' ? 'bg-white text-[#1D1D1F] shadow-sm' : 'text-[#86868B] hover:text-[#1D1D1F]'}`}
          >
            Оргструктура
          </button>
          <button 
            onClick={() => setViewMode('schedule')}
            className={`px-6 py-2 rounded-lg text-xs font-bold transition-all ${viewMode === 'schedule' ? 'bg-white text-[#1D1D1F] shadow-sm' : 'text-[#86868B] hover:text-[#1D1D1F]'}`}
          >
            График СМР
          </button>
        </div>

        <div className="flex items-center space-x-4 flex-1 justify-end">
          <div className="relative flex-1 max-w-sm hidden lg:block">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#86868B]" />
            <input 
              type="text" 
              placeholder="Поиск по титулу или названию работ..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field w-full pl-11"
            />
          </div>
          <button className="btn-icon">
            <Download size={18} />
          </button>
        </div>
      </Card>

      {viewMode === 'cards' ? (
        <>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {sections.map((section) => (
              <Card key={section.id} className={`p-8 transition-all hover:shadow-md border-l-4 ${section.id === '1' ? 'border-l-[#FF9500]' : section.id === '2' ? 'border-l-[#007AFF]' : section.id === '3' ? 'border-l-[#34C759]' : 'border-l-[#86868B]'}`}>
                <div className="flex items-start justify-between mb-8">
                  <div className="flex items-center space-x-5">
                    <div className="w-14 h-14 rounded-2xl bg-[#F5F5F7] flex items-center justify-center text-[#1D1D1F] text-xl font-semibold">
                      {section.id}
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase text-[#86868B] tracking-widest mb-1.5">Участок №{section.id}</p>
                      <h3 className="font-semibold text-[#1D1D1F] text-lg leading-tight">{section.manager}</h3>
                      {section.siteChief && (
                        <p className="text-xs text-[#86868B] mt-2 flex items-center bg-[#F5F5F7] w-fit px-2.5 py-1 rounded-lg">
                          <HardHat size={14} className="mr-2 text-[#86868B]" /> Нач. участка: {section.siteChief}
                        </p>
                      )}
                    </div>
                  </div>
                  <button 
                    onClick={() => { setSelectedManagerId(section.id); setViewMode('schedule'); }}
                    className="btn-icon"
                  >
                    <ChevronRight size={20} />
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {section.titles.map((title) => (
                    <div key={title} className="px-3 py-1.5 bg-[#F5F5F7] border border-black/[0.04] rounded-lg text-[11px] font-medium text-[#1D1D1F] hover:border-[#007AFF]/30 hover:bg-[#007AFF]/5 transition-all cursor-default">
                      {title}
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>

          <Card className="p-10 relative overflow-hidden bg-[#1D1D1F] border-none">
            <div className="absolute top-0 right-0 w-96 h-96 bg-[#007AFF]/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-10">
                <h3 className="text-2xl font-semibold flex items-center text-white">
                  <UserCheck className="mr-4 text-[#007AFF]" size={28} />
                  Сквозные функции управления
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {globalRoles.map((role) => (
                  <div key={role.name} className="flex items-center space-x-6 p-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all group">
                    <div className="w-16 h-16 rounded-2xl bg-[#007AFF]/20 flex items-center justify-center text-[#007AFF] group-hover:scale-110 transition-transform">
                      <role.icon size={32} />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold leading-tight text-white mb-2">{role.name}</h4>
                      <p className="text-xs text-[#86868B]">{role.dept}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </>
      ) : (
        <Card className="p-0 overflow-hidden">
          <div className="p-6 border-b border-black/[0.04] flex flex-wrap items-center justify-between gap-6 bg-[#F5F5F7]/50">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-[#007AFF] rounded-xl text-white shadow-sm">
                <ListTodo size={20} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-[#1D1D1F]">Матрица Графика СМР</h3>
                <p className="text-xs text-[#86868B] mt-1">Детализация по разделам, объемам и срокам</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <select 
                value={selectedManagerId || ''}
                onChange={(e) => setSelectedManagerId(e.target.value || null)}
                className="text-sm bg-white border border-black/[0.08] rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#007AFF]/20 focus:border-[#007AFF] transition-all shadow-sm min-w-[240px] text-[#1D1D1F]"
              >
                <option value="">Все участки / РП</option>
                {sections.map(s => <option key={s.id} value={s.id}>{s.manager}</option>)}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[1400px]">
              <thead>
                <tr className="bg-[#F5F5F7] border-b border-black/[0.04] text-[11px] font-semibold text-[#86868B] uppercase tracking-wider">
                  <th className="px-6 py-4 text-center w-20">Титул</th>
                  <th className="px-4 py-4 w-24">Раздел</th>
                  <th className="px-6 py-4 min-w-[320px]">Наименование пакета работ</th>
                  <th className="px-4 py-4 text-center w-24">Ед. изм.</th>
                  <th className="px-4 py-4 text-center w-32">Объем</th>
                  <th className="px-4 py-4 text-center">Выдача РД</th>
                  <th className="px-4 py-4 text-center text-[#007AFF]">Старт</th>
                  <th className="px-4 py-4 text-center text-[#007AFF]">Финиш</th>
                  <th className="px-6 py-4 text-center">Длит. (дни)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-black/[0.04]">
                {filteredSchedule.length > 0 ? filteredSchedule.map((item, idx) => (
                  <tr key={idx} className="hover:bg-[#F5F5F7]/50 transition-colors group">
                    <td className="px-6 py-4 text-center">
                      <span className="inline-flex px-2.5 py-1 bg-white border border-black/[0.08] text-[#1D1D1F] rounded-lg text-xs font-medium shadow-sm">
                        {item.title}
                      </span>
                    </td>
                    <td className="px-4 py-4 font-medium text-[#86868B] text-xs">{item.section}</td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-[#1D1D1F] group-hover:text-[#007AFF] transition-colors">{item.name}</span>
                    </td>
                    <td className="px-4 py-4 text-center text-[#86868B] text-xs">{item.unit}</td>
                    <td className="px-4 py-4 text-center font-medium text-[#1D1D1F] text-sm">
                      {typeof item.qty === 'number' ? item.qty.toLocaleString() : item.qty}
                    </td>
                    <td className="px-4 py-4 text-center text-xs text-[#86868B]">{item.rdDate}</td>
                    <td className="px-4 py-4 text-center text-sm font-medium text-[#1D1D1F]">{item.start}</td>
                    <td className="px-4 py-4 text-center text-sm font-medium text-[#1D1D1F]">{item.finish}</td>
                    <td className="px-6 py-4 text-center font-medium text-[#86868B] text-sm">{item.duration}</td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={9} className="px-6 py-16 text-center text-[#86868B] text-sm">
                      Нет данных для отображения по выбранным фильтрам
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr className="bg-[#1D1D1F] text-white text-xs font-medium">
                  <td colSpan={9} className="px-8 py-5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-10">
                        <div className="flex items-center">
                          <BarChart3 size={16} className="text-[#007AFF] mr-2" />
                          <span>Интегральный СМР: 42.8%</span>
                        </div>
                        <div className="flex items-center">
                          <Calendar size={16} className="text-[#34C759] mr-2" />
                          <span>Завершено РД: 92%</span>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
};

export default ProjectManagers;
