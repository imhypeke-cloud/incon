
import React from 'react';
import { Book, FileText, Search, ExternalLink, Plus } from 'lucide-react';
import Card from '../components/Card';

const Handbook: React.FC = () => {
  const documents = [
    { title: 'СП РК 5.03-107-2013', desc: 'Несущие и ограждающие конструкции', cat: 'Нормативы' },
    { title: 'Классификатор работ v1.2', desc: 'Унифицированный перечень видов работ ПГУ', cat: 'Классификаторы' },
    { title: 'Справочник материалов', desc: 'Технические условия для ПГУ Туркестан', cat: 'Материалы' },
    { title: 'Реестр поставщиков', desc: 'Актуальный список доверенных контрагентов', cat: 'Справочные данные' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-12">
      <Card className="flex flex-col md:flex-row items-center gap-4">
        <div className="relative w-full md:flex-1">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#86868B]" />
          <input 
            type="text" 
            placeholder="Поиск по базе знаний..." 
            className="input-field w-full pl-11"
          />
        </div>
        <button className="btn-primary w-full md:w-auto uppercase tracking-widest text-caption-1">
          <Plus size={16} className="mr-2" />
          Загрузить документ
        </button>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {documents.map((doc, idx) => (
          <Card key={idx} className="hover:border-[#007AFF]/30 hover:shadow-lg hover:shadow-black/5 transition-all group flex flex-col h-full cursor-pointer">
            <div className="w-12 h-12 bg-[#F5F5F7] rounded-xl flex items-center justify-center text-[#86868B] group-hover:bg-[#007AFF]/10 group-hover:text-[#007AFF] transition-colors mb-5">
              <FileText size={24} />
            </div>
            <span className="text-[10px] font-black text-[#007AFF] uppercase tracking-widest mb-2">{doc.cat}</span>
            <h4 className="font-bold text-[#1D1D1F] text-sm mb-2 leading-tight">{doc.title}</h4>
            <p className="text-xs text-[#86868B] flex-1 leading-relaxed">{doc.desc}</p>
            <div className="mt-6 flex items-center text-[10px] font-bold text-[#86868B] uppercase group-hover:text-[#007AFF] transition-colors">
              Открыть документ <ExternalLink size={14} className="ml-1.5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Handbook;
