
import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      server: {
        port: 3000,
        host: '0.0.0.0',
      },
      plugins: [react()],
      define: {
        // API keys are now handled server-side in /api serverless functions
      },
      resolve: {
        alias: {
          // Fix: Replaced __dirname with path.resolve() as __dirname is not available in ESM context
          '@': path.resolve('.'),
        }
      }
    };
});
