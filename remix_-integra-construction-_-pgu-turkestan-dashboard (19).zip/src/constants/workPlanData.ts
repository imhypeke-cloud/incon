
import { UserRole } from '../types';

export interface WorkPlanEvent {
  id: string;
  title: string;
  type: 'Бетонирование' | 'Монтаж МК' | 'Трубопроводы' | 'Электрика' | 'Прочее';
  date: string;
  progress: number;
  volume: string;
  responsible: string;
  contractor: string;
  status: 'delay' | 'ahead' | 'normal';
  plan: number;
  fact: number;
  unit: string;
}

const rawData = [
  {
    responsible: "Попивнухин Н.В.",
    title: "1.1-КЖ4,5",
    name: "Бетонирование",
    unit: "м3",
    weeks: [
      { plan: 160, fact: 165.6 },
      { plan: 12, fact: 5.8 },
      { plan: 10, fact: 0 },
      { plan: 10.72, fact: 0 }
    ]
  },
  {
    responsible: "Попивнухин Н.В.",
    title: "1.1-КЖ21",
    name: "Бетонирование",
    unit: "м3",
    weeks: [
      { plan: 20, fact: 22 },
      { plan: 64, fact: 1.8 },
      { plan: 32, fact: 0 },
      { plan: 32, fact: 0 }
    ]
  },
  {
    responsible: "Попивнухин Н.В.",
    title: "1.1-КМ3",
    name: "Монтаж металлоконструкций Блок 4,5",
    unit: "т",
    weeks: [
      { plan: 110, fact: 120 },
      { plan: 110, fact: 94.73 },
      { plan: 110, fact: 0 },
      { plan: 20, fact: 0 }
    ]
  },
  {
    responsible: "Махмудов Ю.",
    title: "00-КЖ1",
    name: "Бетонирование участки 10, 13",
    unit: "м3",
    weeks: [
      { plan: 15, fact: 6.9 },
      { plan: 15, fact: 16.3 },
      { plan: 19, fact: 0 },
      { plan: 20, fact: 0 }
    ]
  },
  {
    responsible: "Махмудов Ю.",
    title: "43-КМ",
    name: "Монтаж металлоконструкций порталов",
    unit: "т",
    weeks: [
      { plan: 40, fact: 52 },
      { plan: 40, fact: 63 },
      { plan: 40, fact: 0 },
      { plan: 60, fact: 0 }
    ]
  },
  {
    responsible: "Тлеулесов К.",
    title: "1.1-КУ №11",
    name: "Транспортировка деталей корпуса модуля",
    unit: "упаковка",
    weeks: [
      { plan: 10, fact: 9 },
      { plan: 10, fact: 11 },
      { plan: 10, fact: 0 },
      { plan: 10, fact: 0 }
    ]
  },
  {
    responsible: "Алдамуратов Р.",
    title: "16-КЖ",
    name: "Бетонирование",
    unit: "м3",
    weeks: [
      { plan: 90, fact: 94 },
      { plan: 20, fact: 16 },
      { plan: 20, fact: 0 },
      { plan: 20, fact: 0 }
    ]
  },
  {
    responsible: "Абилькасимов Б.",
    title: "25-КЖ Блок 4",
    name: "Бетонирование",
    unit: "м3",
    weeks: [
      { plan: 30, fact: 30.7 },
      { plan: 20, fact: 18 },
      { plan: 10, fact: 0 },
      { plan: 0, fact: 0 }
    ]
  }
];

const weekStarts = [
  new Date(2026, 2, 2), // March 2
  new Date(2026, 2, 9), // March 9
  new Date(2026, 2, 16), // March 16
  new Date(2026, 2, 23)  // March 23
];

const getWorkType = (name: string): WorkPlanEvent['type'] => {
  if (name.includes('Бетон')) return 'Бетонирование';
  if (name.includes('Монтаж')) return 'Монтаж МК';
  if (name.includes('Труб')) return 'Трубопроводы';
  if (name.includes('Электр')) return 'Электрика';
  return 'Прочее';
};

const generateEvents = (): WorkPlanEvent[] => {
  const events: WorkPlanEvent[] = [];

  rawData.forEach((row, rowIndex) => {
    row.weeks.forEach((week, weekIndex) => {
      if (week.plan === 0 && week.fact === 0) return;

      const progress = week.plan > 0 ? (week.fact / week.plan) * 100 : (week.fact > 0 ? 100 : 0);
      let status: WorkPlanEvent['status'] = 'normal';
      if (week.fact < week.plan) status = 'delay';
      else if (week.fact > week.plan) status = 'ahead';

      const type = getWorkType(row.name);
      const startDate = weekStarts[weekIndex];

      // Distribute over 7 days
      for (let day = 0; day < 7; day++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(startDate.getDate() + day);
        
        const dateStr = currentDate.toISOString().split('T')[0];
        const dailyPlan = week.plan / 7;
        const dailyFact = week.fact / 7;

        events.push({
          id: `${rowIndex}-${weekIndex}-${day}`,
          title: `${type} ${row.title}`,
          type,
          date: dateStr,
          progress: Math.round(progress),
          volume: `${dailyFact.toFixed(1)} ${row.unit}`,
          responsible: row.responsible,
          contractor: "ТОО Integra", // Defaulting to Integra as per context
          status,
          plan: dailyPlan,
          fact: dailyFact,
          unit: row.unit
        });
      }
    });
  });

  return events;
};

export const WORK_PLAN_EVENTS = generateEvents();

export const WORK_PLAN_FILTERS = {
  types: Array.from(new Set(WORK_PLAN_EVENTS.map(e => e.type))),
  responsibles: Array.from(new Set(WORK_PLAN_EVENTS.map(e => e.responsible))),
  contractors: Array.from(new Set(WORK_PLAN_EVENTS.map(e => e.contractor)))
};
