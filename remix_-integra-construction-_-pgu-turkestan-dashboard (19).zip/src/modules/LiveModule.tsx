import React from 'react';
import { Lock, Video, Maximize2, RefreshCw } from 'lucide-react';

const LiveModule: React.FC = React.memo(() => {
  const cameras = [
    { id: 1, name: 'Камера 01: Площадка ПГУ', status: 'Online', type: 'PTZ' },
    { id: 2, name: 'Камера 02: Фундаменты ГТУ №1', status: 'Online', type: 'Fixed' },
    { id: 3, name: 'Камера 03: Машзал / КРУЭ', status: 'Online', type: 'PTZ' },
    { id: 4, name: 'Камера 04: Въезд / КПП', status: 'Maintenance', type: 'Dome' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-500 pb-12">
      <div className="bg-[#FF9500]/10 border border-[#FF9500]/20 p-4 rounded-2xl flex items-start sm:items-center space-x-3">
        <div className="mt-0.5 sm:mt-0">
          <Lock className="text-[#FF9500]" size={20} />
        </div>
        <p className="text-xs font-medium text-[#1D1D1F] leading-relaxed">
          <strong className="font-bold text-[#FF9500] mr-1">Внимание:</strong> 
          Прямая трансляция доступна только для авторизованных пользователей. 
          Запись архива хранится 30 дней. Модуль работает только в режиме просмотра.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {cameras.map((cam) => (
          <div key={cam.id} className="bg-[#1C1C1E] rounded-2xl overflow-hidden aspect-video relative group shadow-lg">
            {/* Video Placeholder */}
            <div className="w-full h-full flex items-center justify-center">
              <Video className="text-white/5" size={64} />
            </div>

            {/* Top-left Status Badge */}
            <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 bg-black/40 backdrop-blur-md rounded-full border border-white/10">
              <span className={`w-2 h-2 rounded-full ${
                cam.status === 'Online' ? 'bg-[#34C759] animate-pulse shadow-[0_0_8px_rgba(52,199,89,0.8)]' : 
                cam.status === 'Maintenance' ? 'bg-[#FF3B30]' : 'bg-[#8E8E93]'
              }`}></span>
              <span className="text-[10px] font-bold text-white uppercase tracking-widest">{cam.status}</span>
            </div>

            {/* Top-right Controls */}
            <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button className="p-2 bg-black/40 backdrop-blur-md rounded-lg text-white border border-white/10 hover:bg-black/60">
                <RefreshCw size={16} />
              </button>
              <button className="p-2 bg-black/40 backdrop-blur-md rounded-lg text-white border border-white/10 hover:bg-black/60">
                <Maximize2 size={16} />
              </button>
            </div>

            {/* Bottom Gradient Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent">
              <h4 className="text-white font-semibold text-sm">{cam.name}</h4>
              <p className="text-white/70 text-[10px] uppercase tracking-wider mt-1">
                {cam.type} Camera • IP: 192.168.10.{100 + cam.id}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
});

export default LiveModule;
