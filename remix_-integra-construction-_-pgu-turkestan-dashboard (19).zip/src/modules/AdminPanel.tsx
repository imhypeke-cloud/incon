import React, { useState } from 'react';
import { Shield, Users, Database, ChevronRight, Activity } from 'lucide-react';
import Card from '../components/Card';
import OptimizedImage from '../components/OptimizedImage';

const IOSSwitch: React.FC<{ checked: boolean; onChange: () => void }> = ({ checked, onChange }) => (
  <button
    onClick={onChange}
    className={`w-12 h-7 rounded-full transition-colors duration-300 flex items-center px-1 ${
      checked ? 'bg-[#34C759]' : 'bg-[#E5E5EA]'
    }`}
  >
    <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-300 ${checked ? 'translate-x-5' : 'translate-x-0'}`} />
  </button>
);

const StatsCard: React.FC<{ icon: any; label: string; value: string }> = ({ icon: Icon, label, value }) => (
  <Card padding="medium" className="flex items-center space-x-3 border-none shadow-sm">
    <div className="w-10 h-10 rounded-xl bg-[#F5F5F7] flex items-center justify-center text-[#007AFF]">
      <Icon size={20} />
    </div>
    <div>
      <p className="text-[10px] font-bold text-[#86868B] uppercase tracking-widest">{label}</p>
      <p className="text-lg font-semibold text-[#1D1D1F] tracking-tight">{value}</p>
    </div>
  </Card>
);

const TimelineItem: React.FC<{ avatar: string; name: string; action: string; time: string; isLast: boolean }> = ({ avatar, name, action, time, isLast }) => (
  <div className="flex gap-4 relative">
    {!isLast && <div className="absolute left-[19px] top-10 bottom-[-24px] w-0.5 bg-[#E5E5EA]" />}
    <OptimizedImage 
      src={avatar} 
      placeholderSrc={`${avatar}?blur=10`}
      alt={name} 
      className="w-10 h-10 rounded-full" 
    />
    <div className="flex-1 pb-6">
      <p className="text-sm font-semibold text-[#1D1D1F]">{name}</p>
      <p className="text-xs text-[#86868B]">{action}</p>
      <p className="text-[10px] text-[#86868B] mt-1">{time}</p>
    </div>
  </div>
);

const SettingsGroup: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="space-y-2">
    <h3 className="text-xs font-bold text-[#86868B] uppercase tracking-widest px-4">{title}</h3>
    <div className="bg-white rounded-xl overflow-hidden border border-black/[0.04]">
      {React.Children.map(children, (child, index) => (
        <div className="relative">
          {child}
          {index !== React.Children.count(children) - 1 && <div className="absolute bottom-0 left-4 right-0 h-[1px] bg-[#E5E5EA]" />}
        </div>
      ))}
    </div>
  </div>
);

const SettingsItem: React.FC<{ label: string; action?: React.ReactNode }> = ({ label, action }) => (
  <div className="h-[52px] px-4 flex items-center justify-between">
    <span className="text-sm text-[#1D1D1F]">{label}</span>
    {action || <ChevronRight size={18} className="text-[#C7C7CC]" />}
  </div>
);

const AdminPanel: React.FC = React.memo(() => {
  const [toggles, setToggles] = useState({ maintenance: false, notifications: true });

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 pb-12">
      {/* Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard icon={Users} label="Пользователей" value="1,248" />
        <StatsCard icon={Activity} label="Сессий" value="84" />
        <StatsCard icon={Database} label="Объем данных" value="1.2 TB" />
        <StatsCard icon={Shield} label="Версия" value="v2.4.0" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Activity Log */}
        <Card padding="medium" className="lg:col-span-2 border-none shadow-lg shadow-black/[0.03]">
          <h3 className="text-lg font-semibold text-[#1D1D1F] mb-6">Активность</h3>
          <div className="space-y-0">
            <TimelineItem avatar="https://picsum.photos/seed/1/40/40" name="Алексей И." action="Обновил план работ" time="10:30" isLast={false} />
            <TimelineItem avatar="https://picsum.photos/seed/2/40/40" name="Мария С." action="Загрузила отчет" time="09:15" isLast={false} />
            <TimelineItem avatar="https://picsum.photos/seed/3/40/40" name="Иван П." action="Изменил настройки" time="08:00" isLast={true} />
          </div>
        </Card>

        {/* Settings */}
        <div className="space-y-6">
          <SettingsGroup title="Основные">
            <SettingsItem label="Режим обслуживания" action={<IOSSwitch checked={toggles.maintenance} onChange={() => setToggles(p => ({...p, maintenance: !p.maintenance}))} />} />
            <SettingsItem label="Уведомления" action={<IOSSwitch checked={toggles.notifications} onChange={() => setToggles(p => ({...p, notifications: !p.notifications}))} />} />
          </SettingsGroup>
          <SettingsGroup title="Система">
            <SettingsItem label="Права доступа" />
            <SettingsItem label="Резервные копии" />
          </SettingsGroup>
        </div>
      </div>
    </div>
  );
});

export default AdminPanel;
