import React, { useState, useMemo } from 'react';
import { Equipment, EquipmentCategory } from '../types';
import { 
  Truck, 
  Construction, 
  Search, 
  ShieldCheck,
  Zap,
  Phone,
  User,
  Car,
  HardHat,
  Wrench
} from 'lucide-react';
import AppleCard from '../components/ui/AppleCard';

interface EquipmentModuleProps {
  data: Equipment[];
}

const EquipmentModule: React.FC<EquipmentModuleProps> = ({ data }) => {
  const [activeCategory, setActiveCategory] = useState<EquipmentCategory | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const stats = useMemo(() => {
    const safeData = Array.isArray(data) ? data : [];
    const total = safeData.reduce((acc, e) => acc + Number(e.total || 0), 0);
    const gen = safeData.reduce((acc, e) => acc + Number(e.genPodryad || 0), 0);
    const sub = safeData.reduce((acc, e) => acc + Number(e.subPodryad || 0), 0);
    return { total, gen, sub };
  }, [data]);

  const filteredData = useMemo(() => {
    const safeData = Array.isArray(data) ? data : [];
    return safeData.filter(e => {
      const catMatch = activeCategory === 'ALL' || e.category === activeCategory;
      const searchMatch = !searchQuery || 
        e.type?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        e.model?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        e.plateNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.operator?.toLowerCase().includes(searchQuery.toLowerCase());
      return catMatch && searchMatch;
    });
  }, [data, activeCategory, searchQuery]);

  const getCategoryIcon = (category: EquipmentCategory) => {
    switch (category) {
      case EquipmentCategory.TRUCKS: return <Truck size={20} />;
      case EquipmentCategory.EARTHMOVING: return <Construction size={20} />;
      case EquipmentCategory.SPECIAL: return <Zap size={20} />;
      case EquipmentCategory.TRANSPORT: return <Car size={20} />;
      case EquipmentCategory.LIFTING: return <HardHat size={20} />;
      case EquipmentCategory.ROAD: return <Wrench size={20} />;
      default: return <Wrench size={20} />;
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-[#007AFF] text-white rounded-2xl flex items-center justify-center shadow-lg shadow-[#007AFF]/20">
            <Truck size={24} />
          </div>
          <div>
            <h2 className="text-large-title text-[#1D1D1F] tracking-tight leading-none">Техника</h2>
            <p className="text-subhead text-[#86868B] mt-1">
              Управление парком и мониторинг ресурсов
            </p>
          </div>
        </div>
      </div>

      {/* Сводная статистика */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          icon={<Truck size={24} />} 
          label="Всего техники" 
          value={stats.total} 
          color="slate" 
        />
        <StatCard 
          icon={<ShieldCheck size={24} />} 
          label="Генподряд (Integra)" 
          value={stats.gen} 
          color="blue" 
        />
        <StatCard 
          icon={<Zap size={24} />} 
          label="Субподрядчики" 
          value={stats.sub} 
          color="orange" 
        />
      </div>

      {/* Панель инструментов */}
      <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
        <div className="flex flex-wrap items-center gap-2">
          <button 
            onClick={() => setActiveCategory('ALL')}
            className={`h-[36px] px-4 rounded-[10px] text-[13px] font-semibold transition-all duration-200 ${
              activeCategory === 'ALL' ? 'bg-[#007AFF] text-white shadow-md' : 'bg-white/80 backdrop-blur-xl text-[#1D1D1F] border border-black/[0.08] hover:bg-[#E5E5EA]'
            }`}
          >
            Все
          </button>
          {Object.values(EquipmentCategory).map(cat => (
            <button 
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`h-[36px] px-4 rounded-[10px] text-[13px] font-semibold transition-all duration-200 ${
                activeCategory === cat ? 'bg-[#007AFF] text-white shadow-md' : 'bg-white/80 backdrop-blur-xl text-[#1D1D1F] border border-black/[0.08] hover:bg-[#E5E5EA]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center space-x-3 w-full lg:w-auto">
          <div className="relative flex-1 lg:w-72 group">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#86868B] group-focus-within:text-[#007AFF] transition-colors" size={16} />
            <input 
              type="text" 
              placeholder="Поиск по модели, номеру..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-[40px] px-4 pl-11 border border-black/[0.08] rounded-xl bg-white/80 backdrop-blur-xl text-[15px] outline-none transition-all duration-200 placeholder:text-[#8E8E93] focus:border-[#007AFF] focus:ring-[3px] ring-[#007AFF]/10 w-full"
            />
          </div>
        </div>
      </div>

      {/* Таблица техники */}
      <AppleCard padding="none" className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-black/[0.04]">
                <th className="p-4 text-left text-caption-2 font-black text-[#86868B] uppercase tracking-widest">Тип / Модель</th>
                <th className="p-4 text-left text-caption-2 font-black text-[#86868B] uppercase tracking-widest">Гос. номер</th>
                <th className="p-4 text-left text-caption-2 font-black text-[#86868B] uppercase tracking-widest">Кол-во</th>
                <th className="p-4 text-left text-caption-2 font-black text-[#86868B] uppercase tracking-widest">Оператор</th>
                <th className="p-4 text-left text-caption-2 font-black text-[#86868B] uppercase tracking-widest">Собственник</th>
                <th className="p-4 text-right text-caption-2 font-black text-[#86868B] uppercase tracking-widest">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/[0.04]">
              {filteredData.map(e => (
                <tr key={e.id} className="hover:bg-[#F5F5F7] transition-colors group cursor-pointer">
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${e.ownerType === 'GEN' ? 'bg-[#007AFF]/10 text-[#007AFF]' : 'bg-[#FF9500]/10 text-[#FF9500]'}`}>
                        {getCategoryIcon(e.category)}
                      </div>
                      <div className="min-w-0">
                        <p className="text-callout font-semibold text-[#1D1D1F] truncate">{e.type}</p>
                        <p className="text-caption-2 text-[#86868B] truncate">{e.model}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="text-callout font-medium text-[#1D1D1F]">{e.plateNumber}</span>
                  </td>
                  <td className="p-4">
                    <span className="text-callout font-semibold text-[#1D1D1F]">{e.total} ед.</span>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <User size={14} className="text-[#86868B]" />
                      <span className="text-callout font-medium text-[#1D1D1F]">{e.operator}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center space-x-2">
                      <span className={`w-2 h-2 rounded-full ${e.ownerType === 'GEN' ? 'bg-[#007AFF]' : 'bg-[#FF9500]'}`} />
                      <span className="text-callout font-medium text-[#1D1D1F]">{e.ownerName}</span>
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <span className="h-[26px] px-3 rounded-full inline-flex items-center text-[12px] font-semibold bg-[#34C759]/10 text-[#34C759]">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#34C759] mr-2 animate-pulse" />
                      Работа
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </AppleCard>
    </div>
  );
};

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: number; color: string }> = ({ icon, label, value, color }) => {
  const iconColors: any = {
    slate: 'bg-[#1D1D1F] text-white',
    blue: 'bg-[#007AFF]/10 text-[#007AFF]',
    orange: 'bg-[#FF9500]/10 text-[#FF9500]'
  };

  return (
    <AppleCard hoverable padding="lg" className="flex items-center group">
      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm mr-5 transition-transform duration-300 group-hover:scale-110 ${iconColors[color]}`}>
        {icon}
      </div>
      <div>
        <p className="text-caption-1 font-black uppercase tracking-widest text-[#86868B] mb-1">
          {label}
        </p>
        <p className="text-large-title font-bold text-[#1D1D1F] leading-none">{value}</p>
      </div>
    </AppleCard>
  );
};

export default EquipmentModule;
