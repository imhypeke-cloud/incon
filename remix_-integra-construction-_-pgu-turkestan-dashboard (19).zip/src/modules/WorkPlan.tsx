import React, { useMemo, useState } from 'react';
import { 
  Search, 
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Filter,
  User,
  HardHat,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Clock
} from 'lucide-react';
import Card from '../components/Card';
import { WORK_PLAN_EVENTS, WORK_PLAN_FILTERS, WorkPlanEvent } from '../constants/workPlanData';

type ViewType = 'week' | 'month';

const WorkPlan: React.FC = () => {
  const [view, setView] = useState<ViewType>('week');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWeek, setSelectedWeek] = useState(0); // 0 to 3 for March 2026
  const [filterType, setFilterType] = useState<string | null>(null);
  const [filterResponsible, setFilterResponsible] = useState<string | null>(null);
  const [filterContractor, setFilterContractor] = useState<string | null>(null);

  const weekDates = useMemo(() => {
    const starts = [
      new Date(2026, 2, 2),
      new Date(2026, 2, 9),
      new Date(2026, 2, 16),
      new Date(2026, 2, 23)
    ];
    const start = starts[selectedWeek];
    return Array.from({ length: 7 }).map((_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      return d;
    });
  }, [selectedWeek]);

  const filteredEvents = useMemo(() => {
    return WORK_PLAN_EVENTS.filter(event => {
      const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           event.responsible.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = !filterType || event.type === filterType;
      const matchesResponsible = !filterResponsible || event.responsible === filterResponsible;
      const matchesContractor = !filterContractor || event.contractor === filterContractor;
      
      return matchesSearch && matchesType && matchesResponsible && matchesContractor;
    });
  }, [searchTerm, filterType, filterResponsible, filterContractor]);

  const getEventsForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return filteredEvents.filter(e => e.date === dateStr);
  };

  const weekRangeLabel = useMemo(() => {
    const start = weekDates[0];
    const end = weekDates[6];
    return `${start.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })} – ${end.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })}`;
  }, [weekDates]);

  return (
    <div className="h-full flex flex-col space-y-6 animate-in fade-in duration-500 p-1 pb-10 max-w-7xl mx-auto">
      
      {/* Header & Controls */}
      <Card className="flex flex-col md:flex-row items-center justify-between p-6 gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-[#007AFF] text-white rounded-2xl flex items-center justify-center shadow-lg shadow-[#007AFF]/20">
            <CalendarIcon size={24} />
          </div>
          <div>
            <h1 className="text-headline text-[#1D1D1F] uppercase tracking-tight leading-none">План работ</h1>
            <p className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest mt-1">Март 2026 • Мониторинг выполнения</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center bg-[#F5F5F7] p-1 rounded-xl border border-black/[0.04]">
            <button 
              onClick={() => setSelectedWeek(prev => Math.max(0, prev - 1))}
              className="p-2 hover:bg-white rounded-lg transition-all text-[#86868B] hover:text-[#1D1D1F]"
            >
              <ChevronLeft size={18} />
            </button>
            <span className="px-4 text-xs font-black uppercase tracking-widest text-[#1D1D1F] min-w-[140px] text-center">
              {weekRangeLabel}
            </span>
            <button 
              onClick={() => setSelectedWeek(prev => Math.min(3, prev + 1))}
              className="p-2 hover:bg-white rounded-lg transition-all text-[#86868B] hover:text-[#1D1D1F]"
            >
              <ChevronRight size={18} />
            </button>
          </div>

          <div className="relative group">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#C7C7CC] group-focus-within:text-[#007AFF] transition-colors" size={18} />
            <input 
              type="text"
              placeholder="ПОИСК ЗАДАЧ..."
              className="input-field w-64 pl-11 h-11"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </Card>

      <div className="flex flex-col lg:flex-row gap-6 flex-1 min-h-0">
        {/* Sidebar Filters */}
        <Card className="w-full lg:w-72 p-6 space-y-8 h-fit lg:sticky lg:top-6">
          <div className="flex items-center justify-between">
            <h3 className="text-caption-1 font-black uppercase tracking-widest text-[#1D1D1F] flex items-center">
              <Filter size={16} className="mr-2 text-[#007AFF]" />
              Фильтры
            </h3>
            <button 
              onClick={() => {
                setFilterType(null);
                setFilterResponsible(null);
                setFilterContractor(null);
                setSearchTerm('');
              }}
              className="text-[10px] text-[#007AFF] font-black uppercase tracking-widest hover:underline"
            >
              Сбросить
            </button>
          </div>

          <div className="space-y-6">
            <FilterGroup 
              title="Тип работ" 
              options={WORK_PLAN_FILTERS.types} 
              selected={filterType} 
              onSelect={setFilterType} 
            />
            <FilterGroup 
              title="Ответственный" 
              options={WORK_PLAN_FILTERS.responsibles} 
              selected={filterResponsible} 
              onSelect={setFilterResponsible} 
            />
            <FilterGroup 
              title="Подрядчик" 
              options={WORK_PLAN_FILTERS.contractors} 
              selected={filterContractor} 
              onSelect={setFilterContractor} 
            />
          </div>
        </Card>

        {/* Calendar Grid */}
        <div className="flex-1 min-w-0">
          <div className="grid grid-cols-1 md:grid-cols-7 gap-4 h-full">
            {weekDates.map((date, i) => (
              <div key={i} className="flex flex-col space-y-3 min-w-0">
                <div className="bg-white p-3 rounded-2xl border border-black/[0.04] shadow-sm flex flex-col items-center">
                  <span className="text-[10px] font-black text-[#86868B] uppercase tracking-widest">
                    {date.toLocaleDateString('ru-RU', { weekday: 'short' })}
                  </span>
                  <span className="text-lg font-black text-[#1D1D1F]">
                    {date.getDate()}
                  </span>
                </div>
                
                <div className="flex-1 space-y-3 overflow-y-auto custom-scrollbar pb-4 pr-1">
                  {getEventsForDate(date).map(event => (
                    <EventCard key={event.id} event={event} />
                  ))}
                  {getEventsForDate(date).length === 0 && (
                    <div className="h-24 border-2 border-dashed border-black/[0.04] rounded-2xl flex items-center justify-center">
                      <span className="text-[10px] font-bold text-[#C7C7CC] uppercase tracking-widest">Нет задач</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const FilterGroup: React.FC<{ title: string; options: string[]; selected: string | null; onSelect: (val: string | null) => void }> = ({ title, options, selected, onSelect }) => (
  <div className="space-y-3">
    <h4 className="text-[10px] font-black text-[#86868B] uppercase tracking-widest">{title}</h4>
    <div className="flex flex-wrap gap-2">
      {options.map(opt => (
        <button 
          key={opt} 
          onClick={() => onSelect(selected === opt ? null : opt)}
          className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-tight transition-all border ${
            selected === opt 
              ? 'bg-[#007AFF] text-white border-[#007AFF] shadow-md shadow-[#007AFF]/20' 
              : 'bg-[#F5F5F7] text-[#1D1D1F] border-transparent hover:border-black/10'
          }`}
        >
          {opt}
        </button>
      ))}
    </div>
  </div>
);

const EventCard: React.FC<{ event: WorkPlanEvent }> = ({ event }) => {
  const typeColors = {
    'Бетонирование': 'bg-[#007AFF]',
    'Монтаж МК': 'bg-[#FF9500]',
    'Трубопроводы': 'bg-[#AF52DE]',
    'Электрика': 'bg-[#34C759]',
    'Прочее': 'bg-[#8E8E93]'
  };

  const statusIcons = {
    'delay': <AlertCircle size={14} className="text-[#FF3B30]" />,
    'ahead': <TrendingUp size={14} className="text-[#34C759]" />,
    'normal': <CheckCircle2 size={14} className="text-[#007AFF]" />
  };

  return (
    <div className="bg-white p-4 rounded-2xl border border-black/[0.04] shadow-sm hover:shadow-md transition-all group cursor-pointer relative overflow-hidden">
      <div className={`absolute left-0 top-0 bottom-0 w-1 ${typeColors[event.type]}`} />
      
      <div className="flex justify-between items-start mb-3">
        <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-md text-white ${typeColors[event.type]}`}>
          {event.type}
        </span>
        {statusIcons[event.status]}
      </div>

      <h4 className="text-xs font-black text-[#1D1D1F] leading-tight mb-3 group-hover:text-[#007AFF] transition-colors">
        {event.title}
      </h4>

      <div className="space-y-2">
        <div className="flex items-center justify-between text-[10px]">
          <span className="text-[#86868B] font-medium">Прогресс</span>
          <span className={`font-black ${event.status === 'delay' ? 'text-[#FF3B30]' : 'text-[#1D1D1F]'}`}>
            {event.progress}%
          </span>
        </div>
        <div className="w-full bg-[#F5F5F7] h-1.5 rounded-full overflow-hidden">
          <div 
            className={`h-full rounded-full transition-all duration-500 ${event.status === 'delay' ? 'bg-[#FF3B30]' : 'bg-[#34C759]'}`}
            style={{ width: `${event.progress}%` }}
          />
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-black/[0.04] space-y-2">
        <div className="flex items-center text-[10px] text-[#86868B]">
          <User size={12} className="mr-2" />
          <span className="truncate">{event.responsible}</span>
        </div>
        <div className="flex items-center text-[10px] text-[#86868B]">
          <HardHat size={12} className="mr-2" />
          <span className="truncate">{event.contractor}</span>
        </div>
        <div className="flex items-center justify-between mt-2 pt-2 bg-[#F5F5F7] p-2 rounded-xl">
          <div className="flex flex-col">
            <span className="text-[8px] font-black text-[#86868B] uppercase">Объем</span>
            <span className="text-[10px] font-black text-[#1D1D1F]">{event.volume}</span>
          </div>
          <Clock size={12} className="text-[#C7C7CC]" />
        </div>
      </div>
    </div>
  );
};

export default WorkPlan;
