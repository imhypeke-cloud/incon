
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Title, HumanResource, Equipment, SupplyItem } from '../types';
import { INITIAL_TITLES, INITIAL_HR, INITIAL_EQUIPMENT, INITIAL_SUPPLY, INITIAL_TITLE_ALLOCATION, DATA_VERSION } from '../constants';

const STORAGE_KEYS = {
  TITLES: 'titles',
  HR: 'hrData',
  EQUIPMENT: 'equipmentData',
  SUPPLY: 'supplyData',
  ALLOCATION: 'titleAllocation',
  VERSION: 'dataVersion'
};

export const useProjectData = () => {
  const queryClient = useQueryClient();

  // Check version and reset if needed (one-time check)
  const checkVersion = () => {
    const savedVersion = localStorage.getItem(STORAGE_KEYS.VERSION);
    if (savedVersion !== DATA_VERSION) {
      localStorage.setItem(STORAGE_KEYS.TITLES, JSON.stringify(INITIAL_TITLES));
      localStorage.setItem(STORAGE_KEYS.HR, JSON.stringify(INITIAL_HR));
      localStorage.setItem(STORAGE_KEYS.EQUIPMENT, JSON.stringify(INITIAL_EQUIPMENT));
      localStorage.setItem(STORAGE_KEYS.SUPPLY, JSON.stringify(INITIAL_SUPPLY));
      localStorage.setItem(STORAGE_KEYS.ALLOCATION, JSON.stringify(INITIAL_TITLE_ALLOCATION));
      localStorage.setItem(STORAGE_KEYS.VERSION, DATA_VERSION);
    }
  };

  checkVersion();

  // Queries
  const titlesQuery = useQuery({
    queryKey: [STORAGE_KEYS.TITLES],
    queryFn: () => {
      const saved = localStorage.getItem(STORAGE_KEYS.TITLES);
      return saved ? JSON.parse(saved) : INITIAL_TITLES;
    }
  });

  const hrQuery = useQuery({
    queryKey: [STORAGE_KEYS.HR],
    queryFn: () => {
      const saved = localStorage.getItem(STORAGE_KEYS.HR);
      return saved ? JSON.parse(saved) : INITIAL_HR;
    }
  });

  const equipmentQuery = useQuery({
    queryKey: [STORAGE_KEYS.EQUIPMENT],
    queryFn: () => {
      const saved = localStorage.getItem(STORAGE_KEYS.EQUIPMENT);
      return saved ? JSON.parse(saved) : INITIAL_EQUIPMENT;
    }
  });

  const supplyQuery = useQuery({
    queryKey: [STORAGE_KEYS.SUPPLY],
    queryFn: () => {
      const saved = localStorage.getItem(STORAGE_KEYS.SUPPLY);
      return saved ? JSON.parse(saved) : INITIAL_SUPPLY;
    }
  });

  const allocationQuery = useQuery({
    queryKey: [STORAGE_KEYS.ALLOCATION],
    queryFn: () => {
      const saved = localStorage.getItem(STORAGE_KEYS.ALLOCATION);
      return saved ? JSON.parse(saved) : INITIAL_TITLE_ALLOCATION;
    }
  });

  // Mutations
  const updateTitles = useMutation({
    mutationFn: (newTitles: Title[]) => {
      localStorage.setItem(STORAGE_KEYS.TITLES, JSON.stringify(newTitles));
      return Promise.resolve(newTitles);
    },
    onSuccess: (data) => {
      queryClient.setQueryData([STORAGE_KEYS.TITLES], data);
    }
  });

  const updateHr = useMutation({
    mutationFn: (newData: HumanResource[]) => {
      localStorage.setItem(STORAGE_KEYS.HR, JSON.stringify(newData));
      return Promise.resolve(newData);
    },
    onSuccess: (data) => {
      queryClient.setQueryData([STORAGE_KEYS.HR], data);
    }
  });

  const updateEquipment = useMutation({
    mutationFn: (newData: Equipment[]) => {
      localStorage.setItem(STORAGE_KEYS.EQUIPMENT, JSON.stringify(newData));
      return Promise.resolve(newData);
    },
    onSuccess: (data) => {
      queryClient.setQueryData([STORAGE_KEYS.EQUIPMENT], data);
    }
  });

  const updateSupply = useMutation({
    mutationFn: (newData: SupplyItem[]) => {
      localStorage.setItem(STORAGE_KEYS.SUPPLY, JSON.stringify(newData));
      return Promise.resolve(newData);
    },
    onSuccess: (data) => {
      queryClient.setQueryData([STORAGE_KEYS.SUPPLY], data);
    }
  });

  const updateAllocation = useMutation({
    mutationFn: (newData: any[]) => {
      localStorage.setItem(STORAGE_KEYS.ALLOCATION, JSON.stringify(newData));
      return Promise.resolve(newData);
    },
    onSuccess: (data) => {
      queryClient.setQueryData([STORAGE_KEYS.ALLOCATION], data);
    }
  });

  return {
    titles: titlesQuery.data || INITIAL_TITLES,
    hrData: hrQuery.data || INITIAL_HR,
    equipmentData: equipmentQuery.data || INITIAL_EQUIPMENT,
    supplyData: supplyQuery.data || INITIAL_SUPPLY,
    titleAllocation: allocationQuery.data || INITIAL_TITLE_ALLOCATION,
    isLoading: titlesQuery.isLoading || hrQuery.isLoading || equipmentQuery.isLoading || supplyQuery.isLoading || allocationQuery.isLoading,
    updateTitles: updateTitles.mutate,
    updateHr: updateHr.mutate,
    updateEquipment: updateEquipment.mutate,
    updateSupply: updateSupply.mutate,
    updateAllocation: updateAllocation.mutate
  };
};
