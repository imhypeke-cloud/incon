import { useState, useEffect } from 'react';
import { fetchData as fetchModuleData, saveData as saveModuleData } from '../services/apiService';

export function useModuleData<T>(moduleName: string, initialData: T) {
  const [data, setData] = useState<T>(initialData);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await fetchModuleData(moduleName);
        if (result) {
          setData(result);
        } else {
          // If not found, save the initial data to the server
          await saveModuleData(moduleName, initialData);
          setData(initialData);
        }
      } catch (err) {
        console.error(`Error loading ${moduleName} data:`, err);
        setError((err as Error).message);
        // Fallback to initial data
        setData(initialData);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [moduleName]);

  const updateData = async (newData: T) => {
    setData(newData);
    try {
      await saveModuleData(moduleName, newData);
    } catch (err) {
      console.error(`Error saving ${moduleName} data:`, err);
      setError((err as Error).message);
    }
  };

  return { data, updateData, isLoading, error };
}
