
import React, { useState, useEffect, Suspense, lazy } from 'react';
import { User, ModuleType, AuditLog, Title, HumanResource, Equipment, SupplyItem, UserRole } from '../types';
import Sidebar from '../components/layout/Sidebar';
import Header from '../components/layout/Header';
import UploadModal from '../components/UploadModal';
import BackToTop from '../components/BackToTop';
import { useProjectData } from '../hooks/useProjectData';
import { INITIAL_TITLES, INITIAL_HR, INITIAL_EQUIPMENT, INITIAL_SUPPLY, DATA_VERSION, INITIAL_TITLE_ALLOCATION } from '../constants';

// Lazy load modules
const GeneralStatus = lazy(() => import('../modules/GeneralStatus'));
const TitlesModule = lazy(() => import('../modules/TitlesModule'));
const HRResources = lazy(() => import('../modules/HRResources'));
const EquipmentModule = lazy(() => import('../modules/EquipmentModule'));
const ExecutionSummary = lazy(() => import('../modules/ExecutionSummary'));
const Subcontractors = lazy(() => import('../modules/Subcontractors'));
const AdminPanel = lazy(() => import('../modules/AdminPanel'));
const LiveModule = lazy(() => import('../modules/LiveModule'));
const SupplyRegistry = lazy(() => import('../modules/SupplyRegistry'));
const Handbook = lazy(() => import('../modules/Handbook'));
const GenStructure = lazy(() => import('../modules/GenStructure'));
const ProjectManagers = lazy(() => import('../modules/ProjectManagers'));
const WorkPlan = lazy(() => import('../modules/WorkPlan'));

// Loading component
const ModuleLoader = () => (
  <div className="flex items-center justify-center h-full">
    <div className="flex flex-col items-center gap-4">
      <div className="w-12 h-12 border-4 border-[#007AFF]/20 border-t-[#007AFF] rounded-full animate-spin"></div>
      <p className="text-subhead text-[#86868B] animate-pulse">Загрузка модуля...</p>
    </div>
  </div>
);

interface DashboardProps {
  user: User;
  onLogout: () => void;
  auditLogs: AuditLog[];
  setAuditLogs: React.Dispatch<React.SetStateAction<AuditLog[]>>;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout, auditLogs, setAuditLogs }) => {
  const [activeModule, setActiveModule] = useState<ModuleType>(() => {
    const saved = localStorage.getItem('activeModule');
    return (saved as ModuleType) || 'GENERAL_STATUS';
  });
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  
  // Sidebar State
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Use React Query for data
  const { 
    titles, 
    hrData, 
    equipmentData, 
    supplyData, 
    titleAllocation, 
    updateTitles, 
    updateHr, 
    updateEquipment, 
    updateSupply, 
    updateAllocation 
  } = useProjectData();

  // Persist active module
  useEffect(() => {
    localStorage.setItem('activeModule', activeModule);
  }, [activeModule]);

  // Determine read-only status based on role
  // ADMIN: Can edit
  // LEADERSHIP (inconshym) & VIEWER: Read Only
  const isReadOnly = user.role !== UserRole.ADMIN;

  // Auto-collapse sidebar on tablet screens initially
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768 && window.innerWidth < 1280) {
        setIsSidebarCollapsed(true);
      } else if (window.innerWidth >= 1280) {
        setIsSidebarCollapsed(false);
      }
    };

    // Set initial state
    handleResize();

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleMenuClick = React.useCallback(() => {
    if (window.innerWidth >= 1024) {
      // Desktop: Toggle collapse
      setIsSidebarCollapsed(prev => !prev);
    } else {
      // Mobile: Toggle drawer
      setIsMobileMenuOpen(true);
    }
  }, []);

  const handleUpdateTitle = React.useCallback((updatedTitle: Title) => {
    // Double check just in case
    if (isReadOnly) return;

    const newTitles = titles.map(t => t.id === updatedTitle.id ? updatedTitle : t);
    updateTitles(newTitles);
    
    // Log change
    const newLog: AuditLog = {
      id: Math.random().toString(36).substr(2, 9),
      user: user.name,
      role: user.role,
      timestamp: new Date().toLocaleString(),
      action: `Редактирование титула: ${updatedTitle.number}`
    };
    setAuditLogs(prev => [newLog, ...prev]);
  }, [isReadOnly, user.name, user.role, setAuditLogs, titles, updateTitles]);

  const handleUploadSuccess = React.useCallback((module: ModuleType, newData: any) => {
    const timestamp = new Date().toLocaleString();
    const action = `Загрузка данных в модуль: ${module}`;
    
    // Update local state based on module
    if (module === 'TITLES') updateTitles(newData);
    if (module === 'HR_RESOURCES') updateHr(newData);
    if (module === 'EQUIPMENT') updateEquipment(newData);
    if (module === 'SUPPLY') updateSupply(newData);

    // Update Audit Logs
    const newLog: AuditLog = {
      id: Math.random().toString(36).substr(2, 9),
      user: user.name,
      role: user.role,
      timestamp,
      action
    };
    setAuditLogs(prev => [newLog, ...prev]);
    setIsUploadModalOpen(false);
  }, [user.name, user.role, setAuditLogs, updateTitles, updateHr, updateEquipment, updateSupply]);

  const renderModule = () => {
    switch (activeModule) {
      case 'GENERAL_STATUS': return <GeneralStatus onNavigate={setActiveModule} titles={titles} hr={hrData} equipment={equipmentData} />;
      case 'TITLES': return <TitlesModule user={user} titles={titles} onUpdateTitle={handleUpdateTitle} />;
      case 'HR_RESOURCES': return <HRResources />;
      case 'EQUIPMENT': return <EquipmentModule data={equipmentData} />;
      case 'EXECUTION_SUMMARY': return <ExecutionSummary />;
      case 'SUBCONTRACTORS': return <Subcontractors />;
      case 'ADMIN_PANEL': return <AdminPanel />;
      case 'LIVE': return <LiveModule />;
      case 'SUPPLY': return <SupplyRegistry data={supplyData} auditLogs={auditLogs} />;
      case 'HANDBOOK': return <Handbook />;
      case 'GEN_STRUCTURE': return <GenStructure />;
      case 'PROJECT_MANAGERS': return <ProjectManagers />;
      case 'WORK_PLAN': return <WorkPlan />;
      default: return <GeneralStatus onNavigate={setActiveModule} titles={titles} hr={hrData} equipment={equipmentData} />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#F5F5F7] text-[#1D1D1F] overflow-hidden relative">
      <Sidebar 
        activeModule={activeModule} 
        setActiveModule={(m) => {
          setActiveModule(m);
          setIsMobileMenuOpen(false);
        }} 
        userRole={user.role} 
        isCollapsed={isSidebarCollapsed}
        toggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        isMobileOpen={isMobileMenuOpen}
        closeMobileMenu={() => setIsMobileMenuOpen(false)}
      />
      
      <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${isSidebarCollapsed ? 'lg:pl-[80px]' : 'lg:pl-[280px]'}`}>
        <Header 
          user={user} 
          onLogout={onLogout} 
          activeModule={activeModule} 
          onUploadClick={() => setIsUploadModalOpen(true)}
          onMenuClick={handleMenuClick}
        />
        <main className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
          <div className="container-grid h-full">
            <Suspense fallback={<ModuleLoader />}>
              {renderModule()}
            </Suspense>
          </div>
          <BackToTop />
        </main>
      </div>

      <UploadModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)} 
        onSuccess={handleUploadSuccess}
        userRole={user.role}
      />
    </div>
  );
};

export default Dashboard;
