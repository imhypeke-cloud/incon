import React from 'react';
import AppleLayout from '../components/layout/AppleLayout';
import AppleCard from '../components/ui/AppleCard';
import AppleBadge from '../components/ui/AppleBadge';
import { Truck, AlertTriangle, CheckCircle2 } from 'lucide-react';

const Technique: React.FC = () => {
  const equipment = [
    { id: 1, name: 'Экскаватор CAT 320', status: 'active', location: 'Титул 101', operator: 'Иванов И.' },
    { id: 2, name: 'Бульдозер Komatsu D65', status: 'maintenance', location: 'База', operator: 'Петров С.' },
    { id: 3, name: 'Самосвал Scania P380', status: 'active', location: 'Титул 102', operator: 'Сидоров А.' },
  ];

  return (
    <AppleLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-[#1D1D1F]">Техника и механизация</h1>
          <div className="flex gap-2">
            <AppleBadge variant="success">В работе: 12</AppleBadge>
            <AppleBadge variant="warning">ТО: 2</AppleBadge>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {equipment.map((item) => (
            <AppleCard key={item.id} hoverable>
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-[#007AFF]/10 rounded-xl text-[#007AFF]">
                  <Truck size={24} />
                </div>
                <AppleBadge variant={item.status === 'active' ? 'success' : 'warning'}>
                  {item.status === 'active' ? 'В работе' : 'На ТО'}
                </AppleBadge>
              </div>
              
              <h3 className="text-lg font-semibold text-[#1D1D1F] mb-1">{item.name}</h3>
              <p className="text-sm text-[#86868B] mb-4">{item.location}</p>
              
              <div className="pt-4 border-t border-black/[0.04] flex items-center justify-between">
                <span className="text-xs text-[#86868B]">Оператор:</span>
                <span className="text-xs font-medium text-[#1D1D1F]">{item.operator}</span>
              </div>
            </AppleCard>
          ))}
        </div>
      </div>
    </AppleLayout>
  );
};

export default Technique;
