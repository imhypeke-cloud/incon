export const callGeminiAI = async (prompt: string, fileData?: { data: string, mimeType: string }) => {
  const response = await fetch('/api/gemini', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt,
      data: fileData?.data,
      mimeType: fileData?.mimeType
    })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || 'Failed to call AI');
  }

  return await response.json();
};

export const checkHealth = async () => {
  const response = await fetch('/api/health');
  if (!response.ok) {
    throw new Error('API is not healthy');
  }
  return await response.json();
};

export const fetchData = async (moduleName: string) => {
  const response = await fetch(`/api/data?module=${moduleName}`);
  if (!response.ok) {
    if (response.status === 404) return null;
    throw new Error(`Failed to fetch data for ${moduleName}`);
  }
  return await response.json();
};

export const saveData = async (moduleName: string, data: any) => {
  const response = await fetch(`/api/data?module=${moduleName}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!response.ok) {
    throw new Error(`Failed to save data for ${moduleName}`);
  }
  return await response.json();
};

export const saveLog = async (log: any) => {
  const response = await fetch('/api/logs', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(log)
  });
  if (!response.ok) {
    throw new Error('Failed to save log');
  }
  return await response.json();
};
