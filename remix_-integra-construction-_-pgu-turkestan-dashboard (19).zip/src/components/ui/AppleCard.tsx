
import React from 'react';

interface AppleCardProps {
  children: React.ReactNode;
  className?: string;
  hoverable?: boolean;
  padding?: 'none' | 'sm' | 'md' | 'lg';
}

const AppleCard: React.FC<AppleCardProps> = ({ 
  children, 
  className = '', 
  hoverable = false,
  padding = 'md'
}) => {
  const paddingClasses = {
    none: 'p-0',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8'
  };

  return (
    <div className={`
      bg-white/80 backdrop-blur-xl 
      rounded-[20px] 
      border border-black/[0.08] 
      shadow-[0_4px_24px_rgba(0,0,0,0.06)] 
      transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]
      ${hoverable ? 'hover:shadow-[0_8px_32px_rgba(0,0,0,0.1)] hover:-translate-y-0.5 cursor-pointer' : ''}
      ${paddingClasses[padding]}
      ${className}
    `}>
      {children}
    </div>
  );
};

export default AppleCard;
