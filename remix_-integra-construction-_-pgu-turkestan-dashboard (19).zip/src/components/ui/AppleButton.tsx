import React from 'react';

interface AppleButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  children: React.ReactNode;
  className?: string;
}

const AppleButton: React.FC<AppleButtonProps> = ({ 
  variant = 'primary', 
  size = 'md', 
  children, 
  className = '', 
  ...props 
}) => {
  const baseStyles = 'inline-flex items-center justify-center font-semibold transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none';
  
  const variants = {
    primary: 'bg-[#007AFF] text-white hover:bg-[#0056CC] shadow-sm',
    secondary: 'bg-[#E5E5EA] text-[#1D1D1F] hover:bg-[#D1D1D6]',
    outline: 'bg-transparent border border-[#D2D2D7] text-[#1D1D1F] hover:bg-[#F5F5F7]',
    ghost: 'bg-transparent text-[#007AFF] hover:bg-[#007AFF]/10',
    danger: 'bg-[#FF3B30] text-white hover:bg-[#D70015] shadow-sm',
  };
  
  const sizes = {
    sm: 'h-8 px-3 text-xs rounded-lg',
    md: 'h-11 px-6 text-[15px] rounded-xl',
    lg: 'h-14 px-8 text-lg rounded-2xl',
    icon: 'h-10 w-10 rounded-xl',
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default AppleButton;
