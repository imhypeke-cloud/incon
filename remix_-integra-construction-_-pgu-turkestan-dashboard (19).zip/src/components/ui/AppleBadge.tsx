import React from 'react';

interface AppleBadgeProps {
  children: React.ReactNode;
  variant?: 'success' | 'warning' | 'error' | 'info' | 'neutral';
  className?: string;
}

const AppleBadge: React.FC<AppleBadgeProps> = ({ 
  children, 
  variant = 'info', 
  className = '' 
}) => {
  const variants = {
    success: 'bg-[#34C759]/10 text-[#34C759] border-[#34C759]/20',
    warning: 'bg-[#FF9500]/10 text-[#FF9500] border-[#FF9500]/20',
    error: 'bg-[#FF3B30]/10 text-[#FF3B30] border-[#FF3B30]/20',
    info: 'bg-[#007AFF]/10 text-[#007AFF] border-[#007AFF]/20',
    neutral: 'bg-[#86868B]/10 text-[#86868B] border-[#86868B]/20',
  };

  return (
    <span className={`
      inline-flex items-center px-2.5 py-0.5 
      rounded-full text-[11px] font-black uppercase tracking-widest 
      border ${variants[variant]} 
      ${className}
    `}>
      {children}
    </span>
  );
};

export default AppleBadge;
