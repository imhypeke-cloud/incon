
import React, { useState } from 'react';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  fallbackSrc?: string;
  placeholderSrc?: string;
  alt: string;
}

const OptimizedImage: React.FC<OptimizedImageProps> = ({ 
  src, 
  fallbackSrc, 
  placeholderSrc, 
  alt, 
  className,
  ...props 
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);

  const handleLoad = () => {
    setIsLoaded(true);
  };

  const handleError = () => {
    setError(true);
  };

  // Simulate WebP by changing extension if it's a known pattern, 
  // but since we use external URLs like picsum, we just use the provided src.
  // In a real app, we'd have multiple formats.
  
  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Placeholder / Blur effect */}
      {placeholderSrc && !isLoaded && !error && (
        <img
          src={placeholderSrc}
          alt={alt}
          className="absolute inset-0 w-full h-full object-cover blur-lg scale-110 transition-opacity duration-500"
          referrerPolicy="no-referrer"
        />
      )}
      
      <img
        src={error && fallbackSrc ? fallbackSrc : src}
        alt={alt}
        onLoad={handleLoad}
        onError={handleError}
        className={`w-full h-full object-cover transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
        loading="lazy"
        referrerPolicy="no-referrer"
        {...props}
      />
    </div>
  );
};

export default OptimizedImage;
