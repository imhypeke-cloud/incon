import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';

interface AppleLayoutProps {
  children: React.ReactNode;
}

const AppleLayout: React.FC<AppleLayoutProps> = ({ children }) => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Mock user for Header
  const user = {
    name: 'Администратор',
    role: 'ADMIN' as any,
    login: 'admin'
  };

  return (
    <div className="flex h-screen w-full bg-[#F5F5F7] text-[#1D1D1F] overflow-hidden relative">
      <Sidebar 
        activeModule="GENERAL_STATUS" 
        setActiveModule={() => {}} 
        userRole={user.role} 
        isCollapsed={isSidebarCollapsed}
        toggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        isMobileOpen={isMobileMenuOpen}
        closeMobileMenu={() => setIsMobileMenuOpen(false)}
      />
      
      <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${isSidebarCollapsed ? 'lg:pl-[80px]' : 'lg:pl-[280px]'}`}>
        <Header 
          user={user} 
          onLogout={() => {}} 
          activeModule="GENERAL_STATUS" 
          onUploadClick={() => {}}
          onMenuClick={() => {
            if (window.innerWidth >= 1024) {
              setIsSidebarCollapsed(!isSidebarCollapsed);
            } else {
              setIsMobileMenuOpen(true);
            }
          }}
        />
        <main className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AppleLayout;
