
import React, { useState, useEffect } from 'react';
import { User, ModuleType, UserRole } from '../../types';
import { LogOut, Bell, Search, User as UserIcon, CloudUpload, Menu } from 'lucide-react';

interface HeaderProps {
  user: User;
  onLogout: () => void;
  activeModule: ModuleType;
  onUploadClick: () => void;
  onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout, activeModule, onUploadClick, onMenuClick }) => {
  const [searchValue, setSearchValue] = useState('');

  useEffect(() => {
    const handler = setTimeout(() => {
      if (searchValue) {
        console.log('Searching for:', searchValue);
        // Here you would typically call a search API or update a global search state
      }
    }, 300);

    return () => clearTimeout(handler);
  }, [searchValue]);

  const getModuleTitle = () => {
    switch (activeModule) {
      case 'GENERAL_STATUS': return 'Общий статус';
      case 'TITLES': return 'Прогресс титулов';
      case 'WORK_PLAN': return 'План работ';
      case 'HR_RESOURCES': return 'Расстановка HR';
      case 'EQUIPMENT': return 'Техника и механизация';
      case 'EXECUTION_SUMMARY': return 'Сводка выполнения работ';
      case 'SUBCONTRACTORS': return 'Реестр субподрядчиков';
      case 'ADMIN_PANEL': return 'Панель администратора';
      case 'LIVE': return 'Видеотрансляция объектов';
      case 'SUPPLY': return 'Реестр снабжения';
      case 'HANDBOOK': return 'Справочник НТД';
      case 'GEN_STRUCTURE': return 'Структура генподряда';
      case 'PROJECT_MANAGERS': return 'Руководители проектов';
      default: return 'Панель управления';
    }
  };

  return (
    <header className="h-[64px] bg-white/80 backdrop-blur-xl border-b border-black/[0.08] flex items-center justify-between px-6 sticky top-0 z-30 transition-apple">
      <div className="flex items-center space-x-4">
        {/* Mobile Menu Button */}
        <button 
          onClick={onMenuClick}
          className="lg:hidden btn-icon"
        >
          <Menu size={20} />
        </button>

        <div className="flex flex-col">
          <h2 className="text-headline font-semibold text-[#1D1D1F] tracking-tight leading-tight">{getModuleTitle()}</h2>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="w-1.5 h-1.5 bg-[#34C759] rounded-full"></span>
            <span className="text-caption-2 font-black text-[#86868B] uppercase tracking-widest">Live System</span>
          </div>
        </div>
        
        <div className="hidden xl:flex items-center ml-6 w-[320px]">
          <div className="relative w-full">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#86868B]" />
            <input 
              type="text" 
              placeholder="Поиск..." 
              className="h-[40px] px-4 pl-11 border border-[#D2D2D7] rounded-xl bg-white text-[15px] outline-none transition-all duration-200 placeholder:text-[#8E8E93] focus:border-[#007AFF] focus:ring-[3px] ring-[#007AFF]/10 w-full"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="flex items-center space-x-3 md:space-x-4">
        {/* Upload Button: Only for ADMIN */}
        {user.role === UserRole.ADMIN && (
          <button 
            onClick={onUploadClick}
            className="btn-primary"
          >
            <CloudUpload size={18} className="mr-2" />
            <span className="hidden md:inline">Импорт данных</span>
          </button>
        )}

        <button className="btn-icon relative">
          <Bell size={20} />
          <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-[#FF3B30] rounded-full border-2 border-white"></span>
        </button>

        <div className="h-8 w-px bg-black/[0.08] hidden sm:block"></div>

        <div className="flex items-center space-x-3">
          <div className="text-right hidden md:block">
            <p className="text-callout font-medium text-[#1D1D1F] leading-none">{user.name}</p>
            <p className="text-caption-2 text-[#86868B] font-black uppercase tracking-widest mt-1">{user.role}</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#007AFF] to-[#5856D6] flex items-center justify-center text-white shadow-sm shrink-0 overflow-hidden">
            <UserIcon size={20} />
          </div>
          <button 
            onClick={onLogout}
            className="btn-icon hover:text-[#FF3B30] hover:bg-[#FF3B30]/10 ml-1"
            title="Выход"
          >
            <LogOut size={20} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
