import { useState } from 'react';

export default function Login({ onLogin }: { onLogin?: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Login attempt:', email);
    onLogin?.();
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F5F5F7] p-4">
      <form onSubmit={handleSubmit} className="bg-white/80 backdrop-blur-xl rounded-[20px] p-8 shadow-[0_4px_24px_rgba(0,0,0,0.06)] w-full max-w-md border border-black/[0.04]">
        <h2 className="text-2xl font-semibold text-[#1D1D1F] mb-6">Вход в систему</h2>
        <input 
          type="email" 
          placeholder="Email" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          className="w-full h-11 px-4 rounded-xl border border-[#D2D2D7] mb-4 focus:outline-none focus:ring-2 focus:ring-[#007AFF] bg-white"
          required
        />
        <input 
          type="password" 
          placeholder="Пароль" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          className="w-full h-11 px-4 rounded-xl border border-[#D2D2D7] mb-6 focus:outline-none focus:ring-2 focus:ring-[#007AFF] bg-white"
          required
        />
        <button 
          type="submit" 
          className="w-full h-11 bg-[#007AFF] text-white rounded-xl font-semibold hover:bg-[#0056CC] transition-all duration-200"
        >
          Войти
        </button>
      </form>
    </div>
  );
}
