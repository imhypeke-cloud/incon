import AppleLayout from './components/layout/AppleLayout';

export default function App() {
  return (
    <AppleLayout>
      <div className="p-6 text-[#1D1D1F]">
        <h1 className="text-2xl font-semibold mb-4">Integra Construction</h1>
        <p>Dashboard loaded successfully ✅</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          <div className="bg-white/80 backdrop-blur-xl rounded-[20px] p-6 shadow-[0_4px_24px_rgba(0,0,0,0.06)] border border-black/[0.04]">
            <h3 className="text-lg font-semibold text-[#1D1D1F] mb-2">Статус проекта</h3>
            <p className="text-3xl font-bold text-[#007AFF]">95%</p>
            <p className="text-sm text-[#86868B]">Выполнено</p>
          </div>
        </div>
      </div>
    </AppleLayout>
  );
}
