
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (login: string, pass: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [login, setLogin] = useState('');
  const [pass, setPass] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(login, pass);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-600/5 -skew-x-12 translate-x-1/4"></div>
      <div className="absolute bottom-0 left-0 w-1/3 h-1/2 bg-rose-600/5 skew-y-12 -translate-x-1/4"></div>

      <div className="max-w-md w-full relative z-10">
        <div className="bg-white rounded-[2rem] p-10 shadow-2xl shadow-black/50 border border-white/10">
          <div className="flex flex-col items-center mb-10">
            <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-xl shadow-blue-500/20 mb-4">IC</div>
            <h1 className="text-2xl font-black text-slate-800 tracking-tight text-center uppercase">Integra Construction</h1>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] mt-2">PGU Turkestan | Portal v2.4</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 mb-2 block">Логин</label>
              <input 
                type="text" 
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-800 font-bold placeholder-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                placeholder="inconshym / admin / viewer"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1 mb-2 block">Пароль</label>
              <input 
                type="password" 
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-800 font-bold placeholder-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                placeholder="••••••••"
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-slate-900 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-500/10 hover:bg-blue-600 hover:shadow-blue-500/30 transition-all uppercase tracking-widest text-sm"
            >
              Войти в систему
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[10px] text-slate-300 font-bold uppercase">© 2025 Integra Construction</span>
            <div className="flex space-x-2">
              <div className="w-2 h-2 rounded-full bg-slate-100"></div>
              <div className="w-2 h-2 rounded-full bg-slate-100"></div>
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
