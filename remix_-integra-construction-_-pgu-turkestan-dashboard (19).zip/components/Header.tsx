
import React from 'react';
import { User, ModuleType, UserRole } from '../types';
import { LogOut, Bell, Search, User as UserIcon, CloudUpload, Menu } from 'lucide-react';

interface HeaderProps {
  user: User;
  onLogout: () => void;
  activeModule: ModuleType;
  onUploadClick: () => void;
  onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout, activeModule, onUploadClick, onMenuClick }) => {
  const getModuleTitle = () => {
    switch (activeModule) {
      case 'GENERAL_STATUS': return 'Общий статус';
      case 'TITLES': return 'Прогресс титулов';
      case 'HR_RESOURCES': return 'Расстановка HR';
      case 'EQUIPMENT': return 'Техника и механизация';
      case 'EXECUTION_SUMMARY': return 'Сводка выполнения работ';
      case 'SUBCONTRACTORS': return 'Реестр субподрядчиков';
      case 'ADMIN_PANEL': return 'Панель администратора';
      case 'LIVE': return 'Видеотрансляция объектов';
      case 'SUPPLY': return 'Реестр снабжения';
      case 'HANDBOOK': return 'Справочник НТД';
      case 'GEN_STRUCTURE': return 'Структура генподряда';
      case 'PROJECT_MANAGERS': return 'Руководители проектов (Участки)';
      default: return 'Панель управления';
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 md:px-6 sticky top-0 z-20 transition-all duration-300">
      <div className="flex items-center space-x-3 md:space-x-4">
        {/* Mobile/Desktop Menu Button */}
        <button 
          onClick={onMenuClick}
          className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <Menu size={24} />
        </button>

        <h2 className="text-sm md:text-lg font-bold text-slate-800 tracking-tight truncate max-w-[150px] md:max-w-none">{getModuleTitle()}</h2>
        
        <div className="hidden xl:flex items-center bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
          <Search size={14} className="text-slate-400" />
          <input 
            type="text" 
            placeholder="Поиск по разделу..." 
            className="bg-transparent border-none focus:ring-0 text-xs text-slate-600 ml-2 w-48 outline-none"
          />
        </div>
      </div>

      <div className="flex items-center space-x-2 md:space-x-6">
        {/* Upload Button: Only for ADMIN */}
        {user.role === UserRole.ADMIN && (
          <button 
            onClick={onUploadClick}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 md:px-4 md:py-2 rounded-xl text-xs font-bold transition-all shadow-lg shadow-blue-500/20"
          >
            <CloudUpload size={16} />
            <span className="hidden md:inline">Загрузить данные</span>
          </button>
        )}

        <button className="relative text-slate-400 hover:text-slate-600 transition-colors p-2">
          <Bell size={20} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
        </button>

        <div className="h-8 w-[1px] bg-slate-200 hidden sm:block"></div>

        <div className="flex items-center space-x-3">
          <div className="text-right hidden md:block">
            <p className="text-sm font-bold text-slate-800 leading-none">{user.name}</p>
            <p className="text-[10px] text-slate-500 font-medium uppercase tracking-tighter mt-1">{user.role}</p>
          </div>
          <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 border border-slate-200 shadow-sm shrink-0">
            <UserIcon size={18} className="md:w-5 md:h-5" />
          </div>
          <button 
            onClick={onLogout}
            className="p-2 text-slate-400 hover:text-rose-500 transition-colors rounded-lg hover:bg-rose-50"
            title="Выход"
          >
            <LogOut size={20} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
