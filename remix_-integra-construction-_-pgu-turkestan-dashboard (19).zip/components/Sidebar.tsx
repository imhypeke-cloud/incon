
import React, { useMemo } from 'react';
import { ModuleType, UserRole } from '../types';
import { 
  LayoutDashboard, 
  Files, 
  TableProperties, 
  CalendarDays, 
  Calendar,
  Users, 
  HardHat, 
  Truck, 
  BookOpen, 
  Package, 
  Network, 
  Video, 
  ShieldCheck,
  UserRoundCheck,
  ChevronLeft,
  ChevronRight,
  X
} from 'lucide-react';

interface SidebarProps {
  activeModule: ModuleType;
  setActiveModule: (m: ModuleType) => void;
  userRole: UserRole;
  isCollapsed: boolean;
  toggleCollapse: () => void;
  isMobileOpen: boolean;
  closeMobileMenu: () => void;
}

const SidebarContent = ({
  isCollapsed,
  activeModule,
  setActiveModule,
  filteredMenuItems,
  userRole
}: {
  isCollapsed: boolean;
  activeModule: ModuleType;
  setActiveModule: (m: ModuleType) => void;
  filteredMenuItems: any[];
  userRole: UserRole;
}) => (
    <>
      <div className={`flex items-center ${isCollapsed ? 'justify-center p-4' : 'p-6 space-x-3'} transition-all duration-300`}>
        <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20 shrink-0 transition-all duration-300">IC</div>
        
        <div className={`overflow-hidden whitespace-nowrap transition-all duration-300 ${isCollapsed ? 'w-0 opacity-0' : 'w-48 opacity-100'}`}>
          <h1 className="text-white font-bold leading-none text-sm tracking-tight">INTEGRA CONSTRUCTION</h1>
          <p className="text-[10px] text-slate-500 font-medium uppercase tracking-widest mt-1">ПГУ Туркестан</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-2 custom-scrollbar overflow-x-hidden">
        <ul className="space-y-1">
          {filteredMenuItems.map((item: any) => (
            item.type === 'divider' ? (
              <li key={item.id} className="my-4 border-t border-slate-800" />
            ) : (
              <li key={item.id}>
                <button
                  onClick={() => setActiveModule(item.id as ModuleType)}
                  title={isCollapsed ? item.label : undefined}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center px-2' : 'px-4 space-x-3'} py-3 rounded-xl transition-all duration-200 group relative ${
                    activeModule === item.id 
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' 
                      : 'hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <item.icon size={20} className={`shrink-0 ${activeModule === item.id ? 'text-white' : 'text-slate-500 group-hover:text-blue-400'}`} />
                  
                  <span className={`text-sm font-medium whitespace-nowrap transition-all duration-300 overflow-hidden ${
                    isCollapsed ? 'w-0 opacity-0' : 'w-auto opacity-100 delay-75'
                  }`}>
                    {item.label}
                  </span>
                  
                  {/* Tooltip for collapsed state */}
                  {isCollapsed && (
                    <div className="absolute left-full top-1/2 -translate-y-1/2 ml-4 bg-slate-800 text-white text-xs font-bold px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-all whitespace-nowrap z-50 shadow-xl border border-slate-700 translate-x-2 group-hover:translate-x-0">
                      {item.label}
                      <div className="absolute left-0 top-1/2 -translate-x-1 -translate-y-1/2 w-2 h-2 bg-slate-800 rotate-45 border-l border-b border-slate-700"></div>
                    </div>
                  )}
                </button>
              </li>
            )
          ))}
          
          {/* ADMIN & LEADERSHIP Specific Buttons */}
          {(userRole === UserRole.ADMIN || userRole === UserRole.LEADERSHIP) && (
            <li className={`mt-6 pt-4 border-t border-slate-800 space-y-1`}>
              <button
                onClick={() => setActiveModule('PROJECT_MANAGERS')}
                title={isCollapsed ? 'Рук проекты' : undefined}
                className={`w-full flex items-center ${isCollapsed ? 'justify-center px-2' : 'px-4 space-x-3'} py-3 rounded-xl transition-all duration-200 group ${
                  activeModule === 'PROJECT_MANAGERS' 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' 
                    : 'hover:bg-slate-800 hover:text-white'
                }`}
              >
                <UserRoundCheck size={20} className={`shrink-0 ${activeModule === 'PROJECT_MANAGERS' ? 'text-white' : 'text-slate-500 group-hover:text-blue-400'}`} />
                <span className={`text-sm font-medium whitespace-nowrap transition-all duration-300 overflow-hidden ${
                    isCollapsed ? 'w-0 opacity-0' : 'w-auto opacity-100 delay-75'
                  }`}>
                    Рук проекты
                </span>
              </button>
              
              {/* Only ADMIN sees Admin Panel */}
              {userRole === UserRole.ADMIN && (
                <button
                  onClick={() => setActiveModule('ADMIN_PANEL')}
                  title={isCollapsed ? 'Админ-панель' : undefined}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center px-2' : 'px-4 space-x-3'} py-3 rounded-xl transition-all duration-200 group ${
                    activeModule === 'ADMIN_PANEL' 
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-500/20' 
                      : 'hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <ShieldCheck size={20} className={`shrink-0 ${activeModule === 'ADMIN_PANEL' ? 'text-white' : 'text-slate-500 group-hover:text-rose-400'}`} />
                  <span className={`text-sm font-medium whitespace-nowrap transition-all duration-300 overflow-hidden ${
                      isCollapsed ? 'w-0 opacity-0' : 'w-auto opacity-100 delay-75'
                    }`}>
                      Админ-панель
                  </span>
                </button>
              )}
            </li>
          )}
        </ul>
      </nav>

      {/* Footer Info */}
      <div className={`p-4 bg-slate-950/50 flex transition-all duration-300 ${isCollapsed ? 'justify-center' : 'justify-between'}`}>
        <div className={`transition-all duration-300 overflow-hidden ${isCollapsed ? 'w-0 h-0 opacity-0' : 'w-full opacity-100'}`}>
          <div className="bg-slate-800/50 rounded-lg p-3 flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500">Система v2.4.0</span>
            <div className="flex space-x-1">
              <div className="w-1 h-1 rounded-full bg-green-500"></div>
              <div className="w-1 h-1 rounded-full bg-green-500"></div>
              <div className="w-1 h-1 rounded-full bg-green-500 animate-pulse"></div>
            </div>
          </div>
        </div>
        
        {isCollapsed && (
          <div className="flex flex-col items-center space-y-1">
             <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
             <span className="text-[8px] font-bold text-slate-600">v2.4</span>
          </div>
        )}
      </div>
    </>
);

const Sidebar: React.FC<SidebarProps> = ({ 
  activeModule, 
  setActiveModule, 
  userRole, 
  isCollapsed, 
  toggleCollapse,
  isMobileOpen,
  closeMobileMenu
}) => {
  
  // Определение доступа к модулям на основе роли
  const filteredMenuItems = useMemo(() => {
    const allItems = [
      { id: 'GENERAL_STATUS', label: 'Общий статус', icon: LayoutDashboard },
      { id: 'EXECUTION_SUMMARY', label: 'Сводка выполнения', icon: Files },
      { id: 'TITLES', label: 'Прогресс титулов', icon: TableProperties },
      { id: 'WORK_PLAN', label: 'План работ', icon: CalendarDays },
      { id: 'HR_RESOURCES', label: 'Расстановка HR', icon: Users },
      { id: 'SUBCONTRACTORS', label: 'Субподрядчики', icon: HardHat },
      { id: 'EQUIPMENT', label: 'Техника', icon: Truck },
      { id: 'divider-1', label: '', type: 'divider' },
      { id: 'HANDBOOK', label: 'Справочник', icon: BookOpen },
      { id: 'SUPPLY', label: 'Реестр снабжения', icon: Package },
      { id: 'GEN_STRUCTURE', label: 'Структура генподряда', icon: Network },
      { id: 'LIVE', label: 'Онлайн-трансляция', icon: Video },
    ];

    // Конфигурация доступа
    // ADMIN: Видит всё (фильтрация не нужна, но спец. кнопки админа ниже)
    // LEADERSHIP (inconshym): Всё, кроме админ панели (админ панель рендерится отдельно внизу)
    // VIEWER: Только базовые модули
    
    if (userRole === UserRole.VIEWER) {
      const allowedViewerModules = ['GENERAL_STATUS', 'EXECUTION_SUMMARY', 'TITLES', 'HR_RESOURCES', 'WORK_PLAN'];
      return allItems.filter(item => item.type === 'divider' || allowedViewerModules.includes(item.id));
    }

    return allItems;
  }, [userRole]);

  return (
    <>
      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-40 lg:hidden animate-in fade-in duration-200"
          onClick={closeMobileMenu}
        />
      )}

      {/* Mobile Sidebar (Slide-over) */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-slate-900 text-slate-300 flex flex-col h-full border-r border-slate-800 transform transition-transform duration-300 ease-in-out lg:hidden ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="absolute top-4 right-4">
          <button onClick={closeMobileMenu} className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-lg">
            <X size={20} />
          </button>
        </div>
        <SidebarContent 
          isCollapsed={false}
          activeModule={activeModule}
          setActiveModule={setActiveModule}
          filteredMenuItems={filteredMenuItems}
          userRole={userRole}
        />
      </aside>

      {/* Desktop Sidebar (Static / Collapsible) */}
      <aside className={`hidden lg:flex bg-slate-900 text-slate-300 flex-col h-full border-r border-slate-800 shrink-0 transition-all duration-300 ease-in-out ${isCollapsed ? 'w-20' : 'w-72'}`}>
        <SidebarContent 
          isCollapsed={isCollapsed}
          activeModule={activeModule}
          setActiveModule={setActiveModule}
          filteredMenuItems={filteredMenuItems}
          userRole={userRole}
        />
        
        {/* Absolute Toggle Button (kept as secondary option) */}
        <button 
          onClick={toggleCollapse}
          className="absolute top-12 -right-3 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-slate-50 hover:bg-blue-700 transition-colors z-10 hover:scale-110 active:scale-95"
        >
          {isCollapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
        </button>
      </aside>
    </>
  );
};

export default Sidebar;
