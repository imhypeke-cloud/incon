
import React, { useState } from 'react';
import { ModuleType, UserRole, ProjectStatus, Type } from '../types';
import { X, CloudUpload, Loader2, CheckCircle2, AlertCircle, FileType } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import * as XLSX from 'xlsx';
import { useData } from '../services/DataContext';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (module: ModuleType, data: any) => void;
  userRole: UserRole;
}

const UploadModal: React.FC<UploadModalProps> = ({ isOpen, onClose, onSuccess, userRole }) => {
  const [selectedModule, setSelectedModule] = useState<ModuleType>('TITLES');
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<'idle' | 'uploading' | 'processing' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const modules = [
    { id: 'TITLES', label: 'Титулы' },
    { id: 'HR_RESOURCES', label: 'Расстановка HR' },
    { id: 'EQUIPMENT', label: 'Техника' },
    { id: 'SUPPLY', label: 'Реестр снабжения' },
  ];

  const processSupplyFile = async (file: File): Promise<any[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

          if (jsonData.length === 0) {
            reject(new Error("Файл пуст"));
            return;
          }

          // Find header row
          let headerRowIndex = -1;
          for (let i = 0; i < Math.min(20, jsonData.length); i++) {
            const row = jsonData[i];
            if (row.some(cell => typeof cell === 'string' && (cell.includes('Номер заявки') || cell.includes('Наименование') || cell.includes('Material')))) {
              headerRowIndex = i;
              break;
            }
          }

          if (headerRowIndex === -1) {
            // Fallback: assume first row is header
            headerRowIndex = 0;
          }

          const headers = jsonData[headerRowIndex].map(h => String(h || '').trim().toLowerCase());
          
          // Map columns
          const colMap: {[key: string]: number} = {};
          headers.forEach((h, idx) => {
            if (h.includes('номер') || h.includes('id')) colMap.id = idx;
            else if (h.includes('дата заявки') || h.includes('date')) colMap.date = idx;
            else if (h.includes('наименование') || h.includes('материал') || h.includes('material')) colMap.material = idx;
            else if (h.includes('ед') || h.includes('unit')) colMap.unit = idx;
            else if (h.includes('кол') || h.includes('qty') || h.includes('количество')) colMap.qty = idx;
            else if (h.includes('примечание') || h.includes('note')) colMap.note = idx;
            else if (h.includes('ответствен') || h.includes('responsible')) colMap.responsible = idx;
            else if (h.includes('статус') || h.includes('status')) colMap.status = idx;
            else if (h.includes('поставщик') || h.includes('supplier')) colMap.supplier = idx;
            else if (h.includes('комментари') || h.includes('comment')) colMap.comment = idx;
            else if (h.includes('дата поставки') || h.includes('delivery')) colMap.deliveryDate = idx;
            else if (h.includes('дней в работе') || h.includes('days')) colMap.daysInWork = idx;
            else if (h.includes('титул') || h.includes('title') || h.includes('объект')) colMap.title = idx;
          });

          const items = [];
          for (let i = headerRowIndex + 1; i < jsonData.length; i++) {
            const row = jsonData[i];
            if (!row || row.length === 0) continue;

            // Skip empty rows where essential fields are missing
            if (!row[colMap.material] && !row[colMap.id]) continue;

            const item = {
              id: colMap.id !== undefined ? String(row[colMap.id] || '') : `ROW-${i}`,
              date: colMap.date !== undefined ? String(row[colMap.date] || '') : '',
              material: colMap.material !== undefined ? String(row[colMap.material] || '') : 'Не указано',
              unit: colMap.unit !== undefined ? String(row[colMap.unit] || '') : '',
              qty: colMap.qty !== undefined ? String(row[colMap.qty] || '') : '',
              note: colMap.note !== undefined ? String(row[colMap.note] || '') : '',
              responsible: colMap.responsible !== undefined ? String(row[colMap.responsible] || '') : '',
              status: colMap.status !== undefined ? String(row[colMap.status] || 'Новая') : 'Новая',
              supplier: colMap.supplier !== undefined ? String(row[colMap.supplier] || '') : '',
              comment: colMap.comment !== undefined ? String(row[colMap.comment] || '') : '',
              deliveryDate: colMap.deliveryDate !== undefined ? String(row[colMap.deliveryDate] || '—') : '—',
              daysInWork: colMap.daysInWork !== undefined ? (row[colMap.daysInWork] || 0) : 0,
              title: colMap.title !== undefined ? String(row[colMap.title] || '') : ''
            };
            items.push(item);
          }

          resolve(items);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = (error) => reject(error);
      reader.readAsArrayBuffer(file);
    });
  };

  const handleProcess = async () => {
    if (!file) return;
    setStatus('processing');
    setErrorMsg('');
    
    try {
      let parsedData: any = [];

      if (selectedModule === 'SUPPLY') {
        // Use local XLSX parsing for Supply Registry to ensure data fidelity and avoid token limits
        parsedData = await processSupplyFile(file);
      } else {
        // Use AI for other modules
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        let systemPrompt = "";
        let responseSchema: any = {};

        if (selectedModule === 'TITLES') {
        systemPrompt = `You are a specialist construction data analyst for INTEGRA CONSTRUCTION. 
        Your task is to parse construction progress tables which typically include:
        - Title Number (e.g. 1.1, 10, 24)
        - Name (Наименование)
        - RC Volumes (Раздел КЖ): Total (Всего), Done (Выполнено), Residual (Остаток)
        - SC Volumes (Раздел КМ): Total (Всего), Done (Выполнено), Residual (Остаток)
        - Status and Manager (if available)
        
        Return a clean JSON array of Title objects. 
        Calculate progress percentage as (done/total)*100 where applicable.`;
        
        responseSchema = {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              number: { type: Type.STRING },
              name: { type: Type.STRING },
              manager: { type: Type.STRING },
              contractor: { type: Type.STRING },
              progress: { type: Type.INTEGER },
              status: { type: Type.STRING },
              lastUpdate: { type: Type.STRING },
              rc: {
                type: Type.OBJECT,
                properties: {
                  total: { type: Type.NUMBER },
                  done: { type: Type.NUMBER },
                  residual: { type: Type.NUMBER },
                  deadline: { type: Type.STRING }
                }
              },
              sc: {
                type: Type.OBJECT,
                properties: {
                  total: { type: Type.NUMBER },
                  done: { type: Type.NUMBER },
                  residual: { type: Type.NUMBER },
                  deadline: { type: Type.STRING }
                }
              }
            },
            required: ['id', 'number', 'name', 'contractor', 'progress', 'status', 'lastUpdate']
          }
        };
      } else if (selectedModule === 'HR_RESOURCES') {
        systemPrompt = "Generate 5 rows of human resources data for construction subcontractors. Return only valid JSON.";
        responseSchema = {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              subcontractor: { type: Type.STRING },
              total: { type: Type.INTEGER },
              itr: { type: Type.INTEGER },
              workers: { type: Type.INTEGER },
              lastUpdate: { type: Type.STRING }
            }
          }
        };
      } else if (selectedModule === 'EQUIPMENT') {
        systemPrompt = `You are a construction fleet manager. Parse the equipment list from the file.
        Map categories to one of: 'Грузовая', 'Подъемная', 'Землеройная', 'Дорожная', 'Специальная', 'Транспортная'.
        Map Owner Type to 'GEN' (General Contractor/Integra) or 'SUB' (Subcontractor).
        Return a JSON array of Equipment objects.`;
        
        responseSchema = {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              type: { type: Type.STRING, description: "Type of equipment (e.g. Excavator)" },
              model: { type: Type.STRING },
              plateNumber: { type: Type.STRING },
              operator: { type: Type.STRING },
              phone: { type: Type.STRING },
              category: { type: Type.STRING, description: "Must be one of: Грузовая, Подъемная, Землеройная, Дорожная, Специальная, Транспортная" },
              ownerType: { type: Type.STRING, enum: ['GEN', 'SUB'] },
              ownerName: { type: Type.STRING },
              status: { type: Type.STRING, enum: ['ACTIVE', 'MAINTENANCE', 'IDLE'] },
              total: { type: Type.INTEGER },
              genPodryad: { type: Type.INTEGER },
              subPodryad: { type: Type.INTEGER }
            },
            required: ['id', 'type', 'category', 'ownerType', 'total']
          }
        };
      }

        // Convert file to base64
        const buffer = await file.arrayBuffer();
        const base64String = btoa(new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), ''));

        const response = await ai.models.generateContent({
          model: 'gemini-2.0-flash', // Use Flash for document processing
          contents: {
            parts: [
              { inlineData: { mimeType: file.type, data: base64String } },
              { text: `Process construction data for module ${selectedModule} from file '${file.name}'.` }
            ]
          },
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json",
            responseSchema: responseSchema
          }
        });

        parsedData = JSON.parse(response.text || "{}");
      }
      
      setStatus('success');
      setTimeout(() => {
        onSuccess(selectedModule, parsedData); // Call parent handler
        setStatus('idle');
        setFile(null);
      }, 1000);

    } catch (err: any) {
      console.error(err);
      setStatus('error');
      setErrorMsg(err.message || 'Ошибка при обработке файла');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
              <CloudUpload size={20} />
            </div>
            <div>
              <h3 className="font-black text-slate-800 uppercase tracking-tight">Загрузка данных</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase">Модульное обновление ИИ</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="p-8 space-y-6">
          {status === 'idle' || status === 'error' ? (
            <>
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-3">Выберите целевой модуль</label>
                <div className="grid grid-cols-2 gap-3">
                  {modules.map(m => (
                    <button
                      key={m.id}
                      onClick={() => setSelectedModule(m.id as ModuleType)}
                      className={`px-4 py-3 rounded-xl border text-xs font-bold transition-all ${
                        selectedModule === m.id 
                          ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-500/20' 
                          : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-3">Прикрепите файл (Excel / PDF / JSON)</label>
                <div 
                  className="border-2 border-dashed border-slate-200 rounded-2xl p-8 flex flex-col items-center justify-center hover:border-blue-400 hover:bg-blue-50/50 transition-all cursor-pointer group"
                  onClick={() => document.getElementById('file-input')?.click()}
                >
                  <input 
                    id="file-input" 
                    type="file" 
                    className="hidden" 
                    accept=".xlsx,.xls,.pdf,.json" 
                    onChange={(e) => setFile(e.target.files?.[0] || null)}
                  />
                  {file ? (
                    <div className="flex items-center space-x-3 text-blue-600">
                      <FileType size={32} />
                      <div className="text-left">
                        <p className="text-sm font-bold truncate max-w-[200px]">{file.name}</p>
                        <p className="text-[10px] uppercase font-bold text-slate-400">{(file.size / 1024).toFixed(1)} KB</p>
                      </div>
                    </div>
                  ) : (
                    <>
                      <CloudUpload size={32} className="text-slate-300 group-hover:text-blue-500 mb-3 transition-colors" />
                      <p className="text-xs font-bold text-slate-500">Нажмите для выбора или перетащите файл</p>
                      <p className="text-[9px] text-slate-400 mt-2 uppercase">Макс. размер 10 MB</p>
                    </>
                  )}
                </div>
              </div>

              {status === 'error' && (
                <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl flex items-center space-x-3 text-rose-600">
                  <AlertCircle size={18} />
                  <p className="text-xs font-bold">{errorMsg}</p>
                </div>
              )}

              <button 
                disabled={!file}
                onClick={handleProcess}
                className={`w-full py-4 rounded-2xl font-black uppercase tracking-widest text-sm transition-all ${
                  file 
                    ? 'bg-slate-900 text-white hover:bg-blue-600 shadow-xl' 
                    : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                }`}
              >
                Начать обработку ИИ
              </button>
            </>
          ) : status === 'processing' ? (
            <div className="py-12 flex flex-col items-center justify-center space-y-4">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Loader2 className="text-blue-600 animate-pulse" size={24} />
                </div>
              </div>
              <div className="text-center">
                <p className="font-black text-slate-800 uppercase tracking-tight">AI Анализ данных...</p>
                <p className="text-xs text-slate-500 mt-1">Извлекаем структуру и обновляем модуль {selectedModule}</p>
              </div>
            </div>
          ) : (
            <div className="py-12 flex flex-col items-center justify-center space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center animate-bounce">
                <CheckCircle2 size={32} />
              </div>
              <div className="text-center">
                <p className="font-black text-slate-800 uppercase tracking-tight">Данные обновлены!</p>
                <p className="text-xs text-slate-500 mt-1">Модуль успешно синхронизирован с загруженным файлом</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UploadModal;
