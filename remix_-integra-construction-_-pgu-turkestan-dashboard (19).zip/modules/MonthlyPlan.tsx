
import React, { useState, useMemo, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  ChevronDown, 
  Download, 
  Activity, 
  Plus, 
  Calculator,
  Sigma,
  Hammer
} from 'lucide-react';
import { useData } from '../services/DataContext';

interface MonthlyPlanProps {
  isReadOnly?: boolean;
}

const MonthlyPlan: React.FC<MonthlyPlanProps> = ({ isReadOnly = false }) => {
  const { monthlyPlanData } = useData();
  const [selectedMonth, setSelectedMonth] = useState<string>('');
  
  const [expandedManagers, setExpandedManagers] = useState<string[]>([
    'Попивнухин Н.В.', 'Махмудов Ю.С.', 'Алдамуратов Р.И.', 'Абилькасимов Б.Ж.', 'Тлеулесов К.К.', 'Рахматулла А.'
  ]);

  // Ensure selectedMonth defaults to the latest available month if not set
  useEffect(() => {
    const availableMonths = Object.keys(monthlyPlanData);
    if (availableMonths.length > 0 && !selectedMonth) {
        // Sort months? For now, just pick the last one added or default 'Февраль 2026'
        setSelectedMonth(availableMonths.includes('Февраль 2026') ? 'Февраль 2026' : availableMonths[availableMonths.length - 1]);
    }
  }, [monthlyPlanData, selectedMonth]);

  const currentMonthPlans = useMemo(() => monthlyPlanData[selectedMonth] || [], [monthlyPlanData, selectedMonth]);

  const toggleManager = (name: string) => {
    setExpandedManagers(prev => prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]);
  };

  // Helper to categorize work type from name
  const detectWorkCategory = (name: string): string => {
    const lower = name?.toLowerCase() || '';
    if (lower.includes('бетонирование')) return 'Бетонирование';
    if (lower.includes('засыпка')) return 'Обратная засыпка';
    if (lower.includes('монтаж мк') || lower.includes('монтаж м/к')) return 'Монтаж металлоконструкций';
    if (lower.includes('сэндвич')) return 'Монтаж сэндвич-панелей';
    if (lower.includes('профлист') || lower.includes('профнастил')) return 'Монтаж профлиста';
    if (lower.includes('кровл')) return 'Кровельные работы';
    if (lower.includes('гидроиз')) return 'Гидроизоляция';
    if (lower.includes('цоколь')) return 'Монтаж цокольных панелей';
    if (lower.includes('рельс')) return 'Устройство рельсовых путей';
    if (lower.includes('трубопровод')) return 'Прокладка трубопроводов';
    if (lower.includes('гтг') || lower.includes('турбин') || lower.includes('генератор')) return 'Монтаж оборудования (ГТГ/ПТ)';
    if (lower.includes('электр') || lower.includes('кабель') || lower.includes('заземлен')) return 'Электромонтажные работы';
    return 'Прочие работы';
  };

  // Helper to calculate totals by work type for a specific manager
  const getManagerTotals = (manager: any) => {
    const totals: Record<string, { plan: number, fact: number, unit: string }> = {};
    
    manager.titles.forEach((t: any) => {
      t.projects.forEach((p: any) => {
        const category = detectWorkCategory(p.name);
        
        if (!totals[category]) {
          totals[category] = { plan: 0, fact: 0, unit: p.unit };
        }
        
        totals[category].plan += p.monthlyPlan;
        totals[category].fact += p.fact;
        if (p.unit && p.unit !== totals[category].unit) totals[category].unit = p.unit;
      });
    });
    
    return totals;
  };

  // Week Color Styles - BRIGHT COLORS
  const weekStyles = {
    n1: { bgHeader: 'bg-slate-200 text-slate-800', bgCell: 'bg-slate-100' },
    n2: { bgHeader: 'bg-cyan-200 text-cyan-900', bgCell: 'bg-cyan-100' },
    n3: { bgHeader: 'bg-violet-200 text-violet-900', bgCell: 'bg-violet-100' },
    n4: { bgHeader: 'bg-orange-200 text-orange-900', bgCell: 'bg-orange-100' },
  };

  // Dynamic Week Headers based on Month
  const getWeekHeaders = (month: string) => {
    if (month.includes('Январь 2026')) return ['05.01 - 11.01', '12.01 - 18.01', '19.01 - 25.01', '26.01 - 01.02'];
    if (month.includes('Февраль 2026')) return ['02.02 - 08.02', '09.02 - 15.02', '16.02 - 22.02', '22.02 - 28.02'];
    // Generic fallback
    return ['Неделя 1', 'Неделя 2', 'Неделя 3', 'Неделя 4'];
  }

  const weekHeaders = getWeekHeaders(selectedMonth);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      
      {/* HEADER CONTROLS */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white p-4 rounded-[1.75rem] border border-slate-200 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center shadow-lg"><Activity size={20} /></div>
          <div>
            <h2 className="text-sm font-black text-slate-800 uppercase tracking-tight leading-none">План работы (Факт/План)</h2>
            <div className="flex items-center mt-1">
              <select 
                value={selectedMonth} 
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="text-[10px] font-bold uppercase tracking-widest bg-transparent border-none outline-none cursor-pointer text-slate-500 hover:text-indigo-600 transition-colors"
              >
                {Object.keys(monthlyPlanData).map(m => <option key={m} value={m}>{m}</option>)}
              </select>
              <ChevronDown size={12} className="ml-1 text-slate-400" />
            </div>
          </div>
        </div>
        
        <div className="flex space-x-2">
           {!isReadOnly && <button className="flex items-center space-x-2 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-200"><Plus size={12}/> <span>Новый план</span></button>}
           <button className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 shadow-lg shadow-indigo-500/20"><Download size={12}/> <span>Экспорт</span></button>
        </div>
      </div>

      {/* DETAILED TABLE */}
      <div className="space-y-4">
        {currentMonthPlans.length === 0 ? (
           <div className="p-12 text-center bg-white rounded-3xl border border-dashed border-slate-200 text-slate-400 font-bold uppercase text-xs">
              Нет данных для выбранного периода
           </div>
        ) : currentMonthPlans.map((manager) => {
          const isExpanded = expandedManagers.includes(manager.name);
          const totals = getManagerTotals(manager);

          return (
            <div key={manager.name} className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
              <div 
                onClick={() => toggleManager(manager.name)}
                className={`px-6 py-4 flex items-center justify-between cursor-pointer transition-colors ${isExpanded ? 'bg-slate-50 border-b border-slate-200' : 'bg-white hover:bg-slate-50'}`}
              >
                 <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-800 text-white flex items-center justify-center font-black text-xs">
                       {manager.name.charAt(0)}
                    </div>
                    <span className="font-black text-slate-800 uppercase tracking-tight text-sm">{manager.name}</span>
                 </div>
                 <ChevronDown size={20} className={`text-slate-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`}/>
              </div>

              {isExpanded && (
                <div className="animate-fade-in">
                  
                  {/* MANAGER TOTALS SUMMARY BY WORK TYPE */}
                  <div className="bg-gradient-to-r from-slate-50 to-white border-b border-slate-200 p-4">
                     <h4 className="flex items-center gap-2 text-xs font-black uppercase text-slate-500 mb-3 tracking-widest">
                       <Hammer size={14} className="text-indigo-600"/>
                       ИТОГО ПО ВИДАМ РАБОТ:
                     </h4>
                     <div className="flex flex-wrap gap-3">
                        {Object.entries(totals).map(([category, val]) => (
                           <div key={category} className="flex flex-col bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm min-w-[180px] hover:shadow-md transition-shadow">
                              <span className="text-[10px] font-black text-slate-500 uppercase tracking-tight mb-2 truncate" title={category}>{category}</span>
                              <div className="flex items-center justify-between gap-3 text-xs">
                                 <div className="flex flex-col">
                                    <span className="text-[8px] text-blue-500 font-bold uppercase">План</span>
                                    <span className="font-black text-slate-800">{val.plan.toLocaleString(undefined, {maximumFractionDigits: 1})} <span className="text-[9px] text-slate-400 font-normal">{val.unit}</span></span>
                                 </div>
                                 <div className="h-6 w-px bg-slate-100"></div>
                                 <div className="flex flex-col items-end">
                                    <span className="text-[8px] text-emerald-600 font-bold uppercase">Факт</span>
                                    <span className="font-black text-slate-800">{val.fact.toLocaleString(undefined, {maximumFractionDigits: 1})} <span className="text-[9px] text-slate-400 font-normal">{val.unit}</span></span>
                                 </div>
                              </div>
                           </div>
                        ))}
                     </div>
                  </div>

                  <div className="overflow-x-auto custom-scrollbar">
                    <table className="w-full text-left border-collapse min-w-[1400px]">
                      <thead>
                        <tr className="bg-slate-50/80 text-xs font-black uppercase text-slate-500 tracking-wider border-b border-slate-200">
                          <th className="py-4 px-4 w-16 bg-white sticky left-0 z-10">Титул</th>
                          <th className="py-4 px-4 min-w-[200px] bg-white sticky left-16 z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]">Наименование работ</th>
                          <th className="py-4 px-4 text-center">Ед.</th>
                          
                          {/* New Columns */}
                          <th className="py-4 px-4 text-center text-slate-600 border-l border-slate-200">Срок ГПР</th>
                          <th className="py-4 px-4 text-center text-slate-600">Всего</th>
                          <th className="py-4 px-4 text-center text-slate-600 border-r border-slate-200">Остаток</th>

                          <th className="py-4 px-4 text-center bg-blue-50/50 text-blue-700">План мес.</th>
                          <th className="py-4 px-4 text-center bg-emerald-50/50 text-emerald-700">Факт мес.</th>
                          <th className="py-4 px-4 text-center text-slate-800 border-r border-slate-200">Откл.</th>
                          
                          {/* DYNAMIC WEEKS HEADER */}
                          <th className={`py-2 px-2 text-center border-r border-slate-200 ${weekStyles.n1.bgHeader}`} colSpan={2}>{weekHeaders[0]}</th>
                          <th className={`py-2 px-2 text-center border-r border-slate-200 ${weekStyles.n2.bgHeader}`} colSpan={2}>{weekHeaders[1]}</th>
                          <th className={`py-2 px-2 text-center border-r border-slate-200 ${weekStyles.n3.bgHeader}`} colSpan={2}>{weekHeaders[2]}</th>
                          <th className={`py-2 px-2 text-center ${weekStyles.n4.bgHeader}`} colSpan={2}>{weekHeaders[3]}</th>
                        </tr>
                        
                        <tr className="bg-slate-50/50 text-[10px] font-black uppercase text-slate-400 tracking-wider border-b border-slate-200">
                          <th colSpan={9} className="bg-white sticky left-0 z-10 border-r border-slate-200 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]"></th>
                          {/* Week 1 Sub-header */}
                          <th className={`pb-2 text-center text-slate-600 ${weekStyles.n1.bgHeader}`}>План</th>
                          <th className={`pb-2 text-center text-slate-800 border-r border-slate-300 ${weekStyles.n1.bgHeader}`}>Факт</th>
                          
                          {/* Week 2 Sub-header */}
                          <th className={`pb-2 text-center text-cyan-700 ${weekStyles.n2.bgHeader}`}>План</th>
                          <th className={`pb-2 text-center text-cyan-900 border-r border-cyan-300 ${weekStyles.n2.bgHeader}`}>Факт</th>
                          
                          {/* Week 3 Sub-header */}
                          <th className={`pb-2 text-center text-violet-700 ${weekStyles.n3.bgHeader}`}>План</th>
                          <th className={`pb-2 text-center text-violet-900 border-r border-violet-300 ${weekStyles.n3.bgHeader}`}>Факт</th>
                          
                          {/* Week 4 Sub-header */}
                          <th className={`pb-2 text-center text-orange-700 ${weekStyles.n4.bgHeader}`}>План</th>
                          <th className={`pb-2 text-center text-orange-900 ${weekStyles.n4.bgHeader}`}>Факт</th>
                        </tr>
                      </thead>
                      
                      <tbody className="text-sm font-medium text-slate-700 divide-y divide-slate-100">
                        {manager.titles.map((t: any) => (
                          t.projects.map((p: any, idx: number) => (
                            <tr key={p.id} className="hover:bg-blue-50/10 transition-colors group">
                              <td className="py-3 px-4 font-bold text-slate-800 sticky left-0 bg-white group-hover:bg-blue-50/10 z-10 text-xs w-16">{idx === 0 ? t.id : ''}</td>
                              <td className="py-3 px-4 sticky left-16 bg-white group-hover:bg-blue-50/10 z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)] min-w-[200px]">
                                 <div className="font-bold text-slate-700 line-clamp-2" title={p.name}>{p.name}</div>
                                 <span className="text-[10px] text-slate-400 uppercase font-black bg-slate-50 px-1.5 rounded border border-slate-100">{p.section}</span>
                              </td>
                              <td className="py-3 px-4 text-center uppercase text-[11px] font-bold text-slate-400">{p.unit}</td>
                              
                              {/* New Data Columns */}
                              <td className="py-3 px-4 text-center text-xs font-medium text-slate-500 border-l border-slate-100 whitespace-nowrap">
                                 {p.completionDate || '-'}
                              </td>
                              <td className="py-3 px-4 text-center text-xs font-bold text-slate-700">
                                 {p.projectTotal?.toLocaleString() || '-'}
                              </td>
                              <td className="py-3 px-4 text-center text-xs font-bold text-slate-500 border-r border-slate-100">
                                 {p.projectResidue?.toLocaleString() || '-'}
                              </td>

                              {/* MONTH TOTALS */}
                              <td className="py-3 px-4 text-center font-black bg-blue-50/30 text-blue-700">{p.monthlyPlan}</td>
                              <td className="py-3 px-4 text-center font-black bg-emerald-50/30 text-emerald-700">{p.fact}</td>
                              <td className={`py-3 px-4 text-center font-black border-r border-slate-100 ${p.deviation < 0 ? 'text-rose-500' : 'text-emerald-500'}`}>
                                 {p.deviation > 0 ? '+' : ''}{Number(p.deviation.toFixed(2))}
                              </td>

                              {/* WEEKS DATA WITH BRIGHT BACKGROUNDS */}
                              <td className={`py-3 px-2 text-center text-slate-500 ${weekStyles.n1.bgCell}`}>{p.weeks.n1.plan}</td>
                              <td className={`py-3 px-2 text-center font-bold border-r border-slate-300 ${weekStyles.n1.bgCell} ${p.weeks.n1.fact < p.weeks.n1.plan ? 'text-rose-600' : 'text-emerald-700'}`}>{p.weeks.n1.fact}</td>

                              <td className={`py-3 px-2 text-center text-slate-500 ${weekStyles.n2.bgCell}`}>{p.weeks.n2.plan}</td>
                              <td className={`py-3 px-2 text-center font-bold border-r border-cyan-300 ${weekStyles.n2.bgCell} ${p.weeks.n2.fact < p.weeks.n2.plan ? 'text-rose-600' : 'text-emerald-700'}`}>{p.weeks.n2.fact}</td>

                              <td className={`py-3 px-2 text-center text-slate-500 ${weekStyles.n3.bgCell}`}>{p.weeks.n3.plan}</td>
                              <td className={`py-3 px-2 text-center font-bold border-r border-violet-300 ${weekStyles.n3.bgCell} ${p.weeks.n3.fact < p.weeks.n3.plan ? 'text-rose-600' : 'text-emerald-700'}`}>{p.weeks.n3.fact}</td>

                              <td className={`py-3 px-2 text-center text-slate-500 ${weekStyles.n4.bgCell}`}>{p.weeks.n4.plan}</td>
                              <td className={`py-3 px-2 text-center font-bold ${weekStyles.n4.bgCell} ${p.weeks.n4.fact < p.weeks.n4.plan ? 'text-rose-600' : 'text-emerald-700'}`}>{p.weeks.n4.fact}</td>
                            </tr>
                          ))
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default MonthlyPlan;
