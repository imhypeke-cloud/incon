import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { MapControls, Environment, ContactShadows, Text, Edges, Html } from '@react-three/drei';
import * as THREE from 'three';
import { useData } from '../services/DataContext';
import { TitleData } from '../types';
import { Edit2, X, Save, Image as ImageIcon, Plus, Trash2, Search, Filter, Map as MapIcon, Layers, Maximize, ZoomIn, ZoomOut, Navigation, Compass } from 'lucide-react';

// Simple building component
function Building({ 
  data, 
  isSelected, 
  isHovered,
  onClick, 
  onPointerOver, 
  onPointerOut 
}: { 
  data: TitleData; 
  isSelected: boolean; 
  isHovered: boolean;
  onClick: () => void;
  onPointerOver: () => void;
  onPointerOut: () => void;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  // Extract coordinates and dimensions from data or use defaults
  const idNum = parseInt(data.id.replace(/\D/g, '')) || 0;
  
  const position: [number, number, number] = [
    data.x !== undefined ? data.x : (idNum % 5) * 4 - 8,
    0, // Y is up, so base is at 0
    data.z !== undefined ? data.z : Math.floor(idNum / 5) * 4 - 8
  ];
  
  const width = data.width || 2 + (idNum % 3);
  const length = data.length || 2 + ((idNum + 1) % 3);
  const height = data.height || 1 + (idNum % 5);
  
  // 2GIS style colors
  let color = data.color || '#FFFFFF'; // Default building color
  let edgeColor = '#D0D5D8';
  let roofColor = '#F5F7F9';
  
  if (isSelected) {
    color = '#2B87F9'; // 2GIS Blue
    roofColor = '#4A9AFB';
    edgeColor = '#1E65C0';
  } else if (isHovered) {
    color = '#EAF2FB'; // Light blue hover
    roofColor = '#F2F7FD';
    edgeColor = '#A0C0E8';
  }
  
  const materials = useMemo(() => [
    new THREE.MeshStandardMaterial({ color: color, roughness: 0.9, metalness: 0.1 }), // sides
    new THREE.MeshStandardMaterial({ color: roofColor, roughness: 0.9, metalness: 0.1 }) // roof/bottom
  ], [color, roofColor]);

  const boxMaterials = useMemo(() => [
    new THREE.MeshStandardMaterial({ color: color, roughness: 0.9, metalness: 0.1 }), // right
    new THREE.MeshStandardMaterial({ color: color, roughness: 0.9, metalness: 0.1 }), // left
    new THREE.MeshStandardMaterial({ color: roofColor, roughness: 0.9, metalness: 0.1 }), // top
    new THREE.MeshStandardMaterial({ color: color, roughness: 0.9, metalness: 0.1 }), // bottom
    new THREE.MeshStandardMaterial({ color: color, roughness: 0.9, metalness: 0.1 }), // front
    new THREE.MeshStandardMaterial({ color: color, roughness: 0.9, metalness: 0.1 }), // back
  ], [color, roofColor]);

  const geometry = useMemo(() => {
    if (data.polygon && data.polygon.length > 2) {
      const shape = new THREE.Shape();
      shape.moveTo(data.polygon[0][0], data.polygon[0][1]);
      for (let i = 1; i < data.polygon.length; i++) {
        shape.lineTo(data.polygon[i][0], data.polygon[i][1]);
      }
      shape.lineTo(data.polygon[0][0], data.polygon[0][1]);
      
      const extrudeSettings = {
        depth: height,
        bevelEnabled: false,
      };
      
      const geom = new THREE.ExtrudeGeometry(shape, extrudeSettings);
      geom.rotateX(Math.PI / 2); // Rotate to lay flat on XZ plane
      return geom;
    }
    return new THREE.BoxGeometry(width, height, length);
  }, [data.polygon, width, height, length]);
  
  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        position={data.polygon && data.polygon.length > 2 ? [0, height, 0] : [0, height / 2, 0]}
        onClick={(e) => {
          e.stopPropagation();
          onClick();
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          onPointerOver();
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          onPointerOut();
        }}
        castShadow
        receiveShadow
        geometry={geometry}
        material={data.polygon && data.polygon.length > 2 ? materials : boxMaterials}
      >
        <Edges scale={1.001} threshold={15} color={edgeColor} />
      </mesh>
      
      {/* Label - only show if selected or hovered for cleaner map, or always show but smaller */}
      {(isSelected || isHovered) && (
        <Html position={[0, height + 1, 0]} center zIndexRange={[100, 0]}>
          <div className={`px-3 py-1.5 rounded-lg shadow-md text-xs font-bold whitespace-nowrap transition-all duration-200 ${isSelected ? 'bg-blue-600 text-white scale-110 shadow-blue-500/30' : 'bg-white text-gray-800 border border-gray-100'}`}>
            {data.name}
          </div>
        </Html>
      )}
    </group>
  );
}

function CameraController({ selectedId, titles }: { selectedId: string | null, titles: TitleData[] }) {
  const { camera, controls } = useThree();
  const [targetId, setTargetId] = useState<string | null>(null);
  
  useEffect(() => {
    if (selectedId) {
      setTargetId(selectedId);
    }
  }, [selectedId]);
  
  useFrame(() => {
    if (targetId) {
      const selectedTitle = titles.find(t => t.id === targetId);
      if (selectedTitle) {
        const targetX = selectedTitle.x || 0;
        const targetZ = selectedTitle.z || 0;
        
        const targetPos = new THREE.Vector3(targetX + 15, 20, targetZ + 15);
        const targetLookAt = new THREE.Vector3(targetX, 0, targetZ);
        
        // Smoothly move camera
        camera.position.lerp(targetPos, 0.05);
        
        // If using MapControls, we need to update its target
        if (controls) {
          // @ts-ignore
          controls.target.lerp(targetLookAt, 0.05);
          // @ts-ignore
          controls.update();
        }

        // Stop focusing if we are close enough
        if (camera.position.distanceTo(targetPos) < 0.5 && controls && (controls as any).target.distanceTo(targetLookAt) < 0.5) {
          setTargetId(null);
        }
      }
    }
  });
  
  return null;
}

function Scene({ 
  titles, 
  selectedId, 
  hoveredId,
  onSelect,
  onHover,
  backgroundImage,
  isDrawMode,
  onPlaneClick,
  controlsRef
}: { 
  titles: TitleData[]; 
  selectedId: string | null; 
  hoveredId: string | null;
  onSelect: (id: string | null) => void;
  onHover: (id: string | null) => void;
  backgroundImage: string | null;
  isDrawMode: boolean;
  onPlaneClick: (x: number, z: number) => void;
  controlsRef: React.RefObject<any>;
}) {
  const texture = useMemo(() => {
    if (!backgroundImage) return null;
    const loader = new THREE.TextureLoader();
    return loader.load(backgroundImage);
  }, [backgroundImage]);

  return (
    <>
      <ambientLight intensity={0.7} />
      <directionalLight 
        position={[30, 50, 20]} 
        intensity={1.0} 
        castShadow 
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-60}
        shadow-camera-right={60}
        shadow-camera-top={60}
        shadow-camera-bottom={-60}
      />
      
      {/* Ground plane */}
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, -0.01, 0]} 
        receiveShadow
        onClick={(e) => {
          if (isDrawMode) {
            e.stopPropagation();
            onPlaneClick(e.point.x, e.point.z);
          } else {
            onSelect(null);
          }
        }}
        onPointerOver={(e) => {
          if (isDrawMode) {
            document.body.style.cursor = 'crosshair';
          }
        }}
        onPointerOut={(e) => {
          if (isDrawMode) {
            document.body.style.cursor = 'default';
          }
        }}
      >
        <planeGeometry args={[300, 300]} />
        {texture ? (
          <meshBasicMaterial map={texture} />
        ) : (
          <meshStandardMaterial color="#F0F3F6" roughness={1} metalness={0} />
        )}
        {!texture && <Edges scale={1} threshold={15} color="#E0E5E9" />}
      </mesh>
      
      {!texture && <gridHelper args={[300, 300, '#E5E9ED', '#E5E9ED']} position={[0, 0, 0]} />}

      {titles.map((title) => (
        <Building
          key={title.id}
          data={title}
          isSelected={selectedId === title.id}
          isHovered={hoveredId === title.id}
          onClick={() => onSelect(title.id)}
          onPointerOver={() => onHover(title.id)}
          onPointerOut={() => onHover(null)}
        />
      ))}

      <ContactShadows position={[0, 0, 0]} opacity={0.4} scale={150} blur={2} far={20} />
      <Environment preset="city" />
      <MapControls 
        ref={controlsRef}
        makeDefault 
        minPolarAngle={0} 
        maxPolarAngle={Math.PI / 2 - 0.15} 
        minDistance={5}
        maxDistance={200}
        enableDamping
        dampingFactor={0.05}
      />
    </>
  );
}

export default function MasterPlan() {
  const { titles, updateTitle, addTitle, deleteTitle, isAdmin } = useData();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<Partial<TitleData>>({});
  const [isDrawMode, setIsDrawMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [backgroundImage, setBackgroundImage] = useState<string | null>(() => {
    return localStorage.getItem('masterPlanBg') || null;
  });
  
  const controlsRef = useRef<any>(null);

  const handleZoomIn = () => {
    if (controlsRef.current) {
      const target = controlsRef.current.target;
      const camera = controlsRef.current.object;
      const v = new THREE.Vector3().subVectors(target, camera.position);
      camera.position.add(v.multiplyScalar(0.3));
      controlsRef.current.update();
    }
  };

  const handleZoomOut = () => {
    if (controlsRef.current) {
      const target = controlsRef.current.target;
      const camera = controlsRef.current.object;
      const v = new THREE.Vector3().subVectors(camera.position, target);
      camera.position.add(v.multiplyScalar(0.3));
      controlsRef.current.update();
    }
  };

  const handleResetRotation = () => {
    if (controlsRef.current) {
      const camera = controlsRef.current.object;
      const target = controlsRef.current.target;
      
      // Calculate current distance
      const distance = camera.position.distanceTo(target);
      const polarAngle = controlsRef.current.getPolarAngle();
      
      // Set new position (North is -Z in Three.js, so camera should be at +Z looking at target)
      camera.position.set(
        target.x,
        target.y + distance * Math.cos(polarAngle),
        target.z + distance * Math.sin(polarAngle)
      );
      
      controlsRef.current.update();
    }
  };

  const filteredTitles = useMemo(() => {
    return titles.filter(t => {
      const matchesSearch = t.name.toLowerCase().includes(searchQuery.toLowerCase()) || t.number.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'All' || t.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [titles, searchQuery, statusFilter]);

  const handleBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setBackgroundImage(result);
        localStorage.setItem('masterPlanBg', result);
      };
      reader.readAsDataURL(file);
    }
  };

  const selectedTitle = useMemo(() => 
    titles.find(t => t.id === selectedId) || null
  , [titles, selectedId]);

  const handleEditClick = () => {
    if (selectedTitle) {
      setEditData(selectedTitle);
      setIsEditing(true);
    }
  };

  const handleSave = () => {
    if (selectedTitle && editData) {
      updateTitle(selectedTitle.id, editData);
      setIsEditing(false);
    }
  };

  return (
    <div className="flex flex-1 h-full overflow-hidden bg-[#F0F3F6] relative font-sans">
      {/* 3D Canvas Area */}
      <div className="flex-1 relative">
        <Canvas shadows camera={{ position: [0, 40, 40], fov: 45 }}>
          <CameraController selectedId={selectedId} titles={titles} />
          <Scene 
            titles={filteredTitles} 
            selectedId={selectedId} 
            hoveredId={hoveredId}
            onSelect={setSelectedId} 
            onHover={setHoveredId}
            backgroundImage={backgroundImage} 
            isDrawMode={isDrawMode}
            controlsRef={controlsRef}
            onPlaneClick={(x, z) => {
              if (isDrawMode && isAdmin) {
                const newId = `T-${Date.now()}`;
                const newTitle: TitleData = {
                  id: newId,
                  number: newId,
                  name: `Новое здание`,
                  manager: '',
                  contractor: '',
                  progress: 0,
                  status: 'Не начато',
                  lastUpdate: new Date().toISOString(),
                  startDate: new Date().toISOString(),
                  deadline: new Date().toISOString(),
                  totalVolume: 0,
                  completedVolume: 0,
                  x,
                  z,
                  width: 4,
                  length: 4,
                  height: 2,
                  color: '#FFFFFF'
                };
                addTitle(newTitle);
                setSelectedId(newId);
                setIsDrawMode(false);
              }
            }}
          />
        </Canvas>
        
        {/* 2GIS Style Search & Filter Panel (Top Left) */}
        <div className="absolute top-4 left-4 flex flex-col gap-3 z-10 w-96 pointer-events-none">
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden pointer-events-auto flex items-center px-4 py-3 border border-gray-100">
            <Search size={20} className="text-gray-400 mr-3" />
            <input 
              type="text" 
              placeholder="Поиск зданий, титулов..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-base outline-none placeholder-gray-400 font-medium text-gray-800"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="text-gray-400 hover:text-gray-600 p-1">
                <X size={18} />
              </button>
            )}
          </div>
          
          <div className="flex gap-2 pointer-events-auto overflow-x-auto pb-1 hide-scrollbar">
            <button 
              onClick={() => setStatusFilter('All')}
              className={`text-sm shadow-sm rounded-full px-4 py-2 outline-none cursor-pointer font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'All' ? 'bg-gray-800 text-white' : 'bg-white text-gray-700 border border-gray-100 hover:bg-gray-50'
              }`}
            >
              Все статусы
            </button>
            <button 
              onClick={() => setStatusFilter('В графике')}
              className={`text-sm shadow-sm rounded-full px-4 py-2 outline-none cursor-pointer font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'В графике' ? 'bg-green-600 text-white' : 'bg-white text-gray-700 border border-gray-100 hover:bg-gray-50'
              }`}
            >
              В графике
            </button>
            <button 
              onClick={() => setStatusFilter('Отставание')}
              className={`text-sm shadow-sm rounded-full px-4 py-2 outline-none cursor-pointer font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'Отставание' ? 'bg-red-600 text-white' : 'bg-white text-gray-700 border border-gray-100 hover:bg-gray-50'
              }`}
            >
              Отставание
            </button>
            
            {isAdmin && (
              <button 
                onClick={() => setIsDrawMode(!isDrawMode)}
                className={`text-sm shadow-sm rounded-full px-4 py-2 outline-none cursor-pointer font-medium flex items-center gap-1 whitespace-nowrap transition-colors ${
                  isDrawMode 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-blue-600 border border-blue-100 hover:bg-blue-50'
                }`}
              >
                <Plus size={16} /> {isDrawMode ? 'Кликните на карту' : 'Добавить'}
              </button>
            )}
          </div>
        </div>

        {/* 2GIS Style Map Controls (Right Side) */}
        <div className={`absolute top-1/2 -translate-y-1/2 flex flex-col gap-3 z-10 pointer-events-none transition-all duration-300 ${selectedId ? 'right-[420px]' : 'right-4'}`}>
          <div className="bg-white rounded-xl shadow-md overflow-hidden pointer-events-auto flex flex-col border border-gray-100">
            <button onClick={handleZoomIn} className="p-3 text-gray-600 hover:bg-gray-50 hover:text-blue-600 transition-colors border-b border-gray-100" title="Приблизить">
              <ZoomIn size={20} />
            </button>
            <button onClick={handleZoomOut} className="p-3 text-gray-600 hover:bg-gray-50 hover:text-blue-600 transition-colors" title="Отдалить">
              <ZoomOut size={20} />
            </button>
          </div>
          <div className="bg-white rounded-xl shadow-md overflow-hidden pointer-events-auto flex flex-col border border-gray-100">
            <button onClick={handleResetRotation} className="p-3 text-gray-600 hover:bg-gray-50 hover:text-blue-600 transition-colors" title="Ориентация на север">
              <Compass size={20} />
            </button>
          </div>
          <div className="bg-white rounded-xl shadow-md overflow-hidden pointer-events-auto flex flex-col border border-gray-100">
            <button className="p-3 text-gray-600 hover:bg-gray-50 hover:text-blue-600 transition-colors" title="Слои карты">
              <Layers size={20} />
            </button>
          </div>
        </div>

        {/* Admin Controls (Bottom Left) */}
        {isAdmin && (
          <div className="absolute bottom-6 left-4 z-10 pointer-events-auto">
            <label className="cursor-pointer bg-white hover:bg-gray-50 text-gray-700 px-4 py-2.5 rounded-xl shadow-md text-sm font-medium border border-gray-100 flex items-center justify-center gap-2 transition-colors">
              <MapIcon size={16} className="text-blue-500" /> 
              <span>Загрузить подложку</span>
              <input type="file" accept="image/*" className="hidden" onChange={handleBgUpload} />
            </label>
          </div>
        )}
      </div>

      {/* 2GIS Style Right Panel (Floating Drawer) */}
      <div 
        className={`absolute top-4 right-4 bottom-4 w-[400px] bg-white rounded-2xl shadow-2xl z-20 transform transition-transform duration-300 ease-in-out flex flex-col overflow-hidden border border-gray-100 ${
          selectedId ? 'translate-x-0' : 'translate-x-[120%]'
        }`}
      >
        {selectedId && (
          <>
            {/* Header Image Area */}
            <div className="relative h-48 bg-gray-100 shrink-0">
              {selectedTitle?.imageUrl ? (
                <img src={selectedTitle.imageUrl} alt={selectedTitle.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 bg-gradient-to-br from-gray-100 to-gray-200">
                  <Layers size={48} className="mb-2 opacity-50" />
                  <span className="text-sm font-medium">Нет фото объекта</span>
                </div>
              )}
              <button 
                onClick={() => { setSelectedId(null); setIsEditing(false); }}
                className="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-sm hover:bg-white rounded-full text-gray-700 shadow-sm transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar">
              <div className="p-6">
                {isEditing && isAdmin ? (
                  <div className="space-y-5">
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Название</label>
                      <input 
                        type="text" 
                        value={editData.name || ''} 
                        onChange={e => setEditData({...editData, name: e.target.value})}
                        className="w-full text-sm border border-gray-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Описание</label>
                      <textarea 
                        value={editData.description || ''} 
                        onChange={e => setEditData({...editData, description: e.target.value})}
                        className="w-full text-sm border border-gray-200 rounded-lg p-2.5 h-28 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Цвет на карте</label>
                      <div className="flex gap-3 items-center">
                        <input 
                          type="color" 
                          value={editData.color || '#E8ECEF'} 
                          onChange={e => setEditData({...editData, color: e.target.value})}
                          className="h-10 w-10 rounded cursor-pointer border-0 p-0"
                        />
                        <input 
                          type="text" 
                          value={editData.color || '#E8ECEF'} 
                          onChange={e => setEditData({...editData, color: e.target.value})}
                          className="flex-1 text-sm border border-gray-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Координаты и размеры</label>
                      <div className="grid grid-cols-2 gap-3 bg-gray-50 p-3 rounded-xl border border-gray-100">
                        <div>
                          <label className="block text-[10px] text-gray-500 mb-1">X Position</label>
                          <input 
                            type="number" 
                            value={editData.x || 0} 
                            onChange={e => setEditData({...editData, x: parseFloat(e.target.value)})}
                            className="w-full text-sm border border-gray-200 rounded-md p-2"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-500 mb-1">Z Position</label>
                          <input 
                            type="number" 
                            value={editData.z || 0} 
                            onChange={e => setEditData({...editData, z: parseFloat(e.target.value)})}
                            className="w-full text-sm border border-gray-200 rounded-md p-2"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-500 mb-1">Ширина</label>
                          <input 
                            type="number" 
                            value={editData.width || 2} 
                            onChange={e => setEditData({...editData, width: parseFloat(e.target.value)})}
                            className="w-full text-sm border border-gray-200 rounded-md p-2"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-gray-500 mb-1">Длина</label>
                          <input 
                            type="number" 
                            value={editData.length || 2} 
                            onChange={e => setEditData({...editData, length: parseFloat(e.target.value)})}
                            className="w-full text-sm border border-gray-200 rounded-md p-2"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-[10px] text-gray-500 mb-1">Высота</label>
                          <input 
                            type="number" 
                            value={editData.height || 1} 
                            onChange={e => setEditData({...editData, height: parseFloat(e.target.value)})}
                            className="w-full text-sm border border-gray-200 rounded-md p-2"
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Фотография</label>
                      <label className="cursor-pointer bg-white hover:bg-gray-50 text-blue-600 py-2.5 px-4 rounded-lg text-sm font-medium border border-blue-200 flex items-center justify-center gap-2 transition-colors border-dashed">
                        <ImageIcon size={18} /> Загрузить изображение
                        <input 
                          type="file" 
                          accept="image/*" 
                          className="hidden" 
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (event) => {
                                setEditData({...editData, imageUrl: event.target?.result as string});
                              };
                              reader.readAsDataURL(file);
                            }
                          }} 
                        />
                      </label>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          selectedTitle?.status === 'В графике' ? 'bg-green-100 text-green-700' :
                          selectedTitle?.status === 'Отставание' ? 'bg-red-100 text-red-700' :
                          selectedTitle?.status === 'Риск' ? 'bg-orange-100 text-orange-700' :
                          selectedTitle?.status === 'Завершено' ? 'bg-blue-100 text-blue-700' :
                          'bg-gray-100 text-gray-600'
                        }`}>
                          {selectedTitle?.status}
                        </span>
                        <span className="text-xs text-gray-400 font-medium">Титул {selectedTitle?.number}</span>
                      </div>
                      <h2 className="text-2xl font-bold text-gray-900 leading-tight">{selectedTitle?.name}</h2>
                    </div>
                    
                    {selectedTitle?.description ? (
                      <div className="text-sm text-gray-600 leading-relaxed">
                        {selectedTitle.description}
                      </div>
                    ) : (
                      <div className="text-sm text-gray-400 italic">
                        Описание отсутствует.
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4 py-4 border-y border-gray-100">
                      <div>
                        <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Подрядчик</div>
                        <div className="text-sm font-medium text-gray-800">{selectedTitle?.contractor || '—'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Ответственный</div>
                        <div className="text-sm font-medium text-gray-800">{selectedTitle?.manager || '—'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Начало</div>
                        <div className="text-sm font-medium text-gray-800">{selectedTitle?.startDate ? new Date(selectedTitle.startDate).toLocaleDateString() : '—'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Окончание</div>
                        <div className="text-sm font-medium text-gray-800">{selectedTitle?.deadline ? new Date(selectedTitle.deadline).toLocaleDateString() : '—'}</div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-end mb-2">
                        <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">Прогресс</div>
                        <div className="text-lg font-bold text-blue-600">{selectedTitle?.progress || 0}%</div>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
                        <div 
                          className="bg-blue-500 h-2.5 rounded-full transition-all duration-500" 
                          style={{ width: `${selectedTitle?.progress || 0}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Footer Actions */}
            <div className="p-4 border-t border-gray-100 bg-gray-50 shrink-0">
              {isEditing && isAdmin ? (
                <div className="flex gap-2">
                  <button 
                    onClick={handleSave}
                    className="flex-1 bg-blue-600 text-white py-2.5 rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center justify-center gap-2 transition-colors shadow-sm"
                  >
                    <Save size={16} /> Сохранить
                  </button>
                  <button 
                    onClick={() => setIsEditing(false)}
                    className="px-4 bg-white text-gray-700 py-2.5 rounded-lg text-sm font-medium hover:bg-gray-50 border border-gray-200 transition-colors"
                  >
                    Отмена
                  </button>
                  <button 
                    onClick={() => {
                      if (selectedTitle && window.confirm('Вы уверены, что хотите удалить это здание?')) {
                        deleteTitle(selectedTitle.id);
                        setSelectedId(null);
                        setIsEditing(false);
                      }
                    }}
                    className="px-3 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
                    title="Удалить здание"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ) : isAdmin ? (
                <button 
                  onClick={handleEditClick}
                  className="w-full bg-white text-blue-600 py-2.5 rounded-lg text-sm font-medium hover:bg-blue-50 flex items-center justify-center gap-2 border border-blue-200 transition-colors shadow-sm"
                >
                  <Edit2 size={16} /> Редактировать данные
                </button>
              ) : null}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
