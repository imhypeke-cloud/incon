import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, Tooltip } from 'recharts';
import { ProjectStatus, ModuleType, Title, HumanResource, Equipment } from '../types';
import { INITIAL_EXECUTION_KPIS } from '../constants';
import { 
  Users, 
  Truck, 
  Layers, 
  Calendar,
  ChevronRight,
  ArrowUpRight,
  AlertCircle,
  Activity
} from 'lucide-react';

interface GeneralStatusProps {
  onNavigate: (m: ModuleType) => void;
  titles: Title[];
  hr: HumanResource[];
  equipment: Equipment[];
}

const GeneralStatus: React.FC<GeneralStatusProps> = ({ onNavigate, titles = [], hr = [], equipment = [] }) => {
  const stats = useMemo(() => {
    const safeTitles = Array.isArray(titles) ? titles : [];
    const totalRC = safeTitles.reduce((acc, t) => acc + (t.rc?.total || 0), 0);
    const doneRC = safeTitles.reduce((acc, t) => acc + (t.rc?.done || 0), 0);
    const rcProgress = totalRC > 0 ? (doneRC / totalRC) * 100 : 0;

    const totalSC = safeTitles.reduce((acc, t) => acc + (t.sc?.total || 0), 0);
    const doneSC = safeTitles.reduce((acc, t) => acc + (t.sc?.done || 0), 0);
    const scProgress = totalSC > 0 ? (doneSC / totalSC) * 100 : 0;

    const arDone = INITIAL_EXECUTION_KPIS.sandwich.value;
    const arProgress = INITIAL_EXECUTION_KPIS.sandwich.percent;
    const arTotal = arProgress > 0 ? arDone / (arProgress / 100) : 0;

    const khTotal = 28; 
    const khDone = 28;  
    const khProgress = (khDone / khTotal) * 100;

    const safeHr = Array.isArray(hr) ? hr : [];
    const safeEquipment = Array.isArray(equipment) ? equipment : [];

    const totalITR = safeHr.find(item => item.subcontractor === 'ИТОГО')?.itr ?? safeHr.reduce((acc, item) => acc + Number(item.itr || 0), 0);
    const totalWorkers = safeHr.find(item => item.subcontractor === 'ИТОГО')?.workers ?? safeHr.reduce((acc, item) => acc + Number(item.workers || 0), 0);
    const totalPeople = safeHr.find(item => item.subcontractor === 'ИТОГО')?.total ?? (Number(totalITR) + Number(totalWorkers));
    
    const hrDate = safeHr.length > 0 
      ? safeHr.reduce((latest, item) => {
          if (!item.lastUpdate || item.lastUpdate === '-') return latest;
          if (!latest || latest === '-') return item.lastUpdate;
          try {
            const [d1, m1, y1] = latest.split('.').map(Number);
            const [d2, m2, y2] = item.lastUpdate.split('.').map(Number);
            const date1 = new Date(y1, m1 - 1, d1);
            const date2 = new Date(y2, m2 - 1, d2);
            return date2 > date1 ? item.lastUpdate : latest;
          } catch (e) {
            return latest || item.lastUpdate;
          }
        }, safeHr[0]?.lastUpdate || '17.03.2026')
      : '17.03.2026';

    const genEquipment = safeEquipment.reduce((acc, item) => acc + (item.ownerType === 'GEN' ? Number(item.total || 0) : 0), 0);
    const subEquipment = safeEquipment.reduce((acc, item) => acc + (item.ownerType === 'SUB' ? Number(item.total || 0) : 0), 0);
    const totalEquipment = genEquipment + subEquipment;
    const equipmentDate = hrDate;

    const statusCounts = {
      [ProjectStatus.IN_SCHEDULE]: safeTitles.filter(t => t.status === ProjectStatus.IN_SCHEDULE).length || 0,
      [ProjectStatus.RISK]: safeTitles.filter(t => t.status === ProjectStatus.RISK).length || 0,
      [ProjectStatus.DELAY]: safeTitles.filter(t => t.status === ProjectStatus.DELAY).length || 0,
      [ProjectStatus.COMPLETED]: safeTitles.filter(t => t.status === ProjectStatus.COMPLETED).length || 0,
    };

    return {
      totalRC, doneRC, rcProgress,
      totalSC, doneSC, scProgress,
      arTotal, arDone, arProgress,
      khTotal, khDone, khProgress,
      totalPeople, totalITR, totalWorkers,
      totalEquipment, genEquipment, subEquipment,
      statusCounts, hrDate, equipmentDate,
      safeTitles
    };
  }, [titles, hr, equipment]);

  const pizzaData = [
    { name: 'В графике', value: stats.statusCounts[ProjectStatus.IN_SCHEDULE], color: '#10b981' },
    { name: 'Риск', value: stats.statusCounts[ProjectStatus.RISK], color: '#f59e0b' },
    { name: 'Отставание', value: stats.statusCounts[ProjectStatus.DELAY], color: '#ef4444' },
    { name: 'Завершено', value: stats.statusCounts[ProjectStatus.COMPLETED], color: '#3b82f6' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-700 pb-10">
      
      {/* ВЕРХНИЙ РЯД: ЛЮДИ И ТЕХНИКА */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Людские ресурсы */}
        <div 
          onClick={() => onNavigate('HR_RESOURCES')}
          className="bg-white p-7 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col justify-between group cursor-pointer hover:shadow-xl hover:shadow-indigo-500/5 transition-all duration-500 relative overflow-hidden"
        >
          <div className="absolute top-6 right-6 w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 group-hover:bg-indigo-600 group-hover:text-white group-hover:rotate-45 transition-all duration-500">
            <ArrowUpRight size={18} strokeWidth={3} />
          </div>
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
              <Users size={24} />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-800 uppercase tracking-tight leading-none">Людские ресурсы</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5 flex items-center">
                <Calendar size={10} className="mr-1.5" /> Актуальность на {stats.hrDate}
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between mt-auto">
            {/* Left: Total */}
            <div className="flex flex-col">
              <span className="text-5xl font-black text-slate-900 tracking-tighter leading-none">{stats.totalPeople}</span>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mt-2">Персонал на объекте</span>
            </div>
            
            {/* Right: Metrics */}
            <div className="flex flex-col items-end space-y-3">
              <div className="text-right">
                <span className="text-xl font-black text-indigo-600 leading-none">{stats.totalITR}</span>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-0.5">ИТР состав</p>
              </div>
              <div className="text-right">
                <span className="text-xl font-black text-emerald-600 leading-none">{stats.totalWorkers}</span>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-0.5">Рабочий персонал</p>
              </div>
            </div>
          </div>
        </div>

        {/* Техника и механизмы */}
        <div 
          onClick={() => onNavigate('EQUIPMENT')}
          className="bg-white p-7 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col justify-between group cursor-pointer hover:shadow-xl hover:shadow-orange-500/5 transition-all duration-500 relative overflow-hidden"
        >
          <div className="absolute top-6 right-6 w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 group-hover:bg-orange-500 group-hover:text-white group-hover:rotate-45 transition-all duration-500">
            <ArrowUpRight size={18} strokeWidth={3} />
          </div>
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-orange-100">
              <Truck size={24} />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-800 uppercase tracking-tight leading-none">Техника</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5 flex items-center">
                <Calendar size={10} className="mr-1.5" /> Актуальность на {stats.equipmentDate}
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between mt-auto">
            {/* Left: Total */}
            <div className="flex flex-col">
              <span className="text-5xl font-black text-slate-900 tracking-tighter leading-none">{stats.totalEquipment}</span>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mt-2">Техника на объекте</span>
            </div>
            
            {/* Right: Metrics */}
            <div className="flex flex-col items-end space-y-3">
              <div className="text-right">
                <span className="text-xl font-black text-orange-600 leading-none">{stats.genEquipment}</span>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-0.5">Генподряд</p>
              </div>
              <div className="text-right">
                <span className="text-xl font-black text-slate-600 leading-none">{stats.subEquipment}</span>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-0.5">Субподряд</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* НИЖНИЙ РЯД: СПИСОК РАЗДЕЛОВ И СОСТОЯНИЕ */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Детализация разделов */}
        <div className="lg:col-span-2 bg-white p-7 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col">
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center border border-blue-100">
              <Layers size={24} />
            </div>
            <h3 className="text-base font-black text-slate-800 uppercase tracking-tight">Детализация разделов</h3>
          </div>
          <div className="space-y-3 flex-1">
            <NavListButton label="Железобетон (КЖ)" progress={stats.rcProgress} done={stats.doneRC} total={stats.totalRC} unit="м3" color="blue" onClick={() => onNavigate('TITLES')} />
            <NavListButton label="Металлоконструкции (КМ)" progress={stats.scProgress} done={stats.doneSC} total={stats.totalSC} unit="тн" color="orange" onClick={() => onNavigate('TITLES')} />
            <NavListButton label="Сэндвич-панели (АР)" progress={stats.arProgress} done={stats.arDone} total={stats.arTotal} unit="м2" color="emerald" onClick={() => onNavigate('EXECUTION_SUMMARY')} />
            <NavListButton label="Технологическое оборудование" progress={stats.khProgress} done={stats.khDone} total={stats.khTotal} unit="компл" color="slate" onClick={() => onNavigate('TITLES')} />
          </div>
        </div>

        {/* Состояние объектов */}
        <div 
          onClick={() => onNavigate('TITLES')}
          className="lg:col-span-3 bg-white p-7 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col group cursor-pointer hover:shadow-xl transition-all duration-500 relative overflow-hidden"
        >
          <div className="absolute top-6 right-6 w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 group-hover:bg-slate-900 group-hover:text-white group-hover:rotate-45 transition-all duration-500 border border-slate-100">
            <ArrowUpRight size={18} strokeWidth={3} />
          </div>
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-1.5 h-6 bg-blue-600 rounded-full"></div>
            <h3 className="text-base font-black text-slate-800 uppercase tracking-tight">Состояние объектов</h3>
          </div>

          <div className="flex flex-col md:flex-row items-center gap-10">
            
            {/* ✅ Диаграмма — ИСПРАВЛЕНО */}
            <div className="h-[220px] w-full md:w-1/2 relative flex items-center justify-center">
              <PieChart width={280} height={220}>
                <Pie
                  data={pizzaData}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={95}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                >
                  {pizzaData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px'}}
                  itemStyle={{fontSize: '11px', fontWeight: '900', textTransform: 'uppercase'}}
                />
              </PieChart>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <Activity size={32} className="text-slate-100" />
              </div>
            </div>

            {/* Списки отстающих и рисков */}
            <div className="w-full md:w-1/2 space-y-6">
              <div>
                <div className="flex items-center space-x-2 mb-3">
                  <AlertCircle size={14} className="text-rose-500" />
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Критическое отставание ({stats.statusCounts[ProjectStatus.DELAY]})</span>
                </div>
                <div className="space-y-2 max-h-[100px] overflow-y-auto custom-scrollbar pr-2">
                  {stats.safeTitles.filter(t => t.status === ProjectStatus.DELAY).length > 0 ? (
                    stats.safeTitles.filter(t => t.status === ProjectStatus.DELAY).map(t => (
                      <div key={t.id} className="flex justify-between items-center bg-rose-50 px-3 py-2 rounded-xl border border-rose-100/50">
                        <span className="text-[11px] font-black text-rose-700">{t.number}</span>
                        <span className="text-[10px] font-bold text-slate-700 truncate ml-3 flex-1">{t.name}</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-[10px] text-slate-300 font-bold uppercase italic">Отставаний нет</p>
                  )}
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-2 mb-3">
                  <AlertCircle size={14} className="text-amber-500" />
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Зона риска ({stats.statusCounts[ProjectStatus.RISK]})</span>
                </div>
                <div className="space-y-2 max-h-[100px] overflow-y-auto custom-scrollbar pr-2">
                  {stats.safeTitles.filter(t => t.status === ProjectStatus.RISK).length > 0 ? (
                    stats.safeTitles.filter(t => t.status === ProjectStatus.RISK).map(t => (
                      <div key={t.id} className="flex justify-between items-center bg-amber-50 px-3 py-2 rounded-xl border border-amber-100/50">
                        <span className="text-[11px] font-black text-amber-700">{t.number}</span>
                        <span className="text-[10px] font-bold text-slate-700 truncate ml-3 flex-1">{t.name}</span>
                      </div>
                    ))
                  ) : (
                    <p className="text-[10px] text-slate-300 font-bold uppercase italic">Рисков нет</p>
                  )}
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

// КОМПОНЕНТ КНОПКИ
const NavListButton: React.FC<{ 
  label: string; 
  progress: number; 
  done: number;
  total: number;
  unit: string;
  color: 'blue' | 'orange' | 'emerald' | 'slate';
  onClick: () => void;
}> = ({ label, progress, done, total, unit, color, onClick }) => {
  const themes = {
    blue: { bg: 'hover:bg-blue-50', text: 'text-blue-600', fill: 'bg-blue-600', border: 'border-slate-100' },
    orange: { bg: 'hover:bg-orange-50', text: 'text-orange-600', fill: 'bg-orange-600', border: 'border-slate-100' },
    emerald: { bg: 'hover:bg-emerald-50', text: 'text-emerald-600', fill: 'bg-emerald-600', border: 'border-slate-100' },
    slate: { bg: 'hover:bg-slate-50', text: 'text-slate-600', fill: 'bg-slate-600', border: 'border-slate-100' }
  };
  const theme = themes[color];

  return (
    <button 
      onClick={onClick}
      className={`w-full group px-5 py-4 rounded-2xl border ${theme.border} bg-white ${theme.bg} transition-all duration-300 flex items-center justify-between hover:shadow-md hover:translate-x-1`}
    >
      <div className="flex items-center space-x-4 flex-1">
        <div className={`w-1 h-8 rounded-full ${theme.fill} opacity-50 group-hover:opacity-100 transition-opacity`} />
        <div className="text-left">
          <h4 className="text-[11px] font-black text-slate-800 uppercase tracking-tight leading-none mb-1.5">{label}</h4>
          <p className="text-[10px] font-bold text-slate-400">
            {typeof done === 'number' ? done.toLocaleString('ru-RU') : '0'} / {typeof total === 'number' ? total.toLocaleString('ru-RU') : '0'} {unit}
          </p>
        </div>
      </div>
      <div className="flex items-center space-x-6">
        <div className="text-right">
          <p className={`text-sm font-black ${theme.text} leading-none`}>{progress.toFixed(1)}%</p>
          <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest mt-1">Прогресс</p>
        </div>
        <ChevronRight size={16} className="text-slate-200 group-hover:text-slate-900 transition-colors" />
      </div>
    </button>
  );
};

export default GeneralStatus;