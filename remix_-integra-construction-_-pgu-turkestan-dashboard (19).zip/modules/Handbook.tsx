
import React from 'react';
import { Book, FileText, Search, ExternalLink } from 'lucide-react';

const Handbook: React.FC = () => {
  const documents = [
    { title: 'СП РК 5.03-107-2013', desc: 'Несущие и ограждающие конструкции', cat: 'Нормативы' },
    { title: 'Классификатор работ v1.2', desc: 'Унифицированный перечень видов работ ПГУ', cat: 'Классификаторы' },
    { title: 'Справочник материалов', desc: 'Технические условия для ПГУ Туркестан', cat: 'Материалы' },
    { title: 'Реестр поставщиков', desc: 'Актуальный список доверенных контрагентов', cat: 'Справочные данные' },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center space-x-4">
        <div className="flex-1 flex items-center bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg">
          <Search size={16} className="text-slate-400 mr-2" />
          <input type="text" placeholder="Поиск по базе знаний..." className="bg-transparent border-none focus:ring-0 text-sm w-full outline-none" />
        </div>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-xs font-bold">Загрузить новый документ</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {documents.map((doc, idx) => (
          <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-blue-300 transition-all group flex flex-col h-full">
            <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-colors mb-4">
              <FileText size={20} />
            </div>
            <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1">{doc.cat}</span>
            <h4 className="font-bold text-slate-800 text-sm mb-2">{doc.title}</h4>
            <p className="text-xs text-slate-500 flex-1">{doc.desc}</p>
            <button className="mt-4 flex items-center text-[10px] font-bold text-slate-400 uppercase hover:text-blue-600 group-hover:translate-x-1 transition-all">
              Открыть документ <ExternalLink size={12} className="ml-1" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Handbook;
