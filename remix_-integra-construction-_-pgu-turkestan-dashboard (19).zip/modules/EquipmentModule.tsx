import React, { useState, useMemo } from 'react';
import { Equipment, EquipmentCategory } from '../types';
import { 
  Truck, 
  Construction, 
  Search, 
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';

interface EquipmentModuleProps {
  data: Equipment[];
}

const EquipmentModule: React.FC<EquipmentModuleProps> = ({ data }) => {
  const [activeCategory, setActiveCategory] = useState<EquipmentCategory | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const stats = useMemo(() => {
    const safeData = Array.isArray(data) ? data : [];
    // Sum the 'total' property instead of counting array length
    const total = safeData.reduce((acc, e) => acc + Number(e.total || 0), 0);
    const gen = safeData.reduce((acc, e) => acc + Number(e.genPodryad || 0), 0);
    const sub = safeData.reduce((acc, e) => acc + Number(e.subPodryad || 0), 0);
    return { total, gen, sub };
  }, [data]);

  const filteredData = useMemo(() => {
    const safeData = Array.isArray(data) ? data : [];
    return safeData.filter(e => {
      const catMatch = activeCategory === 'ALL' || e.category === activeCategory;
      const searchMatch = !searchQuery || 
        e.type?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        e.model?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        e.plateNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.operator?.toLowerCase().includes(searchQuery.toLowerCase());
      return catMatch && searchMatch;
    });
  }, [data, activeCategory, searchQuery]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-800 uppercase tracking-tight leading-none">Техника</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5">
            Сводка по технике
          </p>
        </div>
      </div>

      {/* Сводная статистика */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard 
          icon={<Truck size={24} />} 
          label="Всего техники" 
          value={stats.total} 
          color="slate" 
        />
        <StatCard 
          icon={<ShieldCheck size={24} />} 
          label="Генподряд (Integra)" 
          value={stats.gen} 
          color="blue" 
        />
        <StatCard 
          icon={<Zap size={24} />} 
          label="Субподрядчики" 
          value={stats.sub} 
          color="orange" 
        />
      </div>

      {/* Панель инструментов */}
      <div className="bg-white p-4 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col lg:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <button 
            onClick={() => setActiveCategory('ALL')}
            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
              activeCategory === 'ALL' ? 'bg-slate-900 text-white shadow-lg' : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
            }`}
          >
            Все
          </button>
          {Object.values(EquipmentCategory).map(cat => (
            <button 
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeCategory === cat ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center space-x-3 w-full lg:w-auto">
          <div className="relative flex-1 lg:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input 
              type="text" 
              placeholder="Поиск по модели, номеру или водителю..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-medium outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all"
            />
          </div>
        </div>
      </div>

      {/* Основной контент (Только таблица) */}
      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead>
              <tr className="bg-slate-50 text-[10px] font-black uppercase text-slate-400 tracking-widest border-b border-slate-100">
                <th className="px-6 py-4">Тип / Модель</th>
                <th className="px-6 py-4 text-center">Кол-во</th>
                <th className="px-6 py-4">Водитель / Оператор</th>
                <th className="px-6 py-4">Собственник</th>
                <th className="px-6 py-4">Категория</th>
                <th className="px-6 py-4 text-center">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredData.map(e => (
                <tr key={e.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${e.ownerType === 'GEN' ? 'bg-blue-50 text-blue-600' : 'bg-orange-50 text-orange-600'}`}>
                        {getCategoryIcon(e.category)}
                      </div>
                      <div>
                        <p className="text-xs font-black text-slate-800">{e.type}</p>
                        <p className="text-[10px] font-bold text-slate-400">{e.model}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="font-mono text-[11px] font-black bg-slate-100 px-2 py-1 rounded text-slate-600 border border-slate-200/50">
                      {e.total} ед.
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-slate-700">{e.operator}</span>
                      <span className="text-[10px] text-blue-500 font-black">{e.phone}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-1.5">
                      <span className={`w-1.5 h-1.5 rounded-full ${e.ownerType === 'GEN' ? 'bg-blue-500' : 'bg-orange-500'}`} />
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter">{e.ownerName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest bg-slate-100/50 px-2 py-0.5 rounded-md">
                      {e.category}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center">
                      <span className="flex items-center space-x-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[9px] font-black uppercase">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span>Работа</span>
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: number; color: string }> = ({ icon, label, value, color }) => {
  const styles: any = {
    slate: 'bg-slate-900 text-white',
    blue: 'bg-white text-slate-800 border-slate-100',
    orange: 'bg-white text-slate-800 border-slate-100'
  };
  const iconColors: any = {
    slate: 'bg-white/10 text-blue-400',
    blue: 'bg-blue-50 text-blue-600',
    orange: 'bg-orange-50 text-orange-600'
  };

  return (
    <div className={`p-6 rounded-[2.5rem] border shadow-sm flex items-center justify-between ${styles[color]}`}>
      <div className="flex items-center space-x-4">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${iconColors[color]}`}>
          {icon}
        </div>
        <div>
          <p className={`text-[10px] font-black uppercase tracking-widest leading-none mb-1.5 ${color === 'slate' ? 'text-slate-400' : 'text-slate-400'}`}>
            {label}
          </p>
          <p className="text-3xl font-black leading-none tracking-tight">{value}</p>
        </div>
      </div>
    </div>
  );
};

const getCategoryIcon = (cat: EquipmentCategory) => {
  switch (cat) {
    case EquipmentCategory.TRUCKS: return <Truck size={20} />;
    case EquipmentCategory.LIFTING: return <Construction size={20} />;
    case EquipmentCategory.EARTHMOVING: return <Construction size={20} />;
    case EquipmentCategory.ROAD: return <Construction size={20} />;
    case EquipmentCategory.TRANSPORT: return <Truck size={20} />;
    default: return <Info size={20} />;
  }
};

export default EquipmentModule;