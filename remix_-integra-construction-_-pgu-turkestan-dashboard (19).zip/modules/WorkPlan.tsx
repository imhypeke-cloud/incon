import React, { useMemo, useState, useEffect, useRef } from 'react';
import { WorkPlanRecord, WorkPlanMonth, WorkPlanPeriod } from '../types';
import { useData } from '../services/DataContext';
import { INITIAL_WORK_PLAN, DATA_VERSION } from '../constants';
import { 
  Search, 
  Download, 
  Filter, 
  ChevronDown, 
  ChevronRight, 
  ArrowUpDown, 
  Upload,
  FileSpreadsheet,
  Lock,
  Calendar,
  AlertCircle,
  RefreshCw,
  CalendarPlus
} from 'lucide-react';
import * as XLSX from 'xlsx';

const WorkPlan: React.FC = () => {
  const { updateWorkPlan } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedRows, setExpandedRows] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'error' | 'success' } | null>(null);

  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  
  // Month Management
  const [months, setMonths] = useState<WorkPlanMonth[]>([]);
  const [activeMonthId, setActiveMonthId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const updateInputRef = useRef<HTMLInputElement>(null);

  // Load months from localStorage on mount
  useEffect(() => {
    const savedVersion = localStorage.getItem('workPlan_dataVersion');
    const savedMonths = localStorage.getItem('workPlan_months');
    
    if (savedVersion !== DATA_VERSION || !savedMonths) {
      // Force reload of initial data to reflect new responsibles
      localStorage.removeItem('workPlan_months');
      
      // Initialize with default month
      const defaultMonth: WorkPlanMonth = {
        id: 'default_month',
        name: 'План работ (Март 2026)',
        isArchived: false,
        records: INITIAL_WORK_PLAN,
        periodHeaders: [
          { id: 'mar', name: 'Март', type: 'month' },
          { id: 'w1', name: '02.03 – 08.03', type: 'week' },
          { id: 'w2', name: '09.03 – 15.03', type: 'week' },
          { id: 'w3', name: '16.03 – 22.03', type: 'week' },
          { id: 'w4', name: '23.03 – 29.03', type: 'week' }
        ]
      };
      setMonths([defaultMonth]);
      setActiveMonthId(defaultMonth.id);
      localStorage.setItem('workPlan_dataVersion', DATA_VERSION);
    } else {
      try {
        const parsed = JSON.parse(savedMonths);
        setMonths(parsed);
        if (parsed.length > 0) {
          setActiveMonthId(parsed[0].id);
        }
      } catch (e) {
        console.error('Error parsing workPlan_months', e);
      }
    }
  }, []);

  // Save months to localStorage whenever they change
  useEffect(() => {
    if (months.length > 0) {
      localStorage.setItem('workPlan_months', JSON.stringify(months));
    }
  }, [months]);

  // Sync active month data to global context
  useEffect(() => {
    if (activeMonthId) {
      const activeMonth = months.find(m => m.id === activeMonthId);
      if (activeMonth) {
        updateWorkPlan(activeMonth.records);
      }
    }
  }, [activeMonthId, months, updateWorkPlan]);

  const activeMonth = useMemo(() => 
    months.find(m => m.id === activeMonthId), 
  [months, activeMonthId]);

  const parseExcelData = (data: any[][]) => {
    // 1. Identify Header Row
    let headerRowIndex = -1;
    for (let i = 0; i < Math.min(20, data.length); i++) {
      const row = data[i];
      if (row.some(cell => typeof cell === 'string' && (cell?.toLowerCase().includes('ответственный') || cell?.toLowerCase().includes('наименование')))) {
        headerRowIndex = i;
        break;
      }
    }

    if (headerRowIndex === -1) throw new Error("Не удалось найти заголовок таблицы (Ответственный/Наименование)");

    const row1 = data[headerRowIndex];
    const row2 = data[headerRowIndex + 1] || [];

    // 2. Identify Columns & Periods
    const colMap: any = {};
    const periodHeaders: { id: string; name: string; type: 'month' | 'week' }[] = [];
    const periodMap: { [colIndex: number]: { id: string; type: 'plan' | 'fact' | 'diff' } } = {};

    let currentPeriod: { id: string; name: string; type: 'month' | 'week' } | null = null;

    for (let i = 0; i < row1.length; i++) {
      const cell1 = row1[i] ? String(row1[i]).toLowerCase().trim() : '';
      const cell2 = row2[i] ? String(row2[i]).toLowerCase().trim() : '';

      // Fixed columns (Row 1 or Row 2)
      if (cell1.includes('ответственный') || cell2.includes('ответственный')) colMap.responsible = i;
      else if (cell1.includes('подрядчик') || cell2.includes('подрядчик')) colMap.contractor = i;
      else if (cell1.includes('титул') || cell2.includes('титул')) colMap.title = i;
      else if (cell1.includes('наименование') || cell2.includes('наименование')) colMap.name = i;
      else if (cell1.includes('дата завершения') || cell2.includes('дата завершения') || cell1.includes('гпр')) colMap.gprDate = i;
      else if (cell1.includes('ед. изм') || cell2.includes('ед. изм') || cell1.includes('ед.изм')) colMap.unit = i;
      else if (cell2.includes('по проекту') || cell1.includes('по проекту')) colMap.total = i;
      else if (cell2.includes('остаток') || cell1.includes('остаток')) colMap.remainder = i;

      // Period Detection
      const isPeriodCol = cell2 === 'план' || cell2 === 'факт' || cell2 === '+/-' || cell2 === '+ / -' || cell2.includes('откл');
      
      if (isPeriodCol) {
        if (row1[i] && String(row1[i]).trim() !== '') {
          const isMonth = /январь|февраль|март|апрель|май|июнь|июль|август|сентябрь|октябрь|ноябрь|декабрь/i.test(cell1);
          const id = `p_${periodHeaders.length}_${i}`;
          currentPeriod = { id, name: String(row1[i]).trim(), type: isMonth ? 'month' : 'week' };
          periodHeaders.push(currentPeriod);
        }
        
        if (currentPeriod) {
          if (cell2 === 'план') periodMap[i] = { id: currentPeriod.id, type: 'plan' };
          else if (cell2 === 'факт') periodMap[i] = { id: currentPeriod.id, type: 'fact' };
          else periodMap[i] = { id: currentPeriod.id, type: 'diff' };
        }
      }
    }

    // 3. Parse Rows
    const records: WorkPlanRecord[] = [];
    let currentResponsible = "Не назначен";
    let currentTitle = "";

    for (let i = headerRowIndex + 2; i < data.length; i++) {
      const row = data[i];
      if (!row || row.length === 0) continue;

      // Skip summary rows
      const firstCell = row[colMap.responsible || 0];
      if (typeof firstCell === 'string' && (firstCell?.toLowerCase().includes('итого') || firstCell?.toLowerCase().includes('всего'))) {
        continue;
      }

      // Update context
      if (colMap.responsible !== undefined && row[colMap.responsible]) currentResponsible = String(row[colMap.responsible]);
      if (colMap.title !== undefined && row[colMap.title]) currentTitle = String(row[colMap.title]);

      const name = colMap.name !== undefined ? row[colMap.name] : '';
      if (!name) continue;

      // Filter sections
      const lowerName = String(name || '').toLowerCase().trim();
      
      const periods: WorkPlanPeriod[] = periodHeaders.map(ph => ({
        ...ph,
        plan: 0,
        fact: 0,
        diff: 0
      }));

      // Fill periods
      Object.entries(periodMap).forEach(([colIdx, mapping]) => {
        const val = row[parseInt(colIdx)];
        const numVal = typeof val === 'number' ? val : parseFloat(String(val).replace(',', '.').replace(/\s/g, '')) || 0;
        
        const period = periods.find(p => p.id === mapping.id);
        if (period) {
          if (mapping.type === 'plan') period.plan = numVal;
          if (mapping.type === 'fact') period.fact = numVal;
          if (mapping.type === 'diff') period.diff = numVal;
        }
      });

      // Extract General Data
      const getVal = (idx: number) => {
        if (idx === undefined) return 0;
        const val = row[idx];
        return typeof val === 'number' ? val : parseFloat(String(val).replace(',', '.').replace(/\s/g, '')) || 0;
      };

      records.push({
        id: `row_${i}_${Math.random().toString(36).substr(2, 5)}`,
        responsible: currentResponsible,
        contractor: colMap.contractor !== undefined ? String(row[colMap.contractor] || '') : '',
        title: currentTitle || (colMap.title !== undefined ? String(row[colMap.title] || '') : ''),
        name: String(name),
        gprDate: colMap.gprDate !== undefined ? String(row[colMap.gprDate] || '') : '',
        unit: colMap.unit !== undefined ? String(row[colMap.unit] || '') : '',
        totalProject: getVal(colMap.total),
        remainder: getVal(colMap.remainder),
        periods
      });
    }

    return { records, periodHeaders };
  };

  const handleFileAction = async (e: React.ChangeEvent<HTMLInputElement>, action: 'create' | 'update') => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoading(true);

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, raw: false }) as any[][];

      const { records: newRecords, periodHeaders: newHeaders } = parseExcelData(jsonData);

      if (action === 'create') {
        const newMonth: WorkPlanMonth = {
          id: `month_${Date.now()}`,
          name: `Загрузка ${new Date().toLocaleDateString()}`,
          isArchived: false,
          records: newRecords,
          periodHeaders: newHeaders
        };
        setMonths(prev => [...prev, newMonth]);
        setActiveMonthId(newMonth.id);
        setMessage({ text: 'Данные успешно загружены', type: 'success' });
      } else if (action === 'update') {
        if (!activeMonth) {
          setMessage({ text: "Сначала выберите или создайте месяц для обновления", type: 'error' });
          return;
        }

        // 1. Identify new periods (by name)
        const existingNames = new Set(activeMonth.periodHeaders.map(h => h.name));
        const periodsToAdd = newHeaders.filter(h => !existingNames.has(h.name));
        
        if (periodsToAdd.length === 0) {
          setMessage({ text: "В файле не найдено новых периодов (недель), которых еще нет в таблице.", type: 'error' });
          return;
        }

        // 2. Update Headers
        const updatedHeaders = [...activeMonth.periodHeaders, ...periodsToAdd];

        // 3. Update Records
        const updatedRecords = activeMonth.records.map(rec => {
          // Find matching record by Title and Name
          const match = newRecords.find(r => 
            r.title?.trim().toLowerCase() === rec.title?.trim().toLowerCase() && 
            r.name?.trim().toLowerCase() === rec.name?.trim().toLowerCase()
          );
          
          // Create new period objects for the new headers
          const newPeriodsData = periodsToAdd.map(h => {
            if (match) {
              const matchPeriod = match.periods.find(mp => mp.name === h.name);
              if (matchPeriod) return { 
                ...matchPeriod, 
                id: h.id
              };
            }
            return { ...h, plan: 0, fact: 0, diff: 0 };
          });

          return {
            ...rec,
            // Update remainder/total from new file if matched
            totalProject: match ? match.totalProject : rec.totalProject,
            remainder: match ? match.remainder : rec.remainder,
            periods: [...rec.periods, ...newPeriodsData]
          };
        });

        // Add brand new records that didn't exist before
        const currentKeys = new Set(activeMonth.records.map(r => `${r.title?.trim().toLowerCase()}|${r.name?.trim().toLowerCase()}`));
        const brandNewRecords = newRecords.filter(r => !currentKeys.has(`${r.title?.trim().toLowerCase()}|${r.name?.trim().toLowerCase()}`)).map(r => {
          // Align periods with the new global headers
          const alignedPeriods = updatedHeaders.map(h => {
            const p = r.periods.find(mp => mp.name === h.name);
            return p ? { ...p, id: h.id } : { ...h, plan: 0, fact: 0, diff: 0 };
          });
          
          return { ...r, periods: alignedPeriods };
        });

        const finalRecords = [...updatedRecords, ...brandNewRecords];
        
        const updatedMonth = { 
          ...activeMonth, 
          periodHeaders: updatedHeaders, 
          records: finalRecords 
        };
        
        setMonths(prev => prev.map(m => m.id === activeMonth.id ? updatedMonth : m));
        setMessage({ text: `Данные обновлены. Добавлено периодов: ${periodsToAdd.length}. Новых строк: ${brandNewRecords.length}`, type: 'success' });
      }

    } catch (error) {
      console.error("Error processing file:", error);
      setMessage({ text: "Ошибка при обработке файла: " + (error as Error).message, type: 'error' });
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (updateInputRef.current) updateInputRef.current.value = '';
    }
  };

  const toggleRow = (id: string) => {
    setExpandedRows(prev => 
      prev.includes(id) ? prev.filter(rowId => rowId !== id) : [...prev, id]
    );
  };

  const toggleAll = () => {
    if (expandedRows.length === Object.keys(groupedData).length) {
      setExpandedRows([]);
    } else {
      setExpandedRows(Object.keys(groupedData));
    }
  };

  const filteredData = useMemo(() => {
    if (!activeMonth) return [];
    return activeMonth.records.filter(record => 
      record.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.responsible?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [activeMonth, searchTerm]);

  // Group by Responsible
  const groupedData = useMemo<{ [key: string]: WorkPlanRecord[] }>(() => {
    const groups: { [key: string]: WorkPlanRecord[] } = {};
    filteredData.forEach(record => {
      if (!groups[record.responsible]) {
        groups[record.responsible] = [];
      }
      groups[record.responsible].push(record);
    });
    return groups;
  }, [filteredData]);

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const sortedGroups = useMemo(() => {
    const groups = Object.entries(groupedData);
    if (!sortConfig) return groups;

    return groups.sort((a: [string, WorkPlanRecord[]], b: [string, WorkPlanRecord[]]) => {
      const [respA, recordsA] = a;
      const [respB, recordsB] = b;

      if (sortConfig.key === 'responsible') {
        return sortConfig.direction === 'asc' 
          ? respA.localeCompare(respB)
          : respB.localeCompare(respA);
      }
      
      if (sortConfig.key === 'totalProject') {
        const totalA = recordsA.reduce((sum, r) => sum + r.totalProject, 0);
        const totalB = recordsB.reduce((sum, r) => sum + r.totalProject, 0);
        return sortConfig.direction === 'asc' ? totalA - totalB : totalB - totalA;
      }

      return 0;
    });
  }, [groupedData, sortConfig]);

  const getDiffColor = (val: number) => {
    if (val > 0) return 'text-emerald-600';
    if (val < 0) return 'text-rose-600';
    return 'text-slate-400';
  };

  const formatNumber = (num: any) => {
    if (num === undefined || num === null || isNaN(num)) return '0';
    return num.toLocaleString('ru-RU');
  };

  // Helper to get background color for period columns based on index
  const getPeriodBgColor = (index: number) => {
    const colors = [
      'bg-blue-50/30 text-blue-800', 
      'bg-indigo-50/30 text-indigo-800', 
      'bg-violet-50/30 text-violet-800', 
      'bg-purple-50/30 text-purple-800', 
      'bg-fuchsia-50/30 text-fuchsia-800',
      'bg-pink-50/30 text-pink-800'
    ];
    return colors[index % colors.length];
  };

  const TableHeaderCell = ({ 
    children, 
    className = "", 
    tooltip, 
    rowSpan = 1, 
    colSpan = 1,
    stickyLeft = false,
    stickyTop = false,
    leftOffset = 0,
    onClick
  }: any) => (
    <th 
      rowSpan={rowSpan} 
      colSpan={colSpan}
      className={`
        px-4 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider border-b border-slate-200
        ${stickyTop ? 'sticky top-0 z-20 bg-slate-50' : ''}
        ${stickyLeft ? 'sticky z-30 bg-slate-50' : ''}
        ${className}
        ${onClick ? 'cursor-pointer hover:bg-slate-100 transition-colors' : ''}
      `}
      style={stickyLeft ? { left: leftOffset } : {}}
      title={tooltip}
      onClick={onClick}
    >
      <div className={`flex items-center gap-1 ${className.includes('text-right') ? 'justify-end' : ''}`}>
        {children}
      </div>
    </th>
  );

  return (
    <div className="h-full flex flex-col space-y-4 animate-in fade-in duration-500 relative">
      {message && (
        <div className={`fixed top-4 right-4 px-4 py-3 rounded z-50 shadow-lg border ${message.type === 'error' ? 'bg-red-100 border-red-400 text-red-700' : 'bg-green-100 border-green-400 text-green-700'}`}>
          <span className="block sm:inline">{message.text}</span>
          <button className="absolute top-0 bottom-0 right-0 px-4 py-3" onClick={() => setMessage(null)}>
            <span className="text-xl">&times;</span>
          </button>
        </div>
      )}
      {/* Top Panel */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-xl font-bold text-slate-900">План работ</h1>
        
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text"
              placeholder="Поиск по титулу, работе..."
              className="pl-10 pr-4 py-2 bg-slate-100 border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <button 
            onClick={() => updateInputRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-sm font-semibold hover:bg-indigo-100 transition-colors"
            title="Добавить новые недели из файла без изменения существующих данных"
          >
            <Upload size={18} />
            <span>Обновить данные</span>
          </button>
          
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-600 rounded-xl text-sm font-semibold hover:bg-slate-200 transition-colors"
            title="Загрузить новый план (создаст новый месяц)"
          >
            <FileSpreadsheet size={18} />
            <span>Новый план</span>
          </button>

          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept=".xlsx, .xls" 
            onChange={(e) => handleFileAction(e, 'create')} 
          />
          <input 
            type="file" 
            ref={updateInputRef} 
            className="hidden" 
            accept=".xlsx, .xls" 
            onChange={(e) => handleFileAction(e, 'update')} 
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
        {activeMonth ? (
          <div className="flex-1 overflow-auto custom-scrollbar relative">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr>
                  <TableHeaderCell 
                    rowSpan={2} 
                    stickyTop 
                    stickyLeft 
                    leftOffset={0} 
                    className="min-w-[120px] border-r border-slate-200 shadow-[4px_0_8px_-4px_rgba(0,0,0,0.1)]"
                    onClick={() => handleSort('title')}
                  >
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center gap-2">
                        <span>Титул</span>
                        {sortConfig?.key === 'title' && (
                          <ArrowUpDown size={14} className={sortConfig.direction === 'desc' ? 'rotate-180' : ''} />
                        )}
                      </div>
                      <div 
                        className="p-1 hover:bg-slate-200 rounded cursor-pointer"
                        onClick={(e: any) => { e.stopPropagation(); toggleAll(); }}
                        title="Развернуть/Свернуть все"
                      >
                        {expandedRows.length > 0 ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                      </div>
                    </div>
                  </TableHeaderCell>
                  
                  <TableHeaderCell rowSpan={2} stickyTop className="min-w-[120px]">Подрядчик</TableHeaderCell>
                  <TableHeaderCell rowSpan={2} stickyTop className="min-w-[300px]">Наименование работ</TableHeaderCell>
                  <TableHeaderCell rowSpan={2} stickyTop className="text-center w-24">Дата ГПР</TableHeaderCell>
                  <TableHeaderCell rowSpan={2} stickyTop className="text-center w-20">Ед. изм.</TableHeaderCell>
                  <TableHeaderCell colSpan={2} stickyTop className="text-center border-r border-slate-200">Общие показатели</TableHeaderCell>
                  
                  {/* Dynamic Period Headers */}
                  {activeMonth.periodHeaders.map((header, idx) => (
                    <TableHeaderCell 
                      key={header.id} 
                      colSpan={3} 
                      stickyTop 
                      className={`text-center border-r border-slate-200 ${getPeriodBgColor(idx)}`}
                    >
                      {header.name}
                    </TableHeaderCell>
                  ))}
                </tr>
                <tr>
                  <th className="px-2 py-2 text-xs font-semibold text-slate-500 text-right sticky top-[45px] z-20 bg-white border-b border-slate-200">По проекту</th>
                  <th className="px-2 py-2 text-xs font-semibold text-slate-500 text-right sticky top-[45px] z-20 bg-white border-b border-slate-200 border-r">Остаток</th>
                  {/* Sub-headers for periods */}
                  {activeMonth.periodHeaders.map((header, idx) => (
                    <React.Fragment key={`${header.id}-sub`}>
                      <th className={`px-2 py-2 text-xs font-semibold text-slate-500 text-right sticky top-[45px] z-20 bg-white ${getPeriodBgColor(idx).split(' ')[0]} border-b border-slate-200`}>План</th>
                      <th className={`px-2 py-2 text-xs font-semibold text-slate-500 text-right sticky top-[45px] z-20 bg-white ${getPeriodBgColor(idx).split(' ')[0]} border-b border-slate-200`}>Факт</th>
                      <th className={`px-2 py-2 text-xs font-semibold text-slate-500 text-right sticky top-[45px] z-20 bg-white ${getPeriodBgColor(idx).split(' ')[0]} border-b border-slate-200 border-r`}>+/-</th>
                    </React.Fragment>
                  ))}
                </tr>
              </thead>
              
              <tbody className="divide-y divide-slate-100">
                {sortedGroups.map(([responsible, records]) => {
                  const isExpanded = expandedRows.includes(responsible);

                  return (
                    <React.Fragment key={responsible}>
                      {/* Group Header Row */}
                      <tr 
                        className="bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer group"
                        onClick={() => toggleRow(responsible)}
                      >
                        <td 
                          colSpan={7 + activeMonth.periodHeaders.length * 3}
                          className="sticky left-0 z-10 bg-slate-50 group-hover:bg-slate-100 px-4 py-4 border-b border-slate-200"
                        >
                          <div className="flex items-center gap-3">
                            <div 
                              className={`p-1 rounded-md transition-colors ${isExpanded ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-200 text-slate-500'}`}
                            >
                              {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                            </div>
                            <span className="font-semibold text-slate-800 text-sm">{responsible}</span>
                            <span className="ml-2 px-2 py-0.5 bg-slate-200 text-slate-600 rounded-full text-[10px] font-bold uppercase tracking-wider">
                              Титулов: {new Set(records.map(r => r.title)).size}
                            </span>
                          </div>
                        </td>
                      </tr>

                      {/* Detail Rows */}
                      {isExpanded && records.map((record, idx) => (
                        <tr key={record.id} className="hover:bg-slate-50/80 transition-colors group/row">
                          <td className="sticky left-0 z-10 bg-white group-hover/row:bg-slate-50/80 px-4 py-3 border-r border-slate-200 shadow-[4px_0_8px_-4px_rgba(0,0,0,0.1)]">
                            <span className="text-sm font-medium text-slate-700">{record.title}</span>
                          </td>
                          <td className="px-4 py-3 text-sm text-slate-700 font-medium">{record.contractor}</td>
                          <td className="px-4 py-3 text-sm text-slate-700 font-medium">
                            <div className="line-clamp-2" title={record.name}>{record.name}</div>
                          </td>
                          <td className="px-4 py-3 text-center text-xs text-slate-500">{record.gprDate}</td>
                          <td className="px-4 py-3 text-center text-xs text-slate-500">{record.unit}</td>
                          <td className="px-4 py-3 text-right text-sm text-slate-600 tabular-nums border-r border-slate-200">{formatNumber(record.totalProject)}</td>
                          <td className="px-4 py-3 text-right text-sm text-slate-600 tabular-nums border-r border-slate-200">{formatNumber(record.remainder)}</td>
                          
                          {/* Period Data */}
                          {activeMonth.periodHeaders.map((header) => {
                            const pData = record.periods.find(p => p.id === header.id) || { plan: 0, fact: 0, diff: 0 };
                            return (
                              <React.Fragment key={header.id}>
                                <td className="px-2 py-3 text-right text-sm text-slate-500 tabular-nums">{formatNumber(pData.plan)}</td>
                                <td className="px-2 py-3 text-right text-sm text-slate-500 tabular-nums">{formatNumber(pData.fact)}</td>
                                <td className={`px-2 py-3 text-right text-sm border-r border-slate-200 tabular-nums ${getDiffColor(pData.diff)}`}>{formatNumber(pData.diff)}</td>
                              </React.Fragment>
                            );
                          })}
                        </tr>
                      ))}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-slate-400 p-12">
            <FileSpreadsheet size={64} className="mb-4 opacity-20" />
            <p className="text-xl font-medium text-slate-600">Нет данных для отображения</p>
            <p className="text-sm max-w-md text-center mt-2 mb-6">
              Загрузите файл Excel с планом работ, чтобы начать. Файл должен содержать колонки "Ответственный", "Наименование" и данные по периодам.
            </p>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
            >
              Загрузить файл
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default WorkPlan;
