
import React, { useState, useMemo } from 'react';
import { 
  Package, 
  Truck, 
  Search, 
  Filter, 
  User, 
  Calendar, 
  Warehouse, 
  FileText,
  ClipboardList,
  ChevronLeft,
  ChevronRight,
  Clock,
  AlertCircle,
  MoreHorizontal,
  ArrowUpDown,
  AlertTriangle,
  Timer,
  History,
  Download
} from 'lucide-react';
import { AuditLog } from '../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface SupplyItem {
  id: string;           // Номер заявки
  date: string;         // Дата заявки
  material: string;     // Наименование
  unit: string;         // Ед. изм.
  qty: string | number; // Кол-во
  note: string;         // Примечание (из дока)
  responsible: string;  // Ответственное лицо
  status: string;       // Статус (1-4)
  supplier: string;     // Поставщик
  comment: string;      // Комментарии
  deliveryDate: string; // Дата поставки
  daysInWork: string | number; // Количество дней в работе
  title: string;        // Титул (объект)
}

interface SupplyRegistryProps {
  data: SupplyItem[];
  auditLogs: AuditLog[];
}

const SupplyRegistry: React.FC<SupplyRegistryProps> = ({ data = [], auditLogs = [] }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'ALL' | '1' | '2' | '3' | '4' | 'STORE' | 'CRITICAL'>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc'); // asc = от ранних к поздним
  const [showHistory, setShowHistory] = useState(false);
  const itemsPerPage = 50;
  
  // Дата актуальности данных (из файла)
  const DATA_DATE = "10.03.2026";

  // Вспомогательная функция парсинга даты DD.MM.YYYY
  const parseDate = (dateStr: any) => {
    if (!dateStr || dateStr === '—') return new Date(0);
    const str = String(dateStr);
    if (!str.includes('.')) return new Date(0);
    const parts = str.split('.');
    if (parts.length !== 3) return new Date(0);
    const [day, month, year] = parts.map(Number);
    return new Date(year, month - 1, day);
  };

  // Функция расчета дней в работе
  const calculateDays = (itemDate: any, explicitDays: any) => {
    // Если в исходных данных уже есть число дней (из OCR), используем его
    if (typeof explicitDays === 'number' && explicitDays > 0) return explicitDays;
    if (typeof explicitDays === 'string' && !isNaN(Number(explicitDays)) && Number(explicitDays) > 0) return Number(explicitDays);
    
    // Иначе считаем от даты заявки до текущей даты (актуальности)
    const start = parseDate(itemDate);
    const end = new Date(); // Use current date for calculation if not static
    
    if (start.getTime() === 0) return 0;

    const diffTime = end.getTime() - start.getTime();
    const days = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return days > 0 ? days : 0;
  };

  // Process data to ensure daysInWork is calculated
  const processedData = useMemo(() => {
    return data.map(item => ({
      ...item,
      daysInWork: calculateDays(item.date, item.daysInWork)
    }));
  }, [data]);

  const stats = useMemo(() => {
    return {
      total: processedData.length,
      purchasing: processedData.filter(i => String(i.supplier || '').includes('1.') || String(i.supplier || '').includes('2.')).length,
      contracts: processedData.filter(i => String(i.supplier || '').includes('3.')).length,
      transit: processedData.filter(i => String(i.supplier || '').includes('4.')).length,
      warehouse: processedData.filter(i => String(i.supplier || '') === 'На складе' || String(i.supplier || '').includes('склад') || String(i.note || '').includes('на складе')).length,
      critical: processedData.filter(i => (i.daysInWork as number) > 60).length
    };
  }, [processedData]);

  // Топ проблемных (самые старые незавершенные)
  const criticalItems = useMemo(() => {
      return [...processedData]
        .filter(i => !String(i.supplier || '').includes('COMPLETE') && !String(i.supplier || '').includes('На складе') && !String(i.supplier || '').includes('0. Дополнительное') && (i.daysInWork as number) > 0)
        .sort((a,b) => (b.daysInWork as number) - (a.daysInWork as number))
        .slice(0, 3);
  }, [processedData]);

  // Фильтрация
  const filteredData = useMemo(() => {
    return processedData.filter(item => {
      const searchStr = searchQuery.toLowerCase();
      const searchMatch = String(item.material || '').toLowerCase().includes(searchStr) || 
                          String(item.id || '').toLowerCase().includes(searchStr) ||
                          String(item.title || '').toLowerCase().includes(searchStr);
      
      let tabMatch = true;
      const supplierStr = String(item.supplier || '');
      if (activeTab === '1') tabMatch = supplierStr.includes('1.');
      if (activeTab === '2') tabMatch = supplierStr.includes('2.');
      if (activeTab === '3') tabMatch = supplierStr.includes('3.');
      if (activeTab === '4') tabMatch = supplierStr.includes('4.');
      if (activeTab === 'STORE') tabMatch = supplierStr === 'На складе' || supplierStr.includes('склад') || String(item.note || '').includes('на складе');
      if (activeTab === 'CRITICAL') tabMatch = (item.daysInWork as number) > 60;

      return searchMatch && tabMatch;
    });
  }, [searchQuery, activeTab, processedData]);

  // Сортировка
  const sortedData = useMemo(() => {
      return [...filteredData].sort((a, b) => {
          const dateA = parseDate(a.date).getTime();
          const dateB = parseDate(b.date).getTime();
          return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
      });
  }, [filteredData, sortOrder]);

  // Пагинация
  const totalPages = Math.ceil(sortedData.length / itemsPerPage);
  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage]);

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      document.querySelector('main')?.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const getRowStyle = (days: number) => {
      if (days > 90) return 'bg-rose-50 border-l-4 border-l-rose-500';
      if (days > 45) return 'bg-amber-50 border-l-4 border-l-amber-500';
      return 'hover:bg-blue-50/30 border-l-4 border-l-transparent';
  };

  const exportToPDF = () => {
    const doc = new jsPDF('l', 'mm', 'a4'); // Landscape orientation
    
    // Add title
    doc.setFontSize(16);
    doc.text('Реестр снабжения', 14, 15);
    doc.setFontSize(10);
    doc.text(`Дата актуальности: ${DATA_DATE}`, 14, 22);

    // Define table columns and rows
    const tableColumn = [
      "Заявка", "Дата", "Материал", "Ед.", "Кол-во", 
      "Ответственный", "Статус", "Поставщик", "План поставки", "Дней", "Титул"
    ];

    const tableRows = filteredData.map(item => [
      item.id,
      item.date,
      item.material,
      item.unit,
      item.qty,
      item.responsible,
      item.status,
      item.supplier,
      item.deliveryDate,
      item.daysInWork,
      item.title
    ]);

    // Generate table
    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 30,
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [15, 23, 42], textColor: 255, fontStyle: 'bold' }, // Slate-900
      alternateRowStyles: { fillColor: [248, 250, 252] }, // Slate-50
    });

    // Save PDF
    doc.save(`supply_registry_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      
      {/* ЗАГОЛОВОК И АКТУАЛЬНОСТЬ */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-4 mb-2">
          <div>
             <h2 className="text-2xl font-black text-slate-800">Реестр снабжения</h2>
             <p className="text-xs text-slate-500 font-bold mt-1 uppercase tracking-widest flex items-center">
                <Calendar size={14} className="mr-2 text-blue-500"/>
                Актуальность данных: <span className="text-slate-800 ml-1">{DATA_DATE}</span>
             </p>
          </div>
          <div className="flex gap-2">
             <button 
                onClick={exportToPDF}
                className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white border border-slate-900 rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors shadow-sm"
             >
                <Download size={14}/>
                Скачать PDF
             </button>
             <button 
                onClick={() => setShowHistory(!showHistory)}
                className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-bold transition-colors shadow-sm ${
                  showHistory 
                    ? 'bg-blue-50 border-blue-200 text-blue-600' 
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
             >
                <History size={14}/>
                История загрузок
             </button>
             <button 
                onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors shadow-sm"
             >
                <ArrowUpDown size={14}/>
                {sortOrder === 'asc' ? 'Сначала ранние (Старые)' : 'Сначала поздние (Новые)'}
             </button>
          </div>
      </div>

      {/* ИСТОРИЯ ЗАГРУЗОК */}
      {showHistory && (
        <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm animate-in slide-in-from-top-4 duration-300">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
            <History size={16} className="text-blue-500"/>
            История обновлений реестра
          </h3>
          
          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
            {auditLogs.filter(log => log.module === 'SUPPLY').length === 0 ? (
              <p className="text-xs text-slate-400 italic text-center py-4">История загрузок пуста</p>
            ) : (
              auditLogs
                .filter(log => log.module === 'SUPPLY')
                .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                .map((log) => (
                  <div key={log.id} className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100 hover:bg-blue-50/50 transition-colors group">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      log.status === 'SUCCESS' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
                    }`}>
                      {log.status === 'SUCCESS' ? <FileText size={14} /> : <AlertCircle size={14} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <p className="text-xs font-bold text-slate-700 truncate">{log.fileName}</p>
                        <span className="text-[10px] text-slate-400 whitespace-nowrap ml-2">
                          {new Date(log.timestamp).toLocaleString('ru-RU')}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        {log.action} • {log.details}
                      </p>
                      <p className="text-[9px] text-slate-400 mt-1 flex items-center gap-1">
                        <User size={10} /> {log.user}
                      </p>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>
      )}

      {/* АНАЛИЗ ЗАДЕРЖЕК */}
      {criticalItems.length > 0 && (
          <div className="bg-white rounded-[2rem] border border-rose-100 shadow-lg shadow-rose-100/50 p-6 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-2 h-full bg-rose-500"></div>
              <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-rose-100 text-rose-600 rounded-lg">
                      <AlertTriangle size={24}/>
                  </div>
                  <div>
                      <h3 className="font-black text-slate-800 text-lg leading-none">Топ проблемных позиций</h3>
                      <p className="text-xs text-slate-500 font-medium mt-1">Требуют немедленного внимания ({'>'} 45 дней)</p>
                  </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {criticalItems.map((item, idx) => (
                      <div key={idx} className="bg-rose-50/50 rounded-xl p-4 border border-rose-100 flex flex-col justify-between">
                          <div>
                              <div className="flex justify-between items-start mb-2">
                                  <span className="text-[10px] font-black bg-white border border-rose-200 px-2 py-1 rounded text-rose-600">{item.id}</span>
                                  <span className="text-xs font-bold text-slate-400">{item.date}</span>
                              </div>
                              <p className="font-bold text-slate-800 text-sm line-clamp-2 leading-tight mb-2" title={item.material}>{item.material}</p>
                              <p className="text-[10px] text-slate-500 truncate">{item.responsible}</p>
                          </div>
                          <div className="mt-3 pt-3 border-t border-rose-100 flex items-center justify-between">
                              <span className="text-[10px] font-bold text-slate-400 uppercase">В работе</span>
                              <span className="text-lg font-black text-rose-600 flex items-center gap-1">
                                  <Timer size={16}/> {item.daysInWork} дн.
                              </span>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      )}

      {/* СВОДНЫЕ КАРТОЧКИ */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <StatItem icon={<ClipboardList size={20}/>} label="Всего заявок" value={stats.total} color="slate" />
        <StatItem icon={<Search size={20}/>} label="Тендеры / КП" value={stats.purchasing} color="amber" />
        <StatItem icon={<FileText size={20}/>} label="Договор / Аванс" value={stats.contracts} color="blue" />
        <StatItem icon={<Truck size={20}/>} label="Товар в пути" value={stats.transit} color="indigo" />
        <StatItem icon={<AlertCircle size={20}/>} label="Критично (>60 дн)" value={stats.critical} color="rose" />
      </div>

      {/* ПАНЕЛЬ УПРАВЛЕНИЯ */}
      <div className="bg-white p-5 rounded-[2.5rem] border border-slate-200 shadow-sm flex flex-col lg:flex-row items-center justify-between gap-6">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'ALL', label: 'Все данные' },
            { id: 'CRITICAL', label: '❗ Критичные' },
            { id: '1', label: '1. Сбор КП' },
            { id: '2', label: '2. Протокол' },
            { id: '3', label: '3. Договор' },
            { id: '4', label: '4. Поставка' },
            { id: 'STORE', label: 'Склад ПГУ' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id as any); setCurrentPage(1); }}
              className={`px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === tab.id 
                  ? (tab.id === 'CRITICAL' ? 'bg-rose-600 text-white shadow-xl scale-105' : 'bg-slate-900 text-white shadow-xl scale-105') 
                  : 'bg-slate-50 text-slate-500 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative flex-1 lg:min-w-[400px]">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <input 
            type="text" 
            placeholder="Поиск по материалу, ERP или Титулу..." 
            value={searchQuery}
            onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
            className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all shadow-inner"
          />
        </div>
      </div>

      {/* РЕЕСТР (ТАБЛИЦА) */}
      <div className="bg-white rounded-[3rem] border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[800px]">
        <div className="overflow-auto custom-scrollbar flex-1">
          <table className="w-full text-left border-collapse min-w-[2000px]">
            <thead className="sticky top-0 z-10 bg-slate-900 shadow-md">
              <tr className="text-[10px] font-black uppercase text-slate-400 tracking-[0.15em] border-b border-slate-800">
                <th className="px-8 py-6 w-48 bg-slate-900 sticky left-0 z-20 shadow-[4px_0_12px_-4px_rgba(0,0,0,0.3)]">Заявка / Дата</th>
                <th className="px-6 py-6 min-w-[350px]">Материал</th>
                <th className="px-4 py-6 text-center">Ед.</th>
                <th className="px-6 py-6 text-center w-24">Кол-во</th>
                <th className="px-6 py-6">Примечание</th>
                <th className="px-6 py-6">Статус</th>
                <th className="px-6 py-6">Этап</th>
                <th className="px-6 py-6">Поставщик и Комментарии</th>
                <th className="px-6 py-6 text-center">План поставки</th>
                <th className="px-4 py-6 text-center">Дней в работе</th>
                <th className="px-6 py-6">Ответственный</th>
                <th className="px-6 py-6">Титул (Объект)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedData.length === 0 ? (
                <tr>
                  <td colSpan={12} className="px-8 py-12 text-center text-slate-400 italic">
                    Данные не найдены
                  </td>
                </tr>
              ) : (
                paginatedData.map((item, idx) => (
                  <tr key={idx} className={`${getRowStyle(item.daysInWork as number)} transition-all group hover:bg-slate-50`}>
                    <td className="px-8 py-5 bg-white group-hover:bg-slate-50 sticky left-0 z-10 shadow-[4px_0_12px_-4px_rgba(0,0,0,0.05)] border-r border-slate-100">
                      <div className="flex flex-col">
                        <span className="text-[11px] font-black text-slate-900 mb-1.5">{item.id}</span>
                        <span className="text-[10px] font-bold text-slate-400 flex items-center">
                          <Calendar size={12} className="mr-1.5" /> {item.date}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-5">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 rounded-2xl bg-white border border-blue-100 text-blue-600 flex items-center justify-center shrink-0 shadow-sm">
                          {item.supplier === 'На складе' || item.supplier?.includes('склад') ? <Warehouse size={18} /> : <Package size={18} />}
                        </div>
                        <p className="text-[12px] font-black text-slate-800 leading-tight">{item.material}</p>
                      </div>
                    </td>
                    <td className="px-4 py-5 text-center text-[10px] font-black text-slate-400 uppercase">{item.unit}</td>
                    <td className="px-6 py-5 text-center">
                      <span className="inline-flex px-3 py-1.5 bg-slate-100 rounded-xl text-[11px] font-black text-slate-800 border border-slate-200">
                        {typeof item.qty === 'number' ? item.qty.toLocaleString() : item.qty}
                      </span>
                    </td>
                    <td className="px-6 py-5">
                      <p className="text-[10px] text-slate-500 font-medium italic truncate max-w-[200px]">{item.note}</p>
                    </td>
                    <td className="px-6 py-5">
                      <span className="text-[10px] font-black text-slate-500 uppercase">{item.status}</span>
                    </td>
                    <td className="px-6 py-5">
                      <StatusBadge status={item.supplier} />
                    </td>
                    <td className="px-6 py-5">
                      <p className="text-[10px] text-slate-600 leading-relaxed line-clamp-3 max-w-[300px] whitespace-pre-wrap">{item.comment}</p>
                    </td>
                    <td className="px-6 py-5 text-center">
                      <div className={`text-[11px] font-black px-3 py-1 rounded-lg ${
                        !item.deliveryDate || item.deliveryDate === '—' ? 'text-slate-400' : 'text-emerald-700 bg-emerald-50 border border-emerald-100'
                      }`}>
                        {item.deliveryDate || '—'}
                      </div>
                    </td>
                    <td className="px-4 py-5 text-center">
                      <span className={`text-[12px] font-black ${(item.daysInWork as number) > 60 ? 'text-rose-600' : (item.daysInWork as number) > 30 ? 'text-amber-600' : 'text-slate-400'}`}>
                        {item.daysInWork}
                      </span>
                    </td>
                    <td className="px-6 py-5">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 shadow-sm">
                          <User size={16} />
                        </div>
                        <span className="text-[11px] font-black text-slate-700">{item.responsible}</span>
                      </div>
                    </td>
                    <td className="px-6 py-5">
                      <span className="text-[9px] font-black text-blue-600 bg-blue-100/50 px-2 py-1 rounded-lg uppercase border border-blue-100">
                        {item.title}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ПАГИНАЦИЯ */}
      {totalPages > 1 && (
        <div className="flex flex-col sm:flex-row items-center justify-between bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm gap-4">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
            Показано {(currentPage - 1) * itemsPerPage + 1} - {Math.min(currentPage * itemsPerPage, sortedData.length)} из {sortedData.length} позиций
          </p>
          
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className={`p-3 rounded-xl border transition-all ${currentPage === 1 ? 'text-slate-200 border-slate-50 cursor-not-allowed' : 'text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-blue-600'}`}
            >
              <ChevronLeft size={20} />
            </button>
            
            <div className="flex items-center space-x-1 px-2 overflow-x-auto max-w-[300px] no-scrollbar">
              {generatePageNumbers(currentPage, totalPages).map((page, i) => (
                page === '...' ? (
                  <span key={i} className="px-3 text-slate-300"><MoreHorizontal size={14} /></span>
                ) : (
                  <button
                    key={i}
                    onClick={() => handlePageChange(Number(page))}
                    className={`w-10 h-10 rounded-xl text-xs font-black transition-all shrink-0 ${
                      currentPage === page 
                        ? 'bg-slate-900 text-white shadow-xl scale-110' 
                        : 'bg-white text-slate-400 hover:bg-slate-50 border border-slate-100'
                    }`}
                  >
                    {page}
                  </button>
                )
              ))}
            </div>

            <button 
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className={`p-3 rounded-xl border transition-all ${currentPage === totalPages ? 'text-slate-200 border-slate-50 cursor-not-allowed' : 'text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-blue-600'}`}
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Вспомогательная функция для генерации номеров страниц
const generatePageNumbers = (current: number, total: number) => {
  const pages = [];
  const delta = 2;
  for (let i = 1; i <= total; i++) {
    if (i === 1 || i === total || (i >= current - delta && i <= current + delta)) {
      pages.push(i);
    } else if (pages[pages.length - 1] !== '...') {
      pages.push('...');
    }
  }
  return pages;
};

const StatItem: React.FC<{ icon: React.ReactNode; label: string; value: number | string; color: 'slate' | 'amber' | 'blue' | 'indigo' | 'emerald' | 'rose' }> = ({ icon, label, value, color }) => {
  const themes = {
    slate: 'bg-white border-slate-200 text-slate-900',
    amber: 'bg-white border-amber-200 text-amber-600',
    blue: 'bg-white border-blue-200 text-blue-600',
    indigo: 'bg-white border-indigo-200 text-indigo-600',
    emerald: 'bg-emerald-50 border-emerald-200 text-emerald-700',
    rose: 'bg-rose-50 border-rose-200 text-rose-700'
  };

  return (
    <div className={`p-6 rounded-[2.5rem] border shadow-sm flex flex-col justify-between h-36 transition-all hover:shadow-lg ${themes[color]}`}>
      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-500 shadow-inner border border-slate-100">
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-[0.1em] text-slate-400 mb-1.5">{label}</p>
        <p className="text-3xl font-black leading-none tracking-tighter">{value}</p>
      </div>
    </div>
  );
};

const StatusBadge: React.FC<{ status: any }> = ({ status }) => {
  const statStr = String(status || '—');
  let style = "bg-slate-100 text-slate-600 border-slate-200";
  if (statStr.includes('1.')) style = "bg-amber-50 text-amber-700 border-amber-100";
  if (statStr.includes('2.')) style = "bg-orange-50 text-orange-700 border-orange-100";
  if (statStr.includes('3.')) style = "bg-blue-50 text-blue-700 border-blue-100";
  if (statStr.includes('4.')) style = "bg-indigo-50 text-indigo-700 border-indigo-100";
  if (statStr === 'На складе' || statStr.includes('склад') || statStr.includes('COMPLETE') || statStr.includes('5.') || statStr.includes('6.') || statStr.includes('0. Дополнительное')) style = "bg-emerald-50 text-emerald-700 border-emerald-100";

  return (
    <span className={`inline-flex items-center px-2.5 py-1.5 rounded-xl border text-[9px] font-black uppercase tracking-wider ${style}`}>
      <div className={`w-1.5 h-1.5 rounded-full mr-1.5 ${
        statStr.includes('1') ? 'bg-amber-400' : 
        statStr.includes('2') ? 'bg-orange-400' : 
        statStr.includes('3') ? 'bg-blue-400' : 
        statStr.includes('4') ? 'bg-indigo-400' : 
        statStr === '—' ? 'bg-slate-300' :
        'bg-emerald-400'
      }`} />
      {statStr === '—' ? 'Нет данных' : statStr}
    </span>
  );
};

export default SupplyRegistry;
