
import React from 'react';
import { AuditLog } from '../types';
import { Shield, Users, Settings, Database, History, UserPlus } from 'lucide-react';

interface AdminPanelProps {
  logs: AuditLog[];
}

const AdminStatCard: React.FC<{ icon: React.ReactNode; label: string; value: string; color: string }> = ({ icon, label, value, color }) => {
  const colors: any = {
    blue: 'bg-blue-50 text-blue-600',
    emerald: 'bg-emerald-50 text-emerald-600',
    indigo: 'bg-indigo-50 text-indigo-600',
    slate: 'bg-slate-50 text-slate-600'
  };
  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center space-x-4">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colors[color]}`}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">{label}</p>
        <p className="text-lg font-black text-slate-800">{value}</p>
      </div>
    </div>
  );
};

const AdminAction: React.FC<{ title: string; description: string }> = ({ title, description }) => (
  <button className="w-full text-left p-3 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50 transition-all group">
    <p className="text-sm font-bold text-slate-800 group-hover:text-blue-700">{title}</p>
    <p className="text-[10px] text-slate-500">{description}</p>
  </button>
);

const AdminPanel: React.FC<AdminPanelProps> = ({ logs }) => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <AdminStatCard icon={<Users size={20} />} label="Пользователей" value="12" color="blue" />
        <AdminStatCard icon={<Shield size={20} />} label="Активных сессий" value="3" color="emerald" />
        <AdminStatCard icon={<Database size={20} />} label="Объем данных" value="256 MB" color="indigo" />
        <AdminStatCard icon={<Settings size={20} />} label="Версия ядра" value="v2.4.0" color="slate" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-800 flex items-center">
              <History size={18} className="mr-2 text-slate-400" />
              Лог входов пользователей
            </h3>
            <button className="text-[10px] font-bold text-blue-600 uppercase hover:underline">Экспорт CSV</button>
          </div>
          <div className="flex-1 overflow-y-auto max-h-[400px] custom-scrollbar">
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase z-10">
                <tr>
                  <th className="px-6 py-4">Пользователь</th>
                  <th className="px-6 py-4">Роль</th>
                  <th className="px-6 py-4">Время</th>
                  <th className="px-6 py-4">Действие</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {logs.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-10 text-center text-slate-400 italic">Событий не зафиксировано</td>
                  </tr>
                ) : (
                  logs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/50">
                      <td className="px-6 py-4 font-bold text-slate-800">{log.user}</td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-bold uppercase text-[9px]">
                          {log.role}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-500">{log.timestamp}</td>
                      <td className="px-6 py-4 text-blue-600 font-medium">{log.action}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-6 flex items-center">
            <UserPlus size={18} className="mr-2 text-slate-400" />
            Управление системой
          </h3>
          <div className="space-y-4">
            <AdminAction title="Редактировать разделы" description="Изменение пунктов меню и их названий" />
            <AdminAction title="Логика фильтров" description="Настройка глобальных и модульных фильтров" />
            <AdminAction title="Права доступа" description="Управление ролями и матрицей доступа" />
            <AdminAction title="База данных" description="Оптимизация и резервное копирование" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
