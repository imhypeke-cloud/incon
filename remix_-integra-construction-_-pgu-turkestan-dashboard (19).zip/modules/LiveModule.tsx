
import React from 'react';
import { Camera, Lock, Video } from 'lucide-react';

const LiveModule: React.FC = () => {
  const cameras = [
    { id: 1, name: 'Камера 01: Площадка ПГУ', status: 'Online', type: 'PTZ' },
    { id: 2, name: 'Камера 02: Фундаменты ГТУ №1', status: 'Online', type: 'Fixed' },
    { id: 3, name: 'Камера 03: Машзал / КРУЭ', status: 'Online', type: 'PTZ' },
    { id: 4, name: 'Камера 04: Въезд / КПП', status: 'Maintenance', type: 'Dome' },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-center space-x-3">
        <Lock className="text-amber-600" size={20} />
        <p className="text-xs font-bold text-amber-800">
          Внимание: Прямая трансляция доступна только для авторизованных пользователей. 
          Запись архива хранится 30 дней. Модуль работает только в режиме просмотра.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {cameras.map((cam) => (
          <div key={cam.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col group">
            <div className="aspect-video bg-slate-900 relative flex items-center justify-center group-hover:bg-slate-800 transition-colors">
              <Video className="text-slate-700 group-hover:text-blue-500/50 transition-colors" size={48} />
              <div className="absolute top-4 left-4 px-2 py-1 bg-black/60 backdrop-blur rounded text-[10px] font-bold text-white uppercase tracking-widest flex items-center">
                <span className={`w-1.5 h-1.5 rounded-full mr-2 ${cam.status === 'Online' ? 'bg-green-500 animate-pulse' : 'bg-rose-500'}`}></span>
                {cam.status}
              </div>
              <div className="absolute bottom-4 right-4 flex space-x-2">
                <button className="p-2 bg-white/10 hover:bg-white/20 backdrop-blur rounded text-white"><Camera size={14} /></button>
              </div>
            </div>
            <div className="p-4 flex items-center justify-between bg-slate-50/50">
              <div>
                <h4 className="font-bold text-slate-800 text-sm">{cam.name}</h4>
                <p className="text-[10px] text-slate-400 font-bold uppercase">{cam.type} Camera | IP: 192.168.10.{100 + cam.id}</p>
              </div>
              <button className="text-xs font-bold text-blue-600 hover:underline uppercase">Развернуть</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LiveModule;
