
import React, { useState, useMemo } from 'react';
import { 
  Users, 
  UserCheck, 
  HardHat, 
  Briefcase, 
  Search, 
  Calendar, 
  ChevronDown,
  Building2,
  Stethoscope,
  ShieldCheck,
  Zap,
  Hammer,
  ArrowRight,
  Layout,
  UserPlus
} from 'lucide-react';
import { INITIAL_TITLE_ALLOCATION, INITIAL_HR } from '../constants';

interface HRAllocation {
  id: string;
  title: string;
  itr: number;
  workers: number;
  workType: string;
  subcontractor?: string;
}

interface ManagementStaff {
  position: string;
  qty: number;
  category: 'ADMIN' | 'LINE' | 'WORKERS';
  comment?: string;
}

const HRResources: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  
  // АКТУАЛЬНАЯ ДАТА ИЗ ДОКУМЕНТА
  const reportDate = INITIAL_HR[0]?.lastUpdate || "18.03.2026";

  // ДАННЫЕ ИЗ PDF (Стр. 1): Административный и Линейный состав INTEGRA
  const managementStaff: ManagementStaff[] = [
    { position: 'Исполнительный директор ДПГУ / Deputy Director', qty: 1, category: 'ADMIN' },
    { position: 'Технический директор / Technical Director', qty: 1, category: 'ADMIN' },
    { position: 'Начальник управления по строительству / Managing Director', qty: 1, category: 'ADMIN' },
    { position: 'Заместитель Исполнительного директора по строительству', qty: 1, category: 'ADMIN' },
    { position: 'Руководитель проекта / Project Manager', qty: 4, category: 'ADMIN' },
    { position: 'Инженер ОТ и ТБ, Эколог HSE Engineer, Environmental Engineer', qty: 14, category: 'ADMIN', comment: 'Из них эколог - 2 чел.' },
    { position: 'Начальник ОПП/ Ведущий инженер ОПП, Инженер ОПП', qty: 6, category: 'ADMIN' },
    { position: 'Начальник ОКК, Инженер ОКК', qty: 10, category: 'ADMIN' },
    { position: 'Менеджер по управлению отчетности', qty: 2, category: 'ADMIN' },
    { position: 'Специалист по учету персонала', qty: 5, category: 'ADMIN' },
    { position: 'Заведующий складом, кладовщик / Warehouse Manager, Storekeeper', qty: 9, category: 'ADMIN' },
    { position: 'Фельдшер Paramedic', qty: 3, category: 'ADMIN' },
    { position: 'Специалист АХО Facility Management Specialist', qty: 3, category: 'ADMIN' },
    { position: 'Отдел снабжения / Supply Department', qty: 2, category: 'ADMIN' },
    { position: 'Служба безопасности (СБ) / Security Service (SS)', qty: 2, category: 'ADMIN' },
    { position: 'Главный геодезист, Инженер Геодезист / Chief Surveyor, Survey Engineer', qty: 24, category: 'LINE' },
    { position: 'Начальник участка Site Manager', qty: 8, category: 'LINE' },
    { position: 'Отдел главного энергетика Chief Electrical Engineer', qty: 8, category: 'LINE' },
    { position: 'Прораб / Foreman', qty: 14, category: 'LINE' },
    { position: 'Механик( малая механизация) / Mechanic', qty: 2, category: 'LINE' },
    { position: 'Мастер / Supervisor', qty: 1, category: 'LINE' },
    { position: 'Электромонтажники и Сантехники Electricians and Plumbers', qty: 10, category: 'WORKERS' },
    { position: 'Рабочие / Labors', qty: 28, category: 'WORKERS', comment: '3 чел - пожарная служба, 7 чел. на складе, 12 чел на площадке, 4 чел. пом. геодезиста. 2 чел пом. менед. отч.' },
  ];

  const titleAllocation: HRAllocation[] = INITIAL_TITLE_ALLOCATION;

  // ИТОГОВЫЕ ПОКАЗАТЕЛИ
  const totals = useMemo(() => {
    const totalRow = INITIAL_HR.find(item => item.subcontractor === 'ИТОГО');
    if (totalRow) {
      return {
        itr: totalRow.itr,
        workers: totalRow.workers,
        total: totalRow.total
      };
    }
    return {
      itr: titleAllocation.reduce((acc, curr) => acc + curr.itr, 0),
      workers: titleAllocation.reduce((acc, curr) => acc + curr.workers, 0),
      total: titleAllocation.reduce((acc, curr) => acc + curr.itr + curr.workers, 0),
    };
  }, [titleAllocation]);

  const filteredTitles = useMemo(() => {
    return titleAllocation.filter(t => 
      t.title?.toLowerCase().includes(searchQuery.toLowerCase()) || 
      t.workType?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.subcontractor?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      
      {/* HEADER BLOCK */}
      <div className="bg-white p-4 rounded-[1.75rem] border border-slate-200 shadow-sm flex items-center space-x-4">
        <div className="w-12 h-12 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-100">
          <Users size={24} />
        </div>
        <div className="text-left">
          <h2 className="text-lg font-black text-slate-800 uppercase tracking-tight leading-none">Расстановка HR</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5 flex items-center">
            <Calendar size={12} className="mr-1.5" /> Актуальность на: {reportDate}
          </p>
        </div>
      </div>

      {/* СВОДНЫЕ ПОКАЗАТЕЛИ (HERO SECTION) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-slate-900 rounded-[2.5rem] p-7 text-white shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl group-hover:scale-150 transition-transform duration-700" />
          <div className="relative z-10 text-left">
             <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-3">ИТОГО на площадке</p>
             <div className="flex items-baseline space-x-3">
               <span className="text-5xl font-black tracking-tighter">{totals.total}</span>
               <span className="text-blue-400 font-bold uppercase text-[10px]">чел. суммарно</span>
             </div>
          </div>
        </div>

        <div className="bg-white rounded-[2.5rem] p-7 border border-slate-100 shadow-sm flex flex-col justify-between hover:shadow-xl transition-all group">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <Briefcase size={24} />
            </div>
            <span className="text-[11px] font-black text-slate-300 uppercase tracking-widest leading-none">Management & Eng.</span>
          </div>
          <div className="text-left">
            <p className="text-3xl font-black text-slate-900 tracking-tight">{totals.itr}</p>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">ИТР (Integra + Sub)</p>
          </div>
        </div>

        <div className="bg-white rounded-[2.5rem] p-7 border border-slate-100 shadow-sm flex flex-col justify-between hover:shadow-xl transition-all group">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <HardHat size={24} />
            </div>
            <span className="text-[11px] font-black text-slate-300 uppercase tracking-widest leading-none">Labors & Operators</span>
          </div>
          <div className="text-left">
            <p className="text-3xl font-black text-slate-900 tracking-tight">{totals.workers}</p>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Рабочий персонал</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* АДМИНИСТРАТИВНОЕ УПРАВЛЕНИЕ (ПОЗИЦИИ) */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm h-full">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight mb-6 flex items-center">
              <Building2 className="mr-2 text-indigo-500" size={18} />
              ИТР Состав (INTEGRA)
            </h3>
            <div className="space-y-2.5 max-h-[1000px] overflow-y-auto custom-scrollbar pr-2">
              {managementStaff.map((staff, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-slate-50/50 rounded-xl border border-slate-100 group hover:bg-white hover:border-blue-200 transition-all">
                  <div className="flex-1 text-left">
                    <p className="text-[11px] font-bold text-slate-700 leading-tight">{staff.position}</p>
                    {staff.comment && <p className="text-[9px] text-slate-400 italic mt-0.5">{staff.comment}</p>}
                  </div>
                  <div className={`px-2.5 py-1 rounded-lg text-xs font-black ${staff.category === 'ADMIN' ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700'}`}>
                    {staff.qty}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* РАССТАНОВКА ПО ТИТУЛАМ (ТАБЛИЦА) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col h-full">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight flex items-center">
                <Layout className="mr-2 text-blue-500" size={18} />
                Распределение по объектам
              </h3>
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Титул, работа или подрядчик..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-xs font-medium outline-none focus:ring-4 focus:ring-blue-500/5 focus:bg-white transition-all w-full sm:w-64"
                />
              </div>
            </div>

            <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-220px)] custom-scrollbar">
              <table className="w-full border-collapse min-w-[600px]">
                <thead className="sticky top-0 z-20 bg-white shadow-sm">
                  <tr className="text-[9px] font-black uppercase text-slate-400 tracking-widest border-b border-slate-100">
                    <th className="px-4 py-3 text-left sticky left-0 bg-white z-30 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)]">Титул / Организация</th>
                    <th className="px-4 py-3 text-center">ИТР</th>
                    <th className="px-4 py-3 text-center">Раб.</th>
                    <th className="px-4 py-3 text-left">Виды работ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTitles.map((title) => (
                    <tr key={title.id} className="hover:bg-blue-50/30 transition-all group">
                      <td className="px-4 py-4 text-left sticky left-0 bg-white z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)] group-hover:bg-blue-50/30">
                        <div className="flex items-center space-x-3">
                           <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                           <div>
                             <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight">{title.title}</p>
                             {title.subcontractor && (
                               <span className="text-[8px] font-black text-indigo-500 bg-indigo-50 px-1.5 py-0.5 rounded mt-1 inline-block uppercase border border-indigo-100">
                                 {title.subcontractor}
                               </span>
                             )}
                           </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className={`text-[11px] font-black ${title.itr > 0 ? 'text-indigo-600' : 'text-slate-300'}`}>{title.itr}</span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className="text-[11px] font-black text-emerald-600">{title.workers}</span>
                      </td>
                      <td className="px-4 py-4 text-left">
                        <p className="text-[10px] font-bold text-slate-500 italic leading-snug max-w-[200px] group-hover:text-slate-700">
                          {title.workType}
                        </p>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {filteredTitles.length === 0 && (
              <div className="py-20 text-center flex flex-col items-center">
                <Users size={32} className="text-slate-200 mb-3" />
                <p className="text-xs font-black text-slate-300 uppercase tracking-widest">Результатов не найдено</p>
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
};

export default HRResources;
