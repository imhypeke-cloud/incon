
import React, { useState, useMemo } from 'react';
import { 
  User, 
  Briefcase, 
  UserCheck, 
  HardHat, 
  Zap, 
  Cog, 
  Calendar, 
  ListTodo, 
  ChevronRight, 
  Search,
  Filter,
  BarChart3,
  Download,
  Info
} from 'lucide-react';

interface ScheduleItem {
  title: string;
  section: string;
  name: string;
  unit: string;
  qty: number | string;
  rdDate: string;
  start: string;
  finish: string;
  duration: number | string;
}

const ProjectManagers: React.FC = () => {
  const [viewMode, setViewMode] = useState<'cards' | 'schedule'>('cards');
  const [selectedManagerId, setSelectedManagerId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const sections = [
    {
      id: '1',
      manager: 'Попивнухин Николай Владимирович',
      titles: ['1.1', '1.2', '1.3', '4', '5', '6', '23.3', '34'],
      color: 'border-amber-200 bg-amber-50',
      accent: 'amber'
    },
    {
      id: '2',
      manager: 'Махмудов Юнус Смихан-Оглы',
      titles: ['24', '38', '39', '42', '43', '44', '46', '47.1', '48', '49', '23.4', '45.1', '45.2', '47.1', '47.2', '47.3', '8.2', '12.1', '12.2-12.3', '47.3', '8.1'],
      color: 'border-blue-200 bg-blue-50',
      accent: 'blue'
    },
    {
      id: '3',
      manager: 'Алдамуратов Рахматулла Изатуллаевич',
      titles: ['2.2', '2.1', '3', '7.1', '7.2', '9', '10', '11', '13.4', '13.2-13.3', '38', '19', '32', '33.1-33.6', '35.1', '36', '37', '16', '18', '23.7', '22.1.6', '31', '15.2-15.3', '15.4-15.5', '20.1-20.3', '21', '23.5', '28', '27', '29', '35', '41', '50 кж-7'],
      color: 'border-emerald-200 bg-emerald-50',
      accent: 'emerald'
    },
    {
      id: '4',
      manager: 'Руководитель проекта – Вакансия',
      siteChief: 'Абилькасимов Болат Жарылкасымович',
      titles: ['25', '30', '41'],
      color: 'border-slate-200 bg-slate-50',
      accent: 'slate'
    }
  ];

  const scheduleData: ScheduleItem[] = [
    { title: '1.1', section: 'КЖ', name: 'Конструкции железобетонные КЖ1-21', unit: 'м3', qty: 10796.55, rdDate: '30.05.2025', start: '01.08.2025', finish: '27.07.2026', duration: 360 },
    { title: '1.1', section: 'КМ', name: 'Конструкции металлические КМ1-КМ8', unit: 'тн', qty: 11805.9, rdDate: '25.07.2025', start: '01.08.2025', finish: '25.10.2026', duration: 450 },
    { title: '1.1', section: 'ТХ', name: 'КУ#11 (Комплектная установка)', unit: 'компл', qty: 1, rdDate: '05.11.2025', start: '01.12.2025', finish: '26.12.2026', duration: 390 },
    { title: '1.2', section: 'КЖ', name: 'Железобетонные конструкции', unit: 'м3', qty: 9312.3, rdDate: '01.07.2024', start: '01.08.2025', finish: '29.12.2025', duration: 150 },
    { title: '25', section: 'КЖ', name: 'Адм-хозяйственное здание', unit: 'м3', qty: 13544.03, rdDate: '07.05.2025', start: '01.08.2025', finish: '27.02.2026', duration: 210 },
    { title: '43', section: 'КЖ', name: 'ОРУ-220 кВ - КЖ', unit: 'м3', qty: 4236.26, rdDate: '13.05.2025', start: '01.08.2025', finish: '30.10.2025', duration: 90 },
    { title: '44', section: 'КЖ', name: 'ОРУ-500 кВ - КЖ', unit: 'м3', qty: 3493.5, rdDate: '13.05.2025', start: '20.10.2025', finish: '29.11.2025', duration: 40 },
    { title: '50', section: 'КМ', name: 'Трубопроводные эстакады', unit: 'тн', qty: '—', rdDate: '25.08.2025', start: '01.12.2025', finish: '27.09.2026', duration: 300 },
  ];

  const globalRoles = [
    { name: 'Тлеулесов Каржаубай Куандыкович', dept: 'Отдел оборудования, механики и трубопровода', icon: Cog },
    { name: 'Рахматулла Айбек', dept: 'Отдел по электрике и КИПиА', icon: Zap }
  ];

  const filteredSchedule = useMemo(() => {
    return scheduleData.filter(item => {
      const managerMatch = !selectedManagerId || sections.find(s => s.id === selectedManagerId)?.titles.includes(item.title);
      const searchMatch = !searchQuery || 
        item.title?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        item.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.section?.toLowerCase().includes(searchQuery.toLowerCase());
      return managerMatch && searchMatch;
    });
  }, [scheduleData, selectedManagerId, searchQuery, sections]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-white p-4 rounded-[2rem] border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-1 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
          <button 
            onClick={() => setViewMode('cards')}
            className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${viewMode === 'cards' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Оргструктура
          </button>
          <button 
            onClick={() => setViewMode('schedule')}
            className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${viewMode === 'schedule' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            График СМР
          </button>
        </div>

        <div className="flex items-center space-x-4 flex-1 justify-end">
          <div className="hidden lg:flex items-center bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-xl flex-1 max-w-sm">
            <Search size={14} className="text-slate-400 mr-3" />
            <input 
              type="text" 
              placeholder="Поиск по титулу или названию работ..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent border-none text-[11px] font-bold outline-none w-full" 
            />
          </div>
          <button className="p-3 bg-slate-900 text-white rounded-xl hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/10">
            <Download size={18} />
          </button>
        </div>
      </div>

      {viewMode === 'cards' ? (
        <>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {sections.map((section) => (
              <div key={section.id} className={`rounded-[2.5rem] border p-8 shadow-sm transition-all hover:shadow-md ${section.color}`}>
                <div className="flex items-start justify-between mb-8">
                  <div className="flex items-center space-x-5">
                    <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-sm border border-slate-100 font-black text-slate-800 text-xl">
                      {section.id}
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1.5">Участок №{section.id}</p>
                      <h3 className="font-black text-slate-800 text-xl leading-tight">{section.manager}</h3>
                      {section.siteChief && (
                        <p className="text-xs font-bold text-slate-500 mt-2 flex items-center bg-white/40 w-fit px-2 py-1 rounded-lg">
                          <HardHat size={14} className="mr-2 text-slate-400" /> Нач. участка: {section.siteChief}
                        </p>
                      )}
                    </div>
                  </div>
                  <button 
                    onClick={() => { setSelectedManagerId(section.id); setViewMode('schedule'); }}
                    className="p-3 bg-white hover:bg-slate-900 hover:text-white rounded-2xl shadow-sm border border-slate-100 transition-all text-slate-400"
                  >
                    <ChevronRight size={20} />
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {section.titles.map((title) => (
                    <div key={title} className="px-3 py-1.5 bg-white/60 backdrop-blur-sm border border-slate-200 rounded-xl text-[10px] font-black text-slate-700 shadow-sm hover:border-blue-400 hover:scale-105 transition-all cursor-default group">
                      {title}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="bg-slate-900 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-10">
                <h3 className="text-2xl font-black uppercase tracking-tighter flex items-center">
                  <UserCheck className="mr-4 text-blue-400" size={28} />
                  Сквозные функции управления
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {globalRoles.map((role) => (
                  <div key={role.name} className="flex items-center space-x-8 p-8 bg-white/5 border border-white/10 rounded-[2.5rem] hover:bg-white/10 transition-all group">
                    <div className="w-20 h-20 rounded-3xl bg-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                      <role.icon size={40} />
                    </div>
                    <div>
                      <h4 className="text-xl font-black leading-tight group-hover:text-blue-300 transition-colors">{role.name}</h4>
                      <div className="h-0.5 w-12 bg-blue-500/30 my-3"></div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{role.dept}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl overflow-hidden animate-in slide-in-from-bottom-4 duration-500">
          <div className="p-8 border-b border-slate-100 flex flex-wrap items-center justify-between gap-6 bg-slate-50/30">
            <div className="flex items-center space-x-4">
              <div className="p-3.5 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-500/20">
                <ListTodo size={24} />
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Матрица Графика СМР</h3>
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em] mt-1">Детализация по разделам, объемам и срокам</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <select 
                value={selectedManagerId || ''}
                onChange={(e) => setSelectedManagerId(e.target.value || null)}
                className="text-[11px] font-black bg-white border border-slate-200 rounded-xl px-5 py-3 outline-none focus:ring-4 focus:ring-blue-500/10 transition-all shadow-sm min-w-[240px]"
              >
                <option value="">Все участки / РП</option>
                {sections.map(s => <option key={s.id} value={s.id}>{s.manager}</option>)}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-left border-collapse min-w-[1400px]">
              <thead>
                <tr className="bg-slate-900 border-b border-slate-800 text-[9px] font-black uppercase text-slate-400 tracking-widest">
                  <th className="px-6 py-5 text-center w-20">Титул</th>
                  <th className="px-4 py-5 w-24">Раздел</th>
                  <th className="px-6 py-5 min-w-[320px]">Наименование пакета работ</th>
                  <th className="px-4 py-5 text-center w-24">Ед. изм.</th>
                  <th className="px-4 py-5 text-center w-32">Объем</th>
                  <th className="px-4 py-5 text-center">Выдача РД</th>
                  <th className="px-4 py-5 text-center bg-blue-600/10 text-blue-400 border-x border-slate-800">Старт</th>
                  <th className="px-4 py-5 text-center bg-blue-600/10 text-blue-400 border-x border-slate-800">Финиш</th>
                  <th className="px-6 py-5 text-center">Длит. (дни)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredSchedule.length > 0 ? filteredSchedule.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80 transition-all group">
                    <td className="px-6 py-5 text-center">
                      <span className="inline-flex px-2.5 py-1.5 bg-slate-100 border border-slate-200 text-slate-800 rounded-xl text-[11px] font-black shadow-sm">
                        {item.title}
                      </span>
                    </td>
                    <td className="px-4 py-5 font-black text-slate-400 text-xs tracking-tighter">{item.section}</td>
                    <td className="px-6 py-5">
                      <span className="text-xs font-black text-slate-800 group-hover:text-blue-600 transition-colors leading-relaxed">{item.name}</span>
                    </td>
                    <td className="px-4 py-5 text-center font-bold text-slate-400 text-[10px]">{item.unit}</td>
                    <td className="px-4 py-5 text-center font-black text-slate-800 text-xs">
                      {typeof item.qty === 'number' ? item.qty.toLocaleString() : item.qty}
                    </td>
                    <td className="px-4 py-5 text-center text-[10px] font-bold text-slate-400">{item.rdDate}</td>
                    <td className="px-4 py-5 text-center text-[11px] font-black text-blue-600 bg-blue-50/20 border-x border-blue-100/30">{item.start}</td>
                    <td className="px-4 py-5 text-center text-[11px] font-black text-blue-600 bg-blue-50/20 border-x border-blue-100/30">{item.finish}</td>
                    <td className="px-6 py-5 text-center font-black text-slate-500 text-xs">{item.duration}</td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={9} className="px-6 py-20 text-center text-slate-400 italic font-bold">
                      Нет данных для отображения по выбранным фильтрам
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr className="bg-slate-950 text-white font-black uppercase tracking-[0.2em] text-[10px]">
                  <td colSpan={9} className="px-8 py-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-10">
                        <div className="flex items-center">
                          <BarChart3 size={18} className="text-blue-400 mr-3" />
                          <span>Интегральный СМР: 42.8%</span>
                        </div>
                        <div className="flex items-center">
                          <Calendar size={18} className="text-emerald-400 mr-3" />
                          <span>Завершено РД: 92%</span>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectManagers;
