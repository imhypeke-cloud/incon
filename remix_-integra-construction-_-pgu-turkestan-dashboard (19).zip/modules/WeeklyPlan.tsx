
import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  LineChart,
  Line
} from 'recharts';
import { AlertCircle, TrendingUp, Zap, HelpCircle } from 'lucide-react';

const WeeklyPlan: React.FC = () => {
  const planFactData = [
    { name: 'Неделя 1', план: 25, факт: 22 },
    { name: 'Неделя 2', план: 30, факт: 28 },
    { name: 'Неделя 3', план: 28, факт: 31 },
    { name: 'Неделя 4', план: 35, факт: 20 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800">Сводный План/Факт (Месяц)</h3>
            <div className="flex space-x-2">
              <span className="flex items-center text-xs font-bold text-blue-600">
                <span className="w-3 h-3 bg-blue-600 rounded-sm mr-1.5"></span> План
              </span>
              <span className="flex items-center text-xs font-bold text-orange-500">
                <span className="w-3 h-3 bg-orange-500 rounded-sm mr-1.5"></span> Факт
              </span>
            </div>
          </div>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={planFactData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} fontWeight="bold" axisLine={false} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} fontWeight="bold" axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}} 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="план" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={40} />
                <Bar dataKey="факт" fill="#f97316" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4 flex items-center">
            <Zap size={18} className="text-amber-500 mr-2" />
            Приоритизация работ
          </h3>
          <div className="space-y-3">
            <PriorityTask label="Котлован БНС" priority="Высокий" color="rose" />
            <PriorityTask label="Бетонирование 00-КЖ" priority="Критический" color="rose" />
            <PriorityTask label="Монтаж опор под ГТУ" priority="Средний" color="blue" />
            <PriorityTask label="Временные дороги" priority="Низкий" color="slate" />
          </div>
          <div className="mt-6 pt-6 border-t border-slate-100">
             <h4 className="text-[10px] font-bold text-slate-400 uppercase mb-3">Рейтинг РП по выполнению</h4>
             <div className="space-y-2">
               <ManagerRank name="Иванов И." progress={98} />
               <ManagerRank name="Петров А." progress={92} />
               <ManagerRank name="Сидоров К." progress={74} />
             </div>
          </div>
        </div>
      </div>

      <div className="bg-rose-50 border border-rose-100 p-6 rounded-2xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <AlertCircle className="text-rose-600" />
            <h3 className="font-bold text-rose-900">Реестр проблемных вопросов и рисков</h3>
          </div>
          <button className="bg-rose-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-rose-700 transition-all">
            Подробнее в реестре
          </button>
        </div>
        <div className="bg-white rounded-xl border border-rose-200 overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-rose-100/50 border-b border-rose-200 text-rose-900 font-bold uppercase">
                <th className="px-4 py-3">Вопрос</th>
                <th className="px-4 py-3">Алгоритм действий</th>
                <th className="px-4 py-3">Срок</th>
                <th className="px-4 py-3">Ответственный</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-rose-50">
              <tr>
                <td className="px-4 py-3 font-semibold text-slate-800">Задержка поставки арматуры (12мм)</td>
                <td className="px-4 py-3 text-slate-600 italic">Переброска с другого участка, ускорение логистики</td>
                <td className="px-4 py-3 font-bold text-rose-600 underline">20.05.2025</td>
                <td className="px-4 py-3 text-slate-700">ОМТС / Иванов</td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-semibold text-slate-800">Отставание по монтажу металлоконструкций</td>
                <td className="px-4 py-3 text-slate-600 italic">Увеличение сменности (2/2), мобилизация доп. крана</td>
                <td className="px-4 py-3 font-bold text-slate-500">25.05.2025</td>
                <td className="px-4 py-3 text-slate-700">Субподрядчик / Петров</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const PriorityTask: React.FC<{ label: string; priority: string; color: string }> = ({ label, priority, color }) => (
  <div className={`p-3 rounded-xl border flex items-center justify-between ${
    color === 'rose' ? 'bg-rose-50 border-rose-100 text-rose-900' :
    color === 'blue' ? 'bg-blue-50 border-blue-100 text-blue-900' :
    'bg-slate-50 border-slate-100 text-slate-900'
  }`}>
    <span className="text-xs font-bold">{label}</span>
    <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
      color === 'rose' ? 'bg-rose-200 text-rose-700' :
      color === 'blue' ? 'bg-blue-200 text-blue-700' :
      'bg-slate-200 text-slate-600'
    }`}>{priority}</span>
  </div>
);

const ManagerRank: React.FC<{ name: string; progress: number }> = ({ name, progress }) => (
  <div className="flex items-center space-x-3">
    <span className="text-xs font-bold text-slate-700 w-16 truncate">{name}</span>
    <div className="flex-1 bg-slate-100 h-1.5 rounded-full overflow-hidden">
      <div 
        className={`h-full rounded-full ${progress > 90 ? 'bg-emerald-500' : progress > 80 ? 'bg-blue-500' : 'bg-rose-500'}`} 
        style={{ width: `${progress}%` }}
      />
    </div>
    <span className="text-[10px] font-black text-slate-800">{progress}%</span>
  </div>
);

export default WeeklyPlan;
