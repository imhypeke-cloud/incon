
import React from 'react';
import { User, Network, ChevronDown, Briefcase, Users, HardHat, Ruler, FileText, ShieldCheck } from 'lucide-react';

const GenStructure: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      
      {/* LEVEL 1: TOP MANAGEMENT (HEADQUARTERS) */}
      <div className="flex flex-col items-center space-y-4">
        <div className="bg-slate-900 text-white p-6 rounded-3xl text-center shadow-xl border border-slate-700 min-w-[300px] md:min-w-[400px] relative z-20">
          <p className="text-[10px] font-black uppercase tracking-widest text-blue-400 mb-1">Генеральный директор по строительству</p>
          <h3 className="text-xl font-black">Рахимтаев Д. С.</h3>
        </div>
        
        <div className="h-8 w-px bg-slate-300"></div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
           <NodeCard title="Заместитель Генерального директора" name="Аширбаев Б. М." color="white" />
           <NodeCard title="Начальник Управления по строительству" name="Жаймурзин Б.Б." color="white" />
        </div>

        <div className="h-8 w-px bg-slate-300"></div>

        <div className="bg-white p-5 rounded-3xl text-center shadow-md border border-slate-200 min-w-[300px] md:min-w-[500px]">
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Филиал ТОО «Integra Construction KZ»</p>
          <p className="text-[9px] font-bold text-slate-400 mb-2">«Дирекция по проекту ПГУ в Туркестанской области»</p>
          <h3 className="text-lg font-black text-slate-900">Исполнительный директор</h3>
          <p className="text-xl font-black text-blue-600 mt-1">Сейсенбаев Ш.Т.</p>
        </div>

        <div className="h-6 w-px bg-slate-300"></div>
        <NodeCard title="Первый заместитель исполнительного директора" name="Дуйсебеков Б. Т." color="blue" />
        <div className="h-8 w-px bg-slate-300"></div>
      </div>

      {/* LEVEL 2: FUNCTIONAL DIRECTORS (3 COLUMNS) */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 relative">
        {/* Connector Lines (Desktop only) */}
        <div className="hidden xl:block absolute top-0 left-1/2 -translate-x-1/2 w-[66%] h-px bg-slate-300"></div>
        <div className="hidden xl:block absolute top-0 left-[17%] w-px h-8 bg-slate-300"></div>
        <div className="hidden xl:block absolute top-0 right-[17%] w-px h-8 bg-slate-300"></div>
        <div className="hidden xl:block absolute top-0 left-1/2 w-px h-8 bg-slate-300"></div>

        {/* COLUMN 1: ADMIN & SUPPORT */}
        <div className="flex flex-col space-y-6">
          <div className="flex flex-col items-center">
             <NodeCard 
               title="Зам. исполнительного директора по адм. вопросам" 
               name="Аташов Д." 
               color="slate" 
               className="w-full"
             />
             <div className="h-6 w-px bg-slate-300"></div>
             
             <div className="w-full space-y-3">
               <DeptCard title="Служба безопасности" head="Туебаков Нурбек Нургалиевич" icon={<ShieldCheck size={16}/>} />
               <DeptCard title="HSE (Охрана труда)" head="Ниязбеков Ерназар Жораханұлы" icon={<HardHat size={16}/>} staff={['Инж: Букпанов М.М.', 'Инж: Дилдабеков М.К.', 'Инж: Тойбаев Ж.К.']} />
               <DeptCard title="Отдел экономики и планирования" head="Тургунбаев Медет Анарбаевич" icon={<Briefcase size={16}/>} />
               <DeptCard title="Юридический отдел" head="Ким Семён Семёнович" icon={<FileText size={16}/>} />
               <DeptCard title="Отдел управления персоналом" head="Гапурова Саида Айбековна" icon={<Users size={16}/>} staff={['Менеджер: Садвакасова М.А.', 'Офис-менеджер: Оразова А.Е.']} />
               <DeptCard title="Отдел снабжения" head="Туякбаев Жасулан Ыбраевич" icon={<Briefcase size={16}/>} />
               <DeptCard title="Отдел Бухгалтерии" head="Стваева Айгуль Адасбаевна" icon={<FileText size={16}/>} />
               <DeptCard title="Контрактный отдел" head="Вакансия" icon={<FileText size={16}/>} isVacancy />
             </div>
          </div>
        </div>

        {/* COLUMN 2: CONSTRUCTION (MAIN) */}
        <div className="flex flex-col space-y-6">
          <div className="flex flex-col items-center">
             <NodeCard 
               title="Зам. исполнительного директора по строительству" 
               name="Аширбеков А.С." 
               color="blue" 
               className="w-full"
             />
             <div className="h-6 w-px bg-slate-300"></div>

             {/* CONSTRUCTION SITES GRID */}
             <div className="grid grid-cols-1 gap-4 w-full">
                {/* SITE 1 */}
                <SiteCard 
                  number="1"
                  title="Construction Civil & Structural"
                  pm="Попивнухин Николай Владимирович"
                  siteManager="Раджабов Нидали Рашидович"
                  foremen={['Мусаев М.М.', 'Аманов А.С.', 'Туламишов С.Ч.']}
                  titles={['1.1', '1.2', '1.3', '4.1', '4.2', '5.1-5.4', '6.1-6.4']}
                />
                
                {/* SITE 2 */}
                <SiteCard 
                  number="2"
                  title="Construction Civil & Structural"
                  pm="Махмудов Юнус Смихан-Оглы"
                  siteManager="Лепесканов А."
                  foremen={['Наркулов А.А.', 'Сабденбеков М.У.', 'Алиев Л.Н.', 'Эспанов Е.М.']}
                  titles={['8.1', '8.2', '12.1', '12.2-12.3', '23.4', '24', '38', '39', '42', '43', '44', '45', '46', '47', '48', '49']}
                />

                {/* SITE 3 */}
                <SiteCard 
                  number="3"
                  title="Construction Civil & Structural"
                  pm="Алдамуратов Рахматулла Изатуллаевич"
                  siteManager="Диханбаев Ержан Болаганович"
                  foremen={['Кулахметов З.Н.', 'Диамантиди С.П.', 'Салихов Е.Ж.']}
                  titles={['2.1', '2.2', '3', '7.1', '7.2', '9', '10', '13', '15', '16', '18', '19', '20', '21', '22', '27', '28', '29', '31', '32', '33', '35', '36', '37', '41', '50']}
                />

                {/* SITE 4 */}
                <SiteCard 
                  number="4"
                  title="Construction Civil & Structural"
                  pm="Вакансия"
                  isVacancy
                  siteManager="Абилькасимов Болат Жарылкасымович"
                  foremen={['Оралбаев Даурен Жоламанулы']}
                  titles={['25 (АБК)', '30 (Проходная)']}
                />

                {/* SITE 5 */}
                <SiteCard 
                  number="5"
                  title="Construction Equipment & Mechanical"
                  pm="Тлеулесов Каржаубай Куандыкович"
                  siteManager="Савин Денис Сергеевич"
                  foremen={['Горбатенко Михаил Александрович']}
                  titles={['Монтаж оборудования', 'Механика', 'Трубопровод']}
                  color="orange"
                />

                {/* SITE 6 */}
                <SiteCard 
                  number="6"
                  title="Construction Electrical & Instrumentation"
                  pm="Рахматулла Айбек (Нач. отдела)"
                  siteManager="—"
                  foremen={['Тасыбаев Н.Р.', 'Кулжанов А.Б.', 'Қанытбек О.С.', 'Байтиев Д.Ш.']}
                  titles={['Электрика', 'КИПиА']}
                  color="emerald"
                />
             </div>
          </div>
        </div>

        {/* COLUMN 3: TECHNICAL */}
        <div className="flex flex-col space-y-6">
          <div className="flex flex-col items-center">
             <NodeCard 
               title="Технический директор" 
               name="Курманов С.С." 
               color="slate" 
               className="w-full"
             />
             <div className="h-6 w-px bg-slate-300"></div>

             <div className="w-full space-y-3">
               <DeptCard title="Project Engineering" head="Главный инженер: Вакансия" icon={<Ruler size={16}/>} isVacancy />
               
               <DeptCard 
                 title="ОПП (Отдел подготовки пр-ва)" 
                 head="Грошев Николай Александрович" 
                 icon={<FileText size={16}/>} 
                 staff={['Зам: Кривопалов О.А.', 'Вед.инж: Гамидов М.П.', 'Инж: Хайрулла Б.Ә.', 'Инж: Абдиманатов Е.К.']}
               />

               <DeptCard title="Отдел по управлению отчетностью" head="Садикова Мария Марсовна" icon={<FileText size={16}/>} staff={['Менеджер: Хасанов Р.А.']} />
               
               <DeptCard 
                 title="ПТО (Производственно-тех. отдел)" 
                 head="Байларов Бекзод Ботирұлы" 
                 icon={<Briefcase size={16}/>} 
                 staff={['Зам: Ергешов Ә.Ә.', 'Вед.инж: Әскербеков А.Н.', 'Вед.инж: Әлиакбар Е.Е.', 'Вед.инж: Сейилов Қ.Н.', 'Вед.инж: Клочков А.Г.']}
               />

               <DeptCard title="Сметный отдел" head="Жуматаева Нургуль Омиртаевна" icon={<FileText size={16}/>} />
               
               <DeptCard 
                 title="QA/QC (Отдел контроля качества)" 
                 head="Кулбаев Камбар" 
                 icon={<ShieldCheck size={16}/>} 
                 staff={['Вед.инж: Пернебай Аян', 'Инж: Мохов Валерий', 'Инж: Юсупбеков Алибек', 'Инж: Шаден Жасулан', 'Инж: Сапаров Айбар']}
               />

               <DeptCard 
                 title="Отдел геодезии" 
                 head="Назаров Олжас Жайлаубаевич" 
                 icon={<Ruler size={16}/>} 
                 staff={['Вед.геод: Шалбаев М.С.', 'Вед.геод: Жандосов Б.Ж.', 'Вед.геод: Исабек Н.Б.']}
               />
             </div>
          </div>
        </div>

      </div>
    </div>
  );
};

// --- COMPONENTS ---

const NodeCard: React.FC<{ title: string; name: string; color: 'blue' | 'white' | 'slate'; className?: string }> = ({ title, name, color, className }) => {
  const styles = {
    blue: 'bg-blue-600 text-white border-blue-700',
    white: 'bg-white text-slate-800 border-slate-200',
    slate: 'bg-slate-50 text-slate-800 border-slate-200'
  };

  return (
    <div className={`p-4 rounded-2xl border text-center shadow-sm ${styles[color]} ${className}`}>
      <p className={`text-[9px] font-black uppercase tracking-widest mb-1 ${color === 'blue' ? 'text-blue-100' : 'text-slate-400'}`}>{title}</p>
      <p className="text-sm font-black leading-tight">{name}</p>
    </div>
  );
};

const DeptCard: React.FC<{ title: string; head: string; icon: React.ReactNode; staff?: string[]; isVacancy?: boolean }> = ({ title, head, icon, staff, isVacancy }) => {
  return (
    <div className={`p-4 bg-white rounded-2xl border ${isVacancy ? 'border-rose-200 bg-rose-50/30' : 'border-slate-200'} shadow-sm text-left hover:shadow-md transition-all`}>
      <div className="flex items-center space-x-3 mb-2">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isVacancy ? 'bg-rose-100 text-rose-500' : 'bg-slate-100 text-slate-500'}`}>
          {icon}
        </div>
        <div className="flex-1">
          <p className="text-[10px] font-black uppercase tracking-tight text-slate-800 leading-none mb-1">{title}</p>
          <p className={`text-[11px] font-bold ${isVacancy ? 'text-rose-600' : 'text-blue-600'}`}>{head}</p>
        </div>
      </div>
      {staff && staff.length > 0 && (
        <div className="mt-2 pl-11 space-y-1">
          {staff.map((s, idx) => (
            <p key={idx} className="text-[9px] font-medium text-slate-500 border-l-2 border-slate-100 pl-2">{s}</p>
          ))}
        </div>
      )}
    </div>
  );
};

const SiteCard: React.FC<{ 
  number: string; 
  title: string; 
  pm: string; 
  siteManager: string; 
  titles: string[]; 
  foremen: string[]; 
  isVacancy?: boolean;
  color?: 'blue' | 'orange' | 'emerald';
}> = ({ number, title, pm, siteManager, titles, foremen, isVacancy, color = 'blue' }) => {
  
  const colorStyles = {
    blue: { header: 'bg-blue-600', border: 'border-blue-100', icon: 'text-blue-600 bg-blue-50' },
    orange: { header: 'bg-orange-500', border: 'border-orange-100', icon: 'text-orange-600 bg-orange-50' },
    emerald: { header: 'bg-emerald-600', border: 'border-emerald-100', icon: 'text-emerald-600 bg-emerald-50' }
  };

  const theme = colorStyles[color];

  return (
    <div className={`rounded-2xl border ${theme.border} bg-white shadow-sm overflow-hidden flex flex-col`}>
      <div className={`${theme.header} px-4 py-2 flex items-center justify-between`}>
        <span className="text-white text-[10px] font-black uppercase tracking-widest">Участок №{number}</span>
        <span className="text-white/80 text-[9px] font-bold">{title}</span>
      </div>
      <div className="p-4 space-y-3">
        <div>
          <p className="text-[9px] font-black uppercase tracking-wider text-slate-400 mb-0.5">Руководитель проекта</p>
          <p className={`text-xs font-black ${isVacancy ? 'text-rose-600' : 'text-slate-800'}`}>{pm}</p>
        </div>
        
        <div className="flex flex-col gap-2">
           <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
              <p className="text-[9px] font-bold text-slate-400 mb-1 flex items-center">
                <HardHat size={10} className="mr-1.5"/> Начальник участка
              </p>
              <p className="text-[10px] font-black text-slate-700">{siteManager}</p>
           </div>
           
           {foremen.length > 0 && (
             <div className="space-y-1">
               <p className="text-[9px] font-bold text-slate-400 pl-1">Прорабы / Мастера:</p>
               {foremen.map((f, i) => (
                 <p key={i} className="text-[10px] text-slate-600 pl-3 border-l-2 border-slate-200">{f}</p>
               ))}
             </div>
           )}
        </div>

        <div className="pt-2 border-t border-slate-50">
          <p className="text-[9px] font-black text-slate-400 mb-2">Закрепленные титулы:</p>
          <div className="flex flex-wrap gap-1">
            {titles.map((t, idx) => (
              <span key={idx} className={`px-2 py-0.5 rounded text-[9px] font-bold border ${theme.icon}`}>
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GenStructure;
