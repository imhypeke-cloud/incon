import React, { useState, useMemo } from 'react';
import { 
  Phone, 
  User, 
  FileText, 
  Users, 
  Calendar, 
  Briefcase,
  Search,
  Filter,
  Download,
  LayoutGrid,
  List,
  Building2,
  MoreHorizontal,
  ChevronRight,
  HardHat,
  AlertCircle
} from 'lucide-react';

interface SubcontractorData {
  id: number;
  name: string;
  bin?: string;
  director: string;
  directorContact?: string;
  siteManager: string;
  siteManagerContact?: string;
  workersReg: number;
  workersFact: number;
  contractInfo: string;
  workScope: string;
  titles: string[];
  projectManager: string;
  deadline: string;
  status: 'Active' | 'Inactive' | 'Signing' | 'Completed';
  note?: string;
}

const Subcontractors: React.FC = () => {
  // Установлен 'list' по умолчанию
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  const contractors: SubcontractorData[] = [
    {
      id: 1,
      name: 'ИП Рахим',
      director: 'Рахим Нұртай Ержанұлы',
      siteManager: '—',
      workersReg: 0,
      workersFact: 0,
      contractInfo: 'б/н от 17.09.2025 г.',
      workScope: 'Засыпка фрезерованного материала территории',
      titles: [],
      projectManager: 'Алдамуратов Р.И.',
      deadline: '17.09.2025 - 30.09.2025',
      status: 'Active'
    },
    {
      id: 2,
      name: 'ТОО IST-Q',
      director: 'Представитель',
      directorContact: '8 701 944 77 99',
      siteManager: '—',
      workersReg: 0,
      workersFact: 0,
      contractInfo: '859-РП от 30.09.2025 г.',
      workScope: 'Металлоконструкция по титулу 50',
      titles: ['50', '1.1'],
      projectManager: 'Алдамуратов Р.И., Попивнухин Н.В.',
      deadline: '—',
      status: 'Inactive',
      note: 'Договор не актуален, Подрядчик отказался'
    },
    {
      id: 3,
      name: 'ТОО Baibol',
      director: 'Молдабеков Канатбек Калдарбекович',
      siteManager: 'Нурбек',
      siteManagerContact: '8 708 628 94 76',
      workersReg: 56,
      workersFact: 20,
      contractInfo: '16/10-01 от 16.10.2025 г.',
      workScope: 'Бетонная подготовка, ж/б фундамент, гидроизоляция',
      titles: ['1.1-КЖ 14-15'],
      projectManager: 'Попивнухин Н.В.',
      deadline: '16.10.2025 - 25.12.2025',
      status: 'Active'
    },
    {
      id: 4,
      name: 'ТОО ЕвроСтройТехнология',
      director: 'Темірбек Қуат Анарбекұлы',
      siteManager: 'Ерсултан',
      siteManagerContact: '8 778 561 20 02',
      workersReg: 27,
      workersFact: 19,
      contractInfo: '16/10-02/03 от 16.10.2025, 917-РП от 20.10.2025',
      workScope: 'Монолитные работы, сборка/монтаж труб',
      titles: ['1.1'],
      projectManager: 'Попивнухин Н.В.',
      deadline: '04.10.2025 - 30.12.2026',
      status: 'Active'
    },
    {
      id: 5,
      name: 'ТОО АТАМЕКЕН-ҚС',
      director: 'Адильбеков Полатбек Койлыбекович',
      siteManager: 'Нурсултан',
      siteManagerContact: '8 778 832 92 50',
      workersReg: 37,
      workersFact: 28,
      contractInfo: '914-РП от 17.10.2025 г.',
      workScope: 'Устройство ж/б монолит',
      titles: ['35'],
      projectManager: 'Абилькасимов Б.Ж.',
      deadline: '17.10.2025 - 28.02.2026',
      status: 'Active'
    },
    {
      id: 6,
      name: 'ТОО Q17 CONSTRUCTION',
      director: 'Ешенов Дауренбек Сайранулы',
      siteManager: 'Нач. Участка',
      siteManagerContact: '8 700 207 0096',
      workersReg: 13,
      workersFact: 4,
      contractInfo: '1006-РП от 20.11.2025 г.',
      workScope: 'Титул 35 под ключ',
      titles: ['35'],
      projectManager: 'Алдамуратов Р.И.',
      deadline: '20.11.2025 - 30.07.2026',
      status: 'Active',
      note: '918-рп от 20.10.2025 (МК) не актуален'
    },
    {
      id: 7,
      name: 'ТОО SST Building Co.',
      director: 'Моминов Асан Дуйсенбекович',
      siteManager: 'Жандос',
      siteManagerContact: '8705 222 2775',
      workersReg: 84,
      workersFact: 18,
      contractInfo: '29/10-02 от 29.10.2025, 1002-РП от 20.11.2025',
      workScope: 'Монолитные работы, Монтаж ГТГ',
      titles: ['42', '24', 'Монтаж ГТГ'],
      projectManager: 'Махмудов Ю.С.',
      deadline: '13.10.2025 - 25.12.2025',
      status: 'Active'
    },
    {
      id: 8,
      name: 'ТОО «KTB Partners»',
      director: 'Тё Лариса Афанасьевна',
      directorContact: '8 702 427 57 25',
      siteManager: '—',
      workersReg: 17,
      workersFact: 8,
      contractInfo: '1005-PП от 20.11.2025 г.',
      workScope: 'Титул 25 под ключ',
      titles: ['25'],
      projectManager: 'Абилькасимов Б.Ж.',
      deadline: '20.11.2025 - 30.11.2026',
      status: 'Signing'
    },
    {
      id: 9,
      name: 'ТОО "QPARK group"',
      director: 'Аманкелді Кахарман Қанатбекұлы',
      directorContact: '8 701 444 70 66',
      siteManager: '—',
      workersReg: 46,
      workersFact: 19,
      contractInfo: '1007-РП от 20.11.2025 г.',
      workScope: 'Титул 24 под ключ',
      titles: ['24'],
      projectManager: 'Махмудов Ю.С.',
      deadline: '20.11.2025 - 30.07.2026',
      status: 'Active'
    },
    {
      id: 10,
      name: 'ТОО "Адал Жарық Құрылыс"',
      director: 'Утепбергенов Ардак Байжанович',
      directorContact: '8 702 468 3763',
      siteManager: '—',
      workersReg: 28,
      workersFact: 19,
      contractInfo: '1008-РП от 20.11.2025 г.',
      workScope: 'Титул 38 под ключ',
      titles: ['38'],
      projectManager: 'Алдамуратов Р.И.',
      deadline: '20.11.2025 - 30.10.2026',
      status: 'Active'
    },
    {
      id: 11,
      name: 'ТОО "NUR-AKHMED GROUP»',
      director: 'Астанакулов Нуржан Махматиллаевич',
      directorContact: '8 747 323 0707',
      siteManager: '—',
      workersReg: 42,
      workersFact: 12,
      contractInfo: '1009-РП, 1010-РП от 20.11.2025 г.',
      workScope: 'Титул 48, 8.2 под ключ',
      titles: ['48', '8.2'],
      projectManager: 'Махмудов Ю.С.',
      deadline: '20.11.2025 - 30.12.2026',
      status: 'Active'
    },
    {
      id: 12,
      name: 'ТОО Ancon',
      director: 'Қылыш Азамат Қылышұлы',
      directorContact: '8 778 750 41 17',
      siteManager: '—',
      workersReg: 66,
      workersFact: 46,
      contractInfo: '29/10-01 от 29.10.2025, 1011-РП от 20.11.2025',
      workScope: 'Монолитные работы Титул 1.2, Титул 42 под ключ',
      titles: ['1.2', '42'],
      projectManager: 'Попивнухин Н.В., Махмудов Ю.С.',
      deadline: '20.10.2025 - 30.10.2026',
      status: 'Active'
    },
    {
      id: 13,
      name: 'ТОО KazBuildPartner',
      director: 'Таукеев Нуртас Максатович',
      directorContact: '8 701 427 18 40',
      siteManager: '—',
      workersReg: 5,
      workersFact: 0,
      contractInfo: '961-РП от 31.10.2025 г.',
      workScope: 'Изготовление и монтаж МК',
      titles: ['12.2-12.3', '33.1-33.6'],
      projectManager: 'Махмудов Ю.С.',
      deadline: '31.10.2025 - 30.05.2026',
      status: 'Active'
    },
    {
      id: 14,
      name: 'ИП Жігер',
      director: 'Айтжанова Майра Сериккызы',
      directorContact: '8 705 150 42 84',
      siteManager: 'Газиз',
      siteManagerContact: '8 705 546 70 70',
      workersReg: 0,
      workersFact: 0,
      contractInfo: '05/11-01 от 05.11.2025 г.',
      workScope: 'Алмазное сверление',
      titles: [],
      projectManager: '—',
      deadline: '3 дня с даты подписания',
      status: 'Active'
    },
    {
      id: 15,
      name: 'ТОО Центр противопожарных услуг',
      director: 'Гасанова Гулсахар Асанхановна',
      directorContact: '8 778 289 01 87',
      siteManager: '—',
      workersReg: 0,
      workersFact: 0,
      contractInfo: '07/10-02 от 07.10.2025 г.',
      workScope: 'Покраска металлоконструкций',
      titles: [],
      projectManager: '—',
      deadline: '—',
      status: 'Active'
    },
    {
      id: 16,
      name: 'ТОО Блиц-Монтаж',
      director: 'Бижанов Санжархан Серікұлы',
      siteManager: '—',
      workersReg: 494,
      workersFact: 305,
      contractInfo: '24/11-01 от 24.11.2025 г.',
      workScope: 'Монолитные работы',
      titles: ['Все основные'],
      projectManager: 'Все РП',
      deadline: 'до 31.12.2026',
      status: 'Active'
    },
    {
      id: 17,
      name: 'ТОО Пром Альп',
      director: 'Асанов Бахытжан Жолдасбекович',
      directorContact: '87014783490',
      siteManager: '—',
      workersReg: 0,
      workersFact: 0,
      contractInfo: '13/12-01 от 13.12.2025 г.',
      workScope: 'Антикоррозионные и теплоизоляционные работы',
      titles: ['13.2-13.3', '15.2-15.3', '48.1-48.2'],
      projectManager: '—',
      deadline: '08.01.2026 - 31.03.2026',
      status: 'Active'
    },
    {
      id: 18,
      name: 'ТОО Луго Строй',
      director: 'Қалықбергенов Алишер Нұрлыбекұлы',
      directorContact: '8 702 828 52 50',
      siteManager: '—',
      workersReg: 15,
      workersFact: 4,
      contractInfo: '17/12-01 от 17.12.2025 г.',
      workScope: 'Фасад с 30 титула',
      titles: ['30'],
      projectManager: 'Абилькасимов Б.Ж.',
      deadline: '15.10.2025 - 15.01.2026',
      status: 'Active'
    },
    {
      id: 19,
      name: 'ТОО «Mega Most Construction»',
      director: 'Жаксылыкова Жамал Сагымбаевна',
      directorContact: '8 702 502 88 66',
      siteManager: '—',
      workersReg: 49,
      workersFact: 13,
      contractInfo: '10/12-01 от 10.12.2025 г.',
      workScope: 'Монолитные работы титул 25 - АБК',
      titles: ['25'],
      projectManager: 'Абилькасимов Б.Ж.',
      deadline: '—',
      status: 'Active',
      bin: '020240017956'
    },
    {
      id: 20,
      name: 'ТОО «SARENS» аренда',
      director: 'Арун Мэтью',
      siteManager: '—',
      workersReg: 17,
      workersFact: 7,
      contractInfo: 'SKZ-515/2025 от 20.10.2025 г.',
      workScope: 'Аренда спецтехники',
      titles: ['Спецтехника'],
      projectManager: '—',
      deadline: 'мин.срок аренды 5 месяцев',
      status: 'Active'
    },
    {
      id: 21,
      name: 'ТОО «STEKOL»',
      director: '—',
      siteManager: '—',
      workersReg: 51,
      workersFact: 31,
      contractInfo: 'Не подписан, на обсуждении',
      workScope: '—',
      titles: [],
      projectManager: '—',
      deadline: '—',
      status: 'Signing'
    },
    {
      id: 22,
      name: 'ТОО «ИМСТАЛЬКОН»',
      bin: '950540000292',
      director: 'Малинин А.А.',
      siteManager: '—',
      workersReg: 43,
      workersFact: 12,
      contractInfo: 'Соглашение об уступке права (Цессия)',
      workScope: 'Монтаж металлоконструкций ГК',
      titles: ['Главный корпус'],
      projectManager: '—',
      deadline: '—',
      status: 'Active',
      note: 'работают по Цессии (была переуступка Базисом)'
    },
    {
      id: 23,
      name: 'ТОО «TOWER CONSTRUCTION 2030»',
      bin: '030240005469',
      director: 'Кушумов Артур Талгатович',
      directorContact: '8 701 035 5925 Канат',
      siteManager: '—',
      workersReg: 19,
      workersFact: 9,
      contractInfo: '5 -ГД от 08.01.2026',
      workScope: 'Насосная станция циркуляционной воды',
      titles: ['8.1'],
      projectManager: 'Махмудов Ю.С.',
      deadline: '10.2025 - 06.2026',
      status: 'Signing',
      note: 'на подписании у ЦА'
    },
    {
      id: 24,
      name: 'ТОО «SAI-Construction Company»',
      bin: '200740007330',
      director: 'Утешова Гаухар Бауржановна',
      directorContact: '8 700 657 64 79',
      siteManager: '—',
      workersReg: 28,
      workersFact: 9,
      contractInfo: '28/11-01 от 28.11.2025 г.',
      workScope: 'Монолитные работы',
      titles: [],
      projectManager: '—',
      deadline: '01.11.2025 - 31.12.2025',
      status: 'Active',
      note: 'открытый договор'
    }
  ];

  const filteredContractors = useMemo(() => {
    return contractors.filter(c => {
      const searchMatch = c.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          c.director?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.titles.some(t => t.includes(searchTerm));
      const statusMatch = statusFilter === 'All' || c.status === statusFilter;
      return searchMatch && statusMatch;
    });
  }, [contractors, searchTerm, statusFilter]);

  const totalWorkersReg = contractors.reduce((acc, c) => acc + c.workersReg, 0);
  const totalWorkersFact = contractors.reduce((acc, c) => acc + c.workersFact, 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      
      {/* HEADER STATS - REPLACED WITH SINGLE CLEAN CARD */}
      <div className="bg-white p-5 rounded-[1.5rem] border border-slate-200 shadow-sm flex items-center justify-between">
         <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-white">
                <FileText size={24} />
            </div>
            <div>
                <h3 className="text-lg font-black text-slate-800 leading-tight">Реестр Договоров</h3>
                <p className="text-xs text-slate-500 font-medium">Субподрядные организации</p>
            </div>
         </div>
         <div className="bg-slate-50 px-5 py-2 rounded-xl border border-slate-100 flex flex-col items-end">
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Всего</span>
             <span className="text-2xl font-black text-slate-800">{contractors.length}</span>
         </div>
      </div>

      {/* TOOLBAR */}
      <div className="bg-white p-4 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col lg:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full lg:w-auto flex-1 max-w-2xl">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Поиск организации, директора или титула..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all"
            />
          </div>
          
          <div className="relative">
            <Filter size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="pl-9 pr-8 py-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold outline-none focus:ring-4 focus:ring-blue-500/10 cursor-pointer appearance-none min-w-[140px]"
            >
              <option value="All">Все статусы</option>
              <option value="Active">Действующие</option>
              <option value="Signing">На подписании</option>
              <option value="Inactive">Не активные</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button 
              onClick={() => setViewMode('grid')}
              className={`p-2.5 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <LayoutGrid size={18} />
            </button>
            <button 
              onClick={() => setViewMode('list')}
              className={`p-2.5 rounded-lg transition-all ${viewMode === 'list' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <List size={18} />
            </button>
          </div>
          <button className="flex items-center space-x-2 bg-slate-900 text-white px-5 py-3 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-lg shadow-slate-900/20">
            <Download size={16} />
            <span className="hidden sm:inline">Экспорт</span>
          </button>
        </div>
      </div>

      {/* CONTENT */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filteredContractors.map((c) => (
            <ContractorCard key={c.id} data={c} />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl overflow-hidden">
          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-left border-collapse min-w-[1400px]">
              <thead>
                <tr className="bg-slate-50 text-[9px] font-black uppercase text-slate-400 tracking-[0.1em] border-b border-slate-100">
                  <th className="px-4 py-3 w-16 text-center">№</th>
                  <th className="px-4 py-3 min-w-[180px]">Наименование / БИН</th>
                  <th className="px-4 py-3 min-w-[180px]">Руководство / Контакты</th>
                  <th className="px-4 py-3 text-center">Договор</th>
                  <th className="px-4 py-3 min-w-[220px]">Предмет договора / Титулы</th>
                  <th className="px-4 py-3 text-center">Персонал (Рег/Факт)</th>
                  <th className="px-4 py-3 min-w-[120px]">Куратор РП</th>
                  <th className="px-4 py-3 min-w-[120px]">Срок работ</th>
                  <th className="px-4 py-3 text-center">Статус</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredContractors.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/50 transition-all group text-[11px]">
                    <td className="px-4 py-3 text-center font-black text-slate-300">{c.id}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col">
                        <span className="font-black text-slate-800 mb-0.5">{c.name}</span>
                        {c.bin && <span className="text-[9px] font-mono text-slate-400">БИН: {c.bin}</span>}
                        {c.note && (
                          <div className="mt-1 text-[8px] font-bold text-amber-600 bg-amber-50 p-1 rounded border border-amber-100 inline-block max-w-[180px]">
                            {c.note}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="space-y-2">
                        <div>
                          <div className="flex items-center space-x-1.5 mb-0.5">
                            <User size={10} className="text-blue-500" />
                            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wide">Руководитель</span>
                          </div>
                          <p className="font-bold text-slate-800 leading-tight">{c.director}</p>
                          {c.directorContact && <p className="text-[9px] text-slate-400 font-mono">{c.directorContact}</p>}
                        </div>
                        {c.siteManager !== '—' && (
                          <div>
                            <div className="flex items-center space-x-1.5 mb-0.5">
                              <User size={10} className="text-emerald-500" />
                              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wide">Нач. участка</span>
                            </div>
                            <p className="font-bold text-slate-800 leading-tight">{c.siteManager}</p>
                            {c.siteManagerContact && <p className="text-[9px] text-slate-400 font-mono">{c.siteManagerContact}</p>}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="inline-block px-2 py-1 bg-slate-100 text-slate-600 rounded text-[9px] font-bold border border-slate-200 max-w-[100px] truncate" title={c.contractInfo}>
                        {c.contractInfo.split(' ')[0]}...
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-medium text-slate-600 leading-snug mb-1.5 line-clamp-2" title={c.workScope}>{c.workScope}</p>
                      {c.titles.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {c.titles.map((t, idx) => (
                            <span key={idx} className="px-1.5 py-0.5 bg-blue-50 text-blue-700 rounded text-[9px] font-black border border-blue-100">
                              {t}
                            </span>
                          ))}
                        </div>
                      ) : null}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col items-center justify-center space-y-1">
                        <div className="flex items-center space-x-1">
                          <span className="font-black text-slate-800">{c.workersReg}</span>
                          <span className="text-[8px] text-slate-400 uppercase">Рег.</span>
                        </div>
                        <div className="w-12 h-1 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500" style={{ width: c.workersReg > 0 ? `${(c.workersFact / c.workersReg) * 100}%` : '0%' }}></div>
                        </div>
                        <div className="flex items-center space-x-1">
                          <span className="font-black text-emerald-600">{c.workersFact}</span>
                          <span className="text-[8px] text-slate-400 uppercase">Факт</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-bold text-slate-700 text-[10px]">{c.projectManager}</p>
                    </td>
                    <td className="px-4 py-3">
                      {c.deadline !== '—' ? (
                        <div className="flex items-center text-[9px] font-bold text-slate-500 bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100 w-fit whitespace-nowrap">
                          <Calendar size={10} className="mr-1 text-slate-400" />
                          {c.deadline}
                        </div>
                      ) : <span className="text-slate-300 text-[9px]">Не указан</span>}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge status={c.status} compact />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

// COMPONENTS

const ContractorCard: React.FC<{ data: SubcontractorData }> = ({ data }) => {
  const progressPercent = data.workersReg > 0 ? (data.workersFact / data.workersReg) * 100 : 0;

  return (
    <div className="bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all group flex flex-col h-full relative overflow-hidden">
      {/* Decorative gradient */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-bl-full -mr-8 -mt-8 z-0 transition-transform group-hover:scale-110" />
      
      <div className="relative z-10 flex justify-between items-start mb-6">
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-white border border-slate-100 rounded-2xl flex items-center justify-center shadow-sm text-lg font-black text-slate-700">
            {data.name.substring(0, 2).toUpperCase()}
          </div>
          <div>
            <h3 className="text-sm font-black text-slate-800 leading-tight line-clamp-2 pr-4 min-h-[2.5em]">{data.name}</h3>
            {data.bin && <p className="text-[10px] text-slate-400 font-mono mt-1">БИН: {data.bin}</p>}
          </div>
        </div>
        <StatusBadge status={data.status} compact />
      </div>

      <div className="space-y-4 flex-1 relative z-10">
        <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100/50 space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2.5">
              <div className="w-7 h-7 bg-white rounded-lg flex items-center justify-center text-blue-500 shadow-sm border border-slate-100">
                <User size={14} />
              </div>
              <div>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Руководитель</p>
                <p className="text-[11px] font-bold text-slate-700 leading-tight line-clamp-1">{data.director}</p>
              </div>
            </div>
            {data.directorContact && (
              <a href={`tel:${data.directorContact}`} className="text-slate-400 hover:text-blue-600 transition-colors p-1">
                <Phone size={14} />
              </a>
            )}
          </div>

          <div className="w-full h-px bg-slate-200/50" />

          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-2.5">
              <div className="w-7 h-7 bg-white rounded-lg flex items-center justify-center text-emerald-500 shadow-sm border border-slate-100">
                <HardHat size={14} />
              </div>
              <div>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Нач. участка</p>
                <p className="text-[11px] font-bold text-slate-700 leading-tight line-clamp-1">{data.siteManager}</p>
              </div>
            </div>
            {data.siteManagerContact && (
              <a href={`tel:${data.siteManagerContact}`} className="text-slate-400 hover:text-emerald-600 transition-colors p-1">
                <Phone size={14} />
              </a>
            )}
          </div>
        </div>

        <div className="px-1">
          <div className="flex justify-between items-center mb-1.5">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Персонал (Факт / Рег)</p>
            <p className="text-[10px] font-bold text-slate-600">{data.workersFact} <span className="text-slate-300">/</span> {data.workersReg}</p>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-1000 ${progressPercent > 80 ? 'bg-emerald-500' : 'bg-blue-500'}`} 
              style={{ width: `${Math.min(100, progressPercent)}%` }}
            />
          </div>
        </div>

        {data.workScope && (
          <div className="bg-blue-50/50 rounded-xl p-3 border border-blue-100/50">
            <p className="text-[10px] font-bold text-blue-800 line-clamp-2 leading-relaxed italic">
              "{data.workScope}"
            </p>
          </div>
        )}
      </div>

      <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between relative z-10">
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 bg-slate-900 rounded-full flex items-center justify-center text-white text-[10px] font-black">
            {data.projectManager.charAt(0)}
          </div>
          <span className="text-[10px] font-bold text-slate-500 truncate max-w-[100px]">{data.projectManager.split(' ')[0]}</span>
        </div>
        <button className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline flex items-center">
          Подробнее <ChevronRight size={12} className="ml-1" />
        </button>
      </div>
    </div>
  );
};

const StatusBadge: React.FC<{ status: string; compact?: boolean }> = ({ status, compact }) => {
  const styles = {
    'Active': 'bg-emerald-50 text-emerald-600 border-emerald-100',
    'Inactive': 'bg-rose-50 text-rose-600 border-rose-100',
    'Signing': 'bg-amber-50 text-amber-600 border-amber-100',
    'Completed': 'bg-blue-50 text-blue-600 border-blue-100',
  };

  const labels = {
    'Active': 'Действующий',
    'Inactive': 'Не активен',
    'Signing': 'На подписании',
    'Completed': 'Завершен',
  };

  return (
    <span className={`inline-flex items-center ${compact ? 'px-2 py-1' : 'px-2.5 py-1'} rounded-lg border text-[9px] font-black uppercase tracking-wider ${(styles as any)[status]}`}>
      <div className={`w-1.5 h-1.5 rounded-full mr-1.5 ${(status === 'Active' ? 'bg-emerald-500 animate-pulse' : 'bg-current')}`} />
      {(labels as any)[status]}
    </span>
  );
};

export default Subcontractors;