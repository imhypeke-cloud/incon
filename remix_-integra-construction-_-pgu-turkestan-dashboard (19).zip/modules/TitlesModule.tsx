
import React, { useState, useMemo, useEffect } from 'react';
import { ProjectStatus, User, Title, UserRole, VolumeData } from '../types';
import { 
  AlertTriangle, 
  CheckCircle, 
  ChevronDown, 
  Clock, 
  Search, 
  Target,
  User as UserIcon,
  BadgeCheck,
  Edit2,
  Save,
  X,
  Filter,
  Layers,
  Calculator,
  Calendar
} from 'lucide-react';

interface TitlesModuleProps {
  user: User;
  titles: Title[];
  onUpdateTitle: (updatedTitle: Title) => void;
}

const MANAGER_MAPPING = [
  { id: '1', name: 'Попивнухин Н.В.', titles: ['1.1', '1.2', '1.3', '4.1-4.2', '5.1-5.2', '5.3-5.4', '6.1-6.4', '23.1.1-23.1.2', '23.2', '23.3.1-23.3.2', '34'] },
  { id: '2', name: 'Махмудов Ю.С.', titles: ['8.1', '8.2', '12.1', '12.2', '12.3', '23.4', '24', '38', '39.1-39.4', '42', '43', '44', '45.1', '45.2', '46', '47.1', '47.2', '47.3', '48', '48.1-48.2', '49'] },
  { id: '3', name: 'Алдамуратов Р.И.', titles: ['2.1', '2.2', '3', '7.1', '7.2', '9', '10,11', '13.2-13.3', '13.4', '15.1', '15.2-15.3', '15.4-15.5', '16', '18', '19', '20.1-20.3', '21', '22.1-22.6', '23.5', '23.6.1-23.6.2', '23.7', '26.1-26.3', '27', '28', '29', '31', '32', '33.1-33.6', '35', '35.1', '36', '37', '41', '50', '51', '52'] },
  { id: '4', name: 'Абилькасимов Б.Ж.', titles: ['25', '30'] }
];

const TitlesModule: React.FC<TitlesModuleProps> = ({ user, titles, onUpdateTitle }) => {
  const [expandedTitleId, setExpandedTitleId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('Все статусы');
  const [managerFilter, setManagerFilter] = useState<string>('Все РП');
  const [sectionFilter, setSectionFilter] = useState<string>('Все разделы');
  const [searchQuery, setSearchQuery] = useState('');

  // СПЕЦИАЛЬНЫЕ ТИТУЛЫ (00-КЖ и Временные)
  const specialTitles = titles.filter(t => t.number === '00-КЖ' || t.number === 'Временные');
  const regularTitles = titles.filter(t => t.number !== '00-КЖ' && t.number !== 'Временные');

  const titlesWithContext = useMemo(() => {
    return regularTitles.map(t => {
      const mapping = MANAGER_MAPPING.find(m => 
        m.titles.includes(t.number) || 
        m.titles.some(mt => t.number === mt || t.number.startsWith(mt + '.'))
      );
      return {
        ...t,
        manager: t.manager || (mapping ? mapping.name : 'Не назначен'),
      };
    });
  }, [regularTitles]);

  const managersList = useMemo(() => ['Все РП', ...MANAGER_MAPPING.map(m => m.name)], []);

  const filteredTitles = useMemo(() => {
    return titlesWithContext.filter(t => {
      const statusMatch = statusFilter === 'Все статусы' || t.status === statusFilter;
      const managerMatch = managerFilter === 'Все РП' || t.manager === managerFilter;
      let sectionMatch = true;
      if (sectionFilter === 'Железобетон (КЖ)') sectionMatch = !!(t.rc && t.rc.total > 0);
      else if (sectionFilter === 'Металлоконструкции (КМ)') sectionMatch = !!(t.sc && t.sc.total > 0);

      const searchMatch = !searchQuery || 
        t.name?.toLowerCase().includes(searchQuery.toLowerCase()) || 
        t.number?.toLowerCase().includes(searchQuery.toLowerCase());
        
      return statusMatch && managerMatch && sectionMatch && searchMatch;
    });
  }, [titlesWithContext, statusFilter, managerFilter, sectionFilter, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto space-y-4 animate-in fade-in duration-500 pb-8">
      
      {/* ПАНЕЛЬ ФИЛЬТРОВ */}
      <div className="bg-white p-4 rounded-[1.75rem] border border-slate-200 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Поиск по номеру или названию..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold focus:ring-4 focus:ring-blue-500/10 focus:bg-white outline-none transition-all"
            />
          </div>
          
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-slate-50 border border-slate-100 rounded-xl px-2">
              <Filter size={14} className="text-slate-400 ml-1" />
              <select 
                value={sectionFilter}
                onChange={(e) => setSectionFilter(e.target.value)}
                className="text-xs font-black uppercase tracking-wider border-none bg-transparent px-2 py-2.5 focus:ring-0 outline-none transition-all cursor-pointer min-w-[120px]"
              >
                <option>Все разделы</option>
                <option>Железобетон (КЖ)</option>
                <option>Металлоконструкции (КМ)</option>
              </select>
            </div>

            <select 
              value={managerFilter}
              onChange={(e) => setManagerFilter(e.target.value)}
              className="text-xs font-black uppercase tracking-wider border-slate-200 rounded-xl px-3 py-2.5 bg-slate-50 hover:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all cursor-pointer min-w-[160px]"
            >
              {managersList.map(m => <option key={m} value={m}>{m}</option>)}
            </select>

            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs font-black uppercase tracking-wider border-slate-200 rounded-xl px-3 py-2.5 bg-slate-50 hover:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all cursor-pointer min-w-[130px]"
            >
              <option>Все статусы</option>
              {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* ОСОБЫЕ ТИТУЛЫ (СВОДНЫЕ) */}
      {specialTitles.length > 0 && !searchQuery && managerFilter === 'Все РП' && (
        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-2 px-4">
             <Layers size={16} className="text-blue-600" />
             <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Сводные титулы</span>
          </div>
          <div className="space-y-3">
            {specialTitles.map(specialTitle => (
              <TitleAccordionItem 
                key={specialTitle.id}
                title={specialTitle} 
                isAdmin={user.role === UserRole.ADMIN}
                isOpen={expandedTitleId === specialTitle.id} 
                onToggle={() => setExpandedTitleId(expandedTitleId === specialTitle.id ? null : specialTitle.id)}
                onSave={onUpdateTitle}
                isSpecial
              />
            ))}
          </div>
        </div>
      )}

      {/* ОСНОВНОЙ СПИСОК */}
      <div className="space-y-3">
        {filteredTitles.length > 0 ? filteredTitles.map((title) => (
          <TitleAccordionItem 
            key={title.id} 
            title={title} 
            isAdmin={user.role === UserRole.ADMIN}
            isOpen={expandedTitleId === title.id} 
            onToggle={() => setExpandedTitleId(expandedTitleId === title.id ? null : title.id)}
            onSave={onUpdateTitle}
          />
        )) : (
          <div className="py-12 text-center bg-white rounded-[2rem] border border-dashed border-slate-200">
            <p className="text-slate-400 font-black text-xs uppercase tracking-widest">Ничего не найдено</p>
          </div>
        )}
      </div>
    </div>
  );
};

const TitleAccordionItem: React.FC<{ 
  title: Title; 
  isOpen: boolean; 
  isAdmin: boolean;
  onToggle: () => void;
  onSave: (title: Title) => void;
  isSpecial?: boolean;
}> = ({ title, isOpen, isAdmin, onToggle, onSave, isSpecial }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState<Title>({...title});

  // Sync state when title props change (e.g. external update)
  useEffect(() => {
    if (!isEditing) {
        setEditedTitle({...title});
    }
  }, [title, isEditing]);

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSave(editedTitle);
    setIsEditing(false);
  };

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsEditing(true);
    if (!isOpen) onToggle();
  };

  // Helper to handle nested updates for VolumeData (RC, SC)
  const handleVolumeUpdate = (section: 'rc' | 'sc', field: keyof VolumeData, value: string) => {
    const numValue = field === 'deadline' || field === 'startDate' ? value : parseFloat(value) || 0;
    setEditedTitle(prev => {
        const currentSection = prev[section] || { total: 0, done: 0, residual: 0 };
        const updatedSection = { ...currentSection, [field]: numValue };
        
        // Auto-calculate residual if Total or Done changes
        if (field === 'total' || field === 'done') {
            updatedSection.residual = updatedSection.total - updatedSection.done;
        }

        return { ...prev, [section]: updatedSection };
    });
  };

  const getSectionProgress = (vol: VolumeData | undefined) => {
      if (!vol || vol.total === 0) return 0;
      return Math.min(100, Math.max(0, (vol.done / vol.total) * 100));
  };

  return (
    <div className={`transition-all duration-300 ${isOpen ? 'mb-4' : 'mb-0'}`}>
      <div 
        onClick={isEditing ? undefined : onToggle}
        className={`w-full text-left bg-white border transition-all flex flex-col md:flex-row items-start md:items-center justify-between p-4 rounded-[1.5rem] shadow-sm group/btn relative overflow-hidden ${
          isOpen ? 'border-blue-500 ring-4 ring-blue-500/5 shadow-md' : 'border-slate-100 hover:border-blue-200 hover:shadow-md'
        } ${isSpecial ? 'bg-blue-50/20 border-blue-200' : ''} ${isEditing ? 'cursor-default' : 'cursor-pointer'}`}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-4 flex-1 min-w-0 w-full">
          {/* Flexible Number Badge */}
          <div className={`h-11 min-w-[3.5rem] w-auto px-4 rounded-xl flex items-center justify-center font-black text-sm shrink-0 shadow-sm transition-all self-start md:self-auto ${
            isOpen ? 'bg-blue-600 text-white' : (isSpecial ? 'bg-blue-600 text-white' : 'bg-slate-900 text-white group-hover/btn:bg-blue-600')
          }`}>
            {isEditing ? (
              <input 
                value={editedTitle.number}
                onChange={e => setEditedTitle({...editedTitle, number: e.target.value})}
                className="w-16 bg-transparent text-center focus:outline-none"
              />
            ) : title.number}
          </div>

          <div className="flex-1 min-w-0 w-full">
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-2 mb-2">
              {isEditing ? (
                <input 
                  value={editedTitle.name}
                  onChange={e => setEditedTitle({...editedTitle, name: e.target.value})}
                  className="w-full font-black text-slate-800 text-sm bg-slate-50 border border-slate-200 rounded-md px-2 py-1 focus:ring-2 focus:ring-blue-500"
                />
              ) : (
                <h3 className="font-black text-slate-800 text-base leading-tight group-hover/btn:text-blue-600 transition-colors">
                  {title.name}
                </h3>
              )}
              
              <div className="flex items-center space-x-2 md:hidden">
                 <StatusBadge status={isEditing ? editedTitle.status : title.status} />
              </div>
            </div>

            {/* Compact Progress Indicators in Header */}
            <div className="flex flex-wrap items-center gap-3">
               {!isSpecial && !isEditing && (
                 <span className="hidden md:flex items-center text-[10px] font-black uppercase tracking-wider text-slate-500 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100">
                   <UserIcon size={12} className="mr-1.5" /> {title.manager}
                 </span>
               )}
               
               {/* КЖ Badge */}
               {(title.rc && title.rc.total > 0) || isEditing ? (
                 <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 rounded-lg border border-blue-100">
                    <span className="text-[10px] font-black text-blue-700">КЖ</span>
                    <div className="h-1.5 w-12 bg-blue-200 rounded-full overflow-hidden">
                       <div className="h-full bg-blue-600" style={{width: `${getSectionProgress(isEditing ? editedTitle.rc : title.rc)}%`}}></div>
                    </div>
                    <span className="text-[10px] font-bold text-blue-800">{getSectionProgress(isEditing ? editedTitle.rc : title.rc).toFixed(0)}%</span>
                 </div>
               ) : null}

               {/* КМ Badge */}
               {(title.sc && title.sc.total > 0) || isEditing ? (
                 <div className="flex items-center gap-2 px-3 py-1.5 bg-orange-50 rounded-lg border border-orange-100">
                    <span className="text-[10px] font-black text-orange-700">КМ</span>
                    <div className="h-1.5 w-12 bg-orange-200 rounded-full overflow-hidden">
                       <div className="h-full bg-orange-600" style={{width: `${getSectionProgress(isEditing ? editedTitle.sc : title.sc)}%`}}></div>
                    </div>
                    <span className="text-[10px] font-bold text-orange-800">{getSectionProgress(isEditing ? editedTitle.sc : title.sc).toFixed(0)}%</span>
                 </div>
               ) : null}
            </div>
          </div>
        </div>

        {/* Right Actions (Desktop) */}
        <div className="hidden md:flex items-center ml-4 space-x-4 self-center">
          <div className="flex items-center space-x-3 min-w-[120px] justify-end">
            {isAdmin && !isEditing && (
              <button 
                onClick={handleEditClick}
                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
              >
                <Edit2 size={16} />
              </button>
            )}
            <StatusBadge status={isEditing ? editedTitle.status : title.status} />
            {!isEditing && (
              <div className={`p-1.5 rounded-lg transition-all duration-300 ${isOpen ? 'bg-blue-50 text-blue-600 rotate-180' : 'text-slate-200 bg-slate-50'}`}>
                <ChevronDown size={16} />
              </div>
            )}
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="mx-3 lg:mx-5 bg-white border-x border-b border-slate-100 rounded-b-[1.75rem] p-4 lg:p-6 space-y-6 animate-in slide-in-from-top-2 duration-300 shadow-lg relative z-0">
          
          {/* SECTION PROGRESS BARS */}
          <div className="space-y-4">
             <div className="flex items-center justify-between mb-4">
               <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-600">
                    <Target size={16} />
                  </div>
                  <h4 className="text-xs font-black uppercase tracking-[0.15em] text-slate-800">Детальные объемы</h4>
               </div>
               {isEditing && (
                 <div className="flex gap-2">
                    <button onClick={handleSave} className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-green-700 transition-colors shadow-lg shadow-green-200">
                       <Save size={14}/> Сохранить
                    </button>
                    <button onClick={() => { setIsEditing(false); setEditedTitle({...title}); }} className="flex items-center gap-2 bg-slate-100 text-slate-600 px-4 py-2 rounded-lg text-xs font-bold hover:bg-slate-200 transition-colors">
                       <X size={14}/> Отмена
                    </button>
                 </div>
               )}
             </div>

             <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
               
               {/* RC Section Block */}
               {((title.rc && title.rc.total > 0) || isEditing) && (
                 <SectionEditor 
                    label="Железобетон (КЖ)" 
                    unit="м3"
                    color="blue"
                    data={isEditing ? editedTitle.rc : title.rc} 
                    isEditing={isEditing}
                    onChange={(field, val) => handleVolumeUpdate('rc', field, val)}
                 />
               )}

               {/* SC Section Block */}
               {((title.sc && title.sc.total > 0) || isEditing) && (
                 <SectionEditor 
                    label="Металлоконструкции (КМ)" 
                    unit="тн"
                    color="orange"
                    data={isEditing ? editedTitle.sc : title.sc} 
                    isEditing={isEditing}
                    onChange={(field, val) => handleVolumeUpdate('sc', field, val)}
                 />
               )}

             </div>
          </div>

          {!isSpecial && !isEditing && (
            <div className="bg-slate-900 rounded-[1.25rem] p-4 text-white relative overflow-hidden">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 relative z-10">
                <div className="flex items-center space-x-3 flex-1">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center text-blue-400 border border-white/10">
                    <UserIcon size={20} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-1 mb-0.5">
                      <BadgeCheck size={12} className="text-blue-400" />
                      <p className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Ответственный РП</p>
                    </div>
                    <h5 className="text-sm font-black leading-tight">{title.manager}</h5>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Sub-component for individual section editing/display
const SectionEditor: React.FC<{
  label: string;
  unit: string;
  color: 'blue' | 'orange';
  data: VolumeData | undefined;
  isEditing: boolean;
  onChange: (field: keyof VolumeData, val: string) => void;
}> = ({ label, unit, color, data, isEditing, onChange }) => {
  const safeData = {
    total: data?.total ?? 0,
    done: data?.done ?? 0,
    residual: data?.residual ?? 0,
    deadline: data?.deadline ?? '',
    startDate: data?.startDate ?? ''
  };
  const progress = safeData.total > 0 ? (safeData.done / safeData.total) * 100 : 0;
  
  const theme = {
    blue: { bg: 'bg-blue-50', border: 'border-blue-100', text: 'text-blue-600', bar: 'bg-blue-600', sub: 'bg-blue-200' },
    orange: { bg: 'bg-orange-50', border: 'border-orange-100', text: 'text-orange-600', bar: 'bg-orange-500', sub: 'bg-orange-200' }
  }[color];

  // Helper for displaying dates correctly
  const formatDate = (dStr?: string) => {
      if (!dStr) return 'Не указан';
      const d = new Date(dStr);
      return !isNaN(d.getTime()) ? d.toLocaleDateString('ru-RU') : 'Не указан';
  };

  const formatNumber = (num: number) => {
    return num.toLocaleString('ru-RU');
  };

  return (
    <div className={`p-5 rounded-2xl border transition-all ${isEditing ? 'bg-white border-blue-300 shadow-md ring-1 ring-blue-100' : `${theme.bg} ${theme.border} shadow-sm`}`}>
       <div className="flex justify-between items-center mb-3">
          <span className={`text-[10px] font-black uppercase tracking-widest ${theme.text}`}>{label}</span>
          <span className="text-[10px] font-bold text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-100">{unit}</span>
       </div>

       {isEditing ? (
         <div className="grid grid-cols-2 gap-4 mb-2">
            <div>
               <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Всего (План)</label>
               <div className="relative">
                  <input 
                    type="number" 
                    value={safeData.total} 
                    onChange={e => onChange('total', e.target.value)}
                    className="w-full pl-3 pr-2 py-2 border border-slate-200 rounded-lg text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                  <Calculator size={14} className="absolute right-2 top-2.5 text-slate-300"/>
               </div>
            </div>
            <div>
               <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Выполнено (Факт)</label>
               <input 
                 type="number" 
                 value={safeData.done} 
                 onChange={e => onChange('done', e.target.value)}
                 className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm font-bold text-emerald-600 focus:ring-2 focus:ring-emerald-500 outline-none"
               />
            </div>
            <div className="col-span-2">
               <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Срок завершения</label>
               <input 
                 type="date"
                 value={safeData.deadline || ''} 
                 onChange={e => onChange('deadline', e.target.value)}
                 className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm font-bold text-slate-700 focus:ring-2 focus:ring-blue-500 outline-none"
               />
            </div>
         </div>
       ) : (
         <div className="mb-4 space-y-4">
            {/* Progress Bar & Main Stats */}
            <div>
                <div className="flex justify-between items-end mb-1">
                   <div>
                       <span className="text-[10px] font-bold text-slate-400 uppercase block mb-0.5">Факт / План</span>
                       <div className="flex items-baseline gap-1">
                           <span className="text-xl font-black text-slate-800">{formatNumber(safeData.done)}</span>
                           <span className="text-xs font-bold text-slate-400">/ {formatNumber(safeData.total)}</span>
                       </div>
                   </div>
                   <div className={`text-2xl font-black ${theme.text}`}>{progress.toFixed(0)}%</div>
                </div>
                <div className="w-full h-3 bg-white rounded-full overflow-hidden border border-white/50">
                   <div className={`h-full rounded-full transition-all duration-1000 ${theme.bar}`} style={{width: `${Math.min(100, progress)}%`}}></div>
                </div>
            </div>

            {/* Grid for Residual & Deadline */}
            <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-200/50">
                <div className="bg-white/50 p-2 rounded-lg border border-white">
                    <span className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Остаток</span>
                    <span className={`text-sm font-black ${safeData.residual < 0 ? 'text-red-500' : 'text-slate-700'}`}>
                        {formatNumber(safeData.residual)} <span className="text-[9px] text-slate-400 font-bold">{unit}</span>
                    </span>
                </div>
                <div className="bg-white/50 p-2 rounded-lg border border-white">
                    <span className="text-[9px] font-bold text-slate-400 uppercase block mb-1 flex items-center gap-1">
                        <Calendar size={10}/> Срок (ГПР)
                    </span>
                    <span className="text-sm font-black text-slate-700">
                        {formatDate(safeData.deadline)}
                    </span>
                </div>
            </div>
         </div>
       )}
    </div>
  );
};

const StatusBadge: React.FC<{ status: ProjectStatus | string }> = ({ status }) => {
  const styles: Record<string, string> = {
    [ProjectStatus.IN_SCHEDULE]: 'bg-emerald-50 text-emerald-600 border-emerald-100',
    [ProjectStatus.RISK]: 'bg-amber-50 text-amber-600 border-amber-100',
    [ProjectStatus.DELAY]: 'bg-rose-50 text-rose-600 border-rose-100',
    [ProjectStatus.COMPLETED]: 'bg-blue-50 text-blue-600 border-blue-100',
  };

  const icons: Record<string, React.ReactNode> = {
    [ProjectStatus.IN_SCHEDULE]: <CheckCircle size={12} />,
    [ProjectStatus.RISK]: <AlertTriangle size={12} />,
    [ProjectStatus.DELAY]: <Clock size={12} />,
    [ProjectStatus.COMPLETED]: <CheckCircle size={12} />,
  };

  const currentStyle = styles[status] || 'bg-slate-50 text-slate-600 border-slate-100';
  const currentIcon = icons[status] || <CheckCircle size={12} />;

  return (
    <span className={`inline-flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] font-black uppercase tracking-widest transition-transform group-hover/btn:scale-105 ${currentStyle}`}>
      {currentIcon}
      <span>{status}</span>
    </span>
  );
};

export default TitlesModule;
