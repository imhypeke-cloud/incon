<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/drive/1EsW4eq47iRl5CxoIUqQ1lyKUpC8SG6kh

## Deploy to Vercel

This project is configured for deployment on Vercel using Serverless Functions.

1.  **Install Vercel CLI:**
    `npm install -g vercel`
2.  **Login to Vercel:**
    `vercel login`
3.  **Deploy:**
    `vercel`
4.  **Set Environment Variables:**
    In the Vercel Dashboard, go to Settings -> Environment Variables and add `GEMINI_API_KEY`.

**Note on Persistence:**
Vercel Serverless Functions have a read-only filesystem. Data saved via `/api/data` is stored in `/tmp` and will NOT be persisted across requests or deployments. For production data persistence, consider integrating a database like Firebase, Supabase, or Vercel KV.

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`
