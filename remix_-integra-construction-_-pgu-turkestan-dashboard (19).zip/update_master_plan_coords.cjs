const fs = require('fs');

const constantsPath = './constants.ts';
let content = fs.readFileSync(constantsPath, 'utf8');

const updates = {
  '1.1': { x: -5, z: 10, width: 40, length: 15, height: 6, color: "'#f59e0b'", polygon: "[[-25, 5], [15, 5], [15, 15], [25, 15], [25, 20], [-25, 20]]" },
  '1.2': { x: -25, z: -5, width: 8, length: 12, height: 4, color: "'#f59e0b'" },
  '1.3': { x: -25, z: 5, width: 8, length: 12, height: 4, color: "'#f59e0b'" },
  '2.1': { x: -20, z: -25, width: 10, length: 15, height: 4, color: "'#f59e0b'" },
  '2.2': { x: -5, z: -10, width: 12, length: 8, height: 5, color: "'#f59e0b'" },
  '3': { x: -25, z: -15, width: 6, length: 8, height: 3, color: "'#f59e0b'" },
  '12.3': { x: -5, z: -35, width: 8, length: 8, height: 6, color: "'#f59e0b'", polygon: "Array.from({ length: 32 }, (_, i) => [Math.cos(i * Math.PI / 16) * 4, Math.sin(i * Math.PI / 16) * 4])" },
  '13.2-13.3': { x: 5, z: -35, width: 8, length: 8, height: 6, color: "'#f59e0b'", polygon: "Array.from({ length: 32 }, (_, i) => [Math.cos(i * Math.PI / 16) * 4, Math.sin(i * Math.PI / 16) * 4])" },
  '15.2-15.3': { x: 15, z: -35, width: 8, length: 8, height: 6, color: "'#f59e0b'", polygon: "Array.from({ length: 32 }, (_, i) => [Math.cos(i * Math.PI / 16) * 4, Math.sin(i * Math.PI / 16) * 4])" },
  '20.1-20.3': { x: 25, z: -35, width: 6, length: 6, height: 5, color: "'#f59e0b'", polygon: "Array.from({ length: 32 }, (_, i) => [Math.cos(i * Math.PI / 16) * 3, Math.sin(i * Math.PI / 16) * 3])" },
  '4.1-4.2': { x: -15, z: 25, width: 5, length: 5, height: 2, color: "'#ef4444'" },
  '5.1-5.2': { x: -5, z: 25, width: 5, length: 5, height: 2, color: "'#ef4444'" },
  '5.3-5.4': { x: 5, z: 25, width: 5, length: 5, height: 2, color: "'#ef4444'" },
  '6.1-6.4': { x: 15, z: 25, width: 5, length: 5, height: 2, color: "'#ef4444'" },
  '7.1': { x: 35, z: -25, width: 10, length: 25, height: 4, color: "'#3b82f6'" },
  '7.2': { x: 35, z: -10, width: 10, length: 25, height: 4, color: "'#3b82f6'" },
  '8.1': { x: 25, z: 10, width: 8, length: 15, height: 4, color: "'#f59e0b'" },
  '8.2': { x: 25, z: 20, width: 8, length: 15, height: 4, color: "'#f59e0b'" },
  '9': { x: 35, z: 10, width: 15, length: 20, height: 8, color: "'#f59e0b'", polygon: "[[30, 0], [35, -5], [40, 0], [42, 10], [38, 15], [32, 15], [28, 10]]" },
};

for (const [id, data] of Object.entries(updates)) {
  const regex = new RegExp(`(id:\\s*'${id}'.*?)(})`, 's');
  const match = content.match(regex);
  if (match) {
    let props = Object.entries(data)
      .map(([k, v]) => `${k}: ${v}`)
      .join(', ');
    
    // Check if it already has x, z, etc.
    if (!match[1].includes('x:')) {
      const replacement = `${match[1].trim()},\n    ${props}\n  }`;
      content = content.replace(regex, replacement);
    }
  }
}

fs.writeFileSync(constantsPath, content, 'utf8');
console.log('Updated constants.ts');
