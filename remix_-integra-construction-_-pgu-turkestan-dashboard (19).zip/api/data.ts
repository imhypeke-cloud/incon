import { VercelRequest, VercelResponse } from '@vercel/node';
import fs from 'fs';
import path from 'path';

// WARNING: Vercel Serverless Functions have a read-only filesystem.
// Files written to /tmp are not persisted across requests.
// This implementation is for demonstration and will NOT persist data on Vercel.
// Use a database (Firebase, Supabase, Vercel KV) for production.

const DATA_DIR = '/tmp/data'; // Use /tmp for temporary storage if needed, but it's not persistent

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const { module } = req.query;
  
  if (!module || typeof module !== 'string') {
    return res.status(400).json({ error: 'Module name is required' });
  }

  const filePath = path.join(DATA_DIR, `${module}.json`);

  if (req.method === 'GET') {
    if (fs.existsSync(filePath)) {
      try {
        const data = fs.readFileSync(filePath, 'utf-8');
        return res.status(200).json(JSON.parse(data));
      } catch (e) {
        return res.status(500).json({ error: 'Error reading data' });
      }
    }
    return res.status(404).json({ error: 'Data not found' });
  }

  if (req.method === 'POST') {
    try {
      fs.writeFileSync(filePath, JSON.stringify(req.body, null, 2), 'utf-8');
      return res.status(200).json({ success: true });
    } catch (e) {
      return res.status(500).json({ error: 'Error saving data' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
