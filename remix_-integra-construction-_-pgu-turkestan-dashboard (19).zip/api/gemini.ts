import { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from "@google/genai";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.error('GEMINI_API_KEY is not set in environment variables');
    return res.status(500).json({ error: 'Server configuration error: Missing API Key' });
  }

  try {
    const { prompt, data, mimeType } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const genAI = new GoogleGenAI({ apiKey });
    
    let result;
    if (data && mimeType) {
      // Handle file (Base64)
      result = await genAI.models.generateContent({
        model: "gemini-1.5-flash",
        contents: {
          parts: [
            { text: prompt },
            { inlineData: { data, mimeType } }
          ]
        },
        config: {
          systemInstruction: "You are a specialist construction data analyst for INTEGRA CONSTRUCTION."
        }
      });
    } else {
      // Text only
      result = await genAI.models.generateContent({
        model: "gemini-1.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are a specialist construction data analyst for INTEGRA CONSTRUCTION."
        }
      });
    }

    const text = result.text;

    return res.status(200).json({ text });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    return res.status(500).json({ error: error.message || 'Internal Server Error' });
  }
}
