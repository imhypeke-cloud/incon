import { VercelRequest, VercelResponse } from '@vercel/node';
import fs from 'fs';
import path from 'path';

const DATA_DIR = '/tmp/data';

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const filePath = path.join(DATA_DIR, 'auditLogs.json');
  
  try {
    let logs = [];
    if (fs.existsSync(filePath)) {
      logs = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    }
    logs.unshift(req.body);
    fs.writeFileSync(filePath, JSON.stringify(logs, null, 2), 'utf-8');
    return res.status(200).json({ success: true });
  } catch (e) {
    return res.status(500).json({ error: 'Error saving logs' });
  }
}
